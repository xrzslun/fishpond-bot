#!/usr/bin/env python3
"""QQ <-> DeepSeek 桥接机器人 + 管理后台

本源码完全免费发布，请勿通过购买获取。
作者 QQ：2844642318
交流群：243625638


- OneBot 11 WebSocket 连接 NapCat，群聊 @ 触发 / 私聊直回
- DeepSeek API 回复，带上下文与限流
- 管理后台（登录后可见）：状态、扫码登录（点击才请求）、群/QQ 白名单、管理员账号
"""
import asyncio
import base64
import hashlib
import io
import random
import json
import logging
import os
import sys
import secrets
import sqlite3
import subprocess
import re
import time
from datetime import datetime
from collections import deque
from pathlib import Path

import aiohttp
import yaml
from aiohttp import web as aiohttp_web

APP_VERSION = "3.3.5"
DEFAULT_UPDATE_URL = "https://xrzs.cloud/updates/latest.json"
MEMORY_FEATURE = False  # 发布版由 make_release.py 置为 False
VIEWER_FEATURE = False  # 发布版由 make_release.py 置为 False

BASE = Path(__file__).resolve().parent
STICKER_DIR = BASE / "stickers"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("qqbridge")

LOG_RING = deque(maxlen=80)


class RingHandler(logging.Handler):
    def emit(self, record):
        try:
            LOG_RING.append(self.format(record))
        except Exception:
            pass


_ring = RingHandler()
_ring.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%H:%M:%S"))
log.addHandler(_ring)
logging.getLogger().addHandler(_ring)


BORED_LINES = [
    "安静得有点过分了，你们说全世界最安静的地方是哪儿？",
    "突然想问问，你们午饭都吃啥了？我还在纠结",
    "话说鱼会口渴吗？在线等，不着急",
    "有没有人跟我一样，明明很困但就是不想睡",
    "我怀疑这个群被施了静音咒，有人能解开吗",
    "如果发呆能赚钱，我现在应该已经财富自由了",
    "刚看到一只猫在晒太阳，你们说它脑子里在想什么",
    "突然好奇：你们手机里最舍不得删的一张照片是什么",
    "好无聊啊，有没有人来讲个冷笑话，我先讲：企鹅为什么不怕冷",
    "问一下，你们觉得世界上先有鸡还是先有蛋（认真脸）",
    "这个点大家都在忙什么？摸鱼的扣个 1",
    "天塌下来也先聊两句再跑啊，你们说是不是",
    "刚才发呆十分钟，感觉自己像个加载中的网页",
    "有人在线吗，出来吱一声，让我知道我没对着空气说话",
    "突然想到，如果今天不用上班，你们最想去哪儿",
]


PROVIDER_PRESETS = {
    "deepseek": {"base_url": "https://api.deepseek.com", "model": "deepseek-chat"},
    "openai": {"base_url": "https://api.openai.com/v1", "model": "gpt-4o-mini"},
    "moonshot": {"base_url": "https://api.moonshot.cn/v1", "model": "moonshot-v1-8k"},
    "zhipu": {"base_url": "https://open.bigmodel.cn/api/paas/v4", "model": "glm-4-flash"},
    "siliconflow": {"base_url": "https://api.siliconflow.cn/v1", "model": "deepseek-ai/DeepSeek-V3"},
    "openrouter": {"base_url": "https://openrouter.ai/api/v1", "model": "openrouter/auto"},
    "groq": {"base_url": "https://api.groq.com/openai/v1", "model": "llama-3.3-70b-versatile"},
    "custom": {"base_url": "", "model": ""},
}

END_PHRASES = [
    "没你事了", "没你事", "滚吧", "滚蛋", "闭嘴", "别说了", "别接话",
    "不用你了", "不需要你", "一边去", "走开", "退下", "散了吧",
    "你可以走了", "别理我", "歇着吧", "没你说话的份",
]


def load_config() -> dict:
    cfg_path = BASE / "config.yaml"
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    return cfg


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 200_000).hex()
    return f"{salt}${h}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt, h = stored.split("$", 1)
    except ValueError:
        return False
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 200_000).hex() == h


class Store:
    """SQLite 存储：管理员、白名单"""

    def __init__(self, path: Path):
        self.path = path
        self._cache: dict[str, str] = {}
        self._cache_ts = 0.0
        self._init()

    def _conn(self):
        c = sqlite3.connect(self.path)
        c.row_factory = sqlite3.Row
        return c

    def _init(self):
        with self._conn() as c:
            c.executescript(
                """
                CREATE TABLE IF NOT EXISTS admins (
                    username TEXT PRIMARY KEY,
                    pass_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS wl_groups (group_id TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS wl_users (qq TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS keywords (word TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS prefix_map (qq TEXT PRIMARY KEY, prefix TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS auto_users (qq TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS bored_lines (line TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS always_groups (group_id TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS group_rate (group_id TEXT PRIMARY KEY, max_per_minute INTEGER, min_interval_seconds INTEGER);
                CREATE TABLE IF NOT EXISTS stickers (id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS end_phrases (phrase TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS personas (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, content TEXT NOT NULL, created_at REAL NOT NULL, updated_at REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS blacklist (qq TEXT PRIMARY KEY, nick TEXT, added_at REAL);
                CREATE TABLE IF NOT EXISTS friend_requests (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, comment TEXT, flag TEXT, action TEXT, created_at TEXT, acted_at TEXT);
                CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY AUTOINCREMENT, owner_qq TEXT NOT NULL, level TEXT DEFAULT 'normal', content TEXT NOT NULL, use_count INTEGER DEFAULT 0, permanent INTEGER DEFAULT 0, source TEXT DEFAULT '', created_at TEXT, last_used_at TEXT);
                CREATE INDEX IF NOT EXISTS idx_mem_owner ON memories(owner_qq);
                CREATE INDEX IF NOT EXISTS idx_mem_level ON memories(level);
                CREATE INDEX IF NOT EXISTS idx_mem_created ON memories(created_at);
                CREATE TABLE IF NOT EXISTS login_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER, username TEXT, role TEXT, success INTEGER, ip TEXT, ua TEXT, reason TEXT, created_at TEXT);
                CREATE TABLE IF NOT EXISTS rest_groups (group_id TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS rest_users (qq TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS rest_notify_groups (group_id TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS providers (name TEXT PRIMARY KEY, base_url TEXT NOT NULL, api_key TEXT NOT NULL, model TEXT NOT NULL, updated_at TEXT);
                CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
                """
            )
        with self._conn() as c:
            try:
                acols = [r["name"] for r in c.execute("PRAGMA table_info(admins)").fetchall()]
                for col, typ in (("role", "TEXT DEFAULT 'admin'"), ("created_by", "INTEGER"),
                                 ("quota_groups", "INTEGER"), ("quota_users", "INTEGER"),
                                 ("disabled", "INTEGER DEFAULT 0"), ("last_login_at", "TEXT"), ("last_login_ip", "TEXT")):
                    if col not in acols:
                        c.execute(f"ALTER TABLE admins ADD COLUMN {col} {typ}")
                if "id" not in acols:
                    c.execute(
                        "CREATE TABLE admins_new (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,"
                        " pass_hash TEXT NOT NULL, role TEXT DEFAULT 'admin', created_by INTEGER, quota_groups INTEGER,"
                        " quota_users INTEGER, disabled INTEGER DEFAULT 0, last_login_at TEXT, last_login_ip TEXT, created_at TEXT)"
                    )
                    c.execute(
                        "INSERT INTO admins_new(username, pass_hash, role, created_by, quota_groups, quota_users, disabled, created_at)"
                        " SELECT username, pass_hash, role, created_by, quota_groups, quota_users, disabled, created_at FROM admins"
                    )
                    c.execute("DROP TABLE admins")
                    c.execute("ALTER TABLE admins_new RENAME TO admins")
                    acols = [r["name"] for r in c.execute("PRAGMA table_info(admins)").fetchall()]
                gcols = [r["name"] for r in c.execute("PRAGMA table_info(wl_groups)").fetchall()]
                if "created_by" not in gcols:
                    c.execute("ALTER TABLE wl_groups ADD COLUMN created_by INTEGER")
                if "created_at" not in gcols:
                    c.execute("ALTER TABLE wl_groups ADD COLUMN created_at TEXT")
                ucols = [r["name"] for r in c.execute("PRAGMA table_info(wl_users)").fetchall()]
                if "created_by" not in ucols:
                    c.execute("ALTER TABLE wl_users ADD COLUMN created_by INTEGER")
                if "created_at" not in ucols:
                    c.execute("ALTER TABLE wl_users ADD COLUMN created_at TEXT")
                c.execute("UPDATE admins SET role='super' WHERE username IN ('admin','心如止水')")
                c.execute("UPDATE admins SET role='admin' WHERE role IS NULL OR role=''")
            except Exception:
                pass
            try:
                cols = [r["name"] for r in c.execute("PRAGMA table_info(blacklist)").fetchall()]
                if "nick" not in cols:
                    c.execute("ALTER TABLE blacklist ADD COLUMN nick TEXT")
                if "added_at" not in cols:
                    c.execute("ALTER TABLE blacklist ADD COLUMN added_at REAL")
                lcols = [r["name"] for r in c.execute("PRAGMA table_info(login_logs)").fetchall()]
                if lcols and "location" not in lcols:
                    c.execute("ALTER TABLE login_logs ADD COLUMN location TEXT")
            except Exception:
                pass

    def admins(self) -> list[str]:
        with self._conn() as c:
            return [r["username"] for r in c.execute("SELECT username FROM admins ORDER BY created_at")]

    def admin_hash(self, username: str) -> str | None:
        with self._conn() as c:
            r = c.execute("SELECT pass_hash FROM admins WHERE username=?", (username,)).fetchone()
            return r["pass_hash"] if r else None

    def add_admin(self, username: str, password: str) -> bool:
        try:
            with self._conn() as c:
                c.execute(
                    "INSERT INTO admins(username, pass_hash, created_at) VALUES(?,?,datetime('now','localtime'))",
                    (username, hash_password(password)),
                )
            return True
        except sqlite3.IntegrityError:
            return False

    def remove_admin(self, username: str):
        with self._conn() as c:
            c.execute("DELETE FROM admins WHERE username=?", (username,))

    def admin_count(self) -> int:
        with self._conn() as c:
            return c.execute("SELECT COUNT(*) AS n FROM admins").fetchone()["n"]


    # ---------- 好友申请 ----------
    def friend_add(self, user_id, comment, flag, action):
        with self._conn() as c:
            c.execute("INSERT INTO friend_requests(user_id, comment, flag, action, created_at)"
                      " VALUES(?,?,?,?,datetime('now','localtime'))",
                      (str(user_id), str(comment or "")[:120], str(flag or ""), action))

    def friend_update(self, flag, action):
        with self._conn() as c:
            c.execute("UPDATE friend_requests SET action=?, acted_at=datetime('now','localtime') WHERE flag=?",
                      (action, str(flag or "")))

    def friend_list(self, limit=50):
        with self._conn() as c:
            return [dict(r) for r in c.execute(
                "SELECT * FROM friend_requests ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]

    def friend_today(self, action):
        with self._conn() as c:
            r = c.execute("SELECT COUNT(*) AS n FROM friend_requests WHERE action=? AND date(created_at)=date('now','localtime')",
                          (action,)).fetchone()
            return int(r["n"] if r else 0)

    # ---------- 记忆 ----------
    @staticmethod
    def mem_norm(text: str) -> str:
        import re as _re
        return _re.sub(r"[\s，。！？、,.!?：:；;\"'“”‘’（）()【】\[\]]+", "", str(text or "")).lower()

    def mem_dedupe(self):
        with self._conn() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT * FROM memories ORDER BY permanent DESC, use_count DESC, id ASC").fetchall()]
            kept = []
            for r in rows:
                dup = None
                for k in kept:
                    if k["owner_qq"] != r["owner_qq"]:
                        continue
                    if self.mem_sim(r["content"], k["content"]):
                        dup = k
                        break
                if dup is None:
                    kept.append(r)
                    continue
                # 保留更有价值的一条
                keep, drop = dup, r
                if int(r.get("use_count") or 0) > int(dup.get("use_count") or 0):
                    keep, drop = r, dup
                if int(drop.get("permanent") or 0) and not int(keep.get("permanent") or 0):
                    keep, drop = drop, keep
                c.execute("DELETE FROM memories WHERE id=?", (drop["id"],))
                if keep is r:
                    kept = [x for x in kept if x["id"] != dup["id"]] + [r]

    @staticmethod
    def mem_core(text: str) -> str:
        t = Store.mem_norm(text)
        for w in ("用户", "称呼为", "被称为", "称呼", "叫", "提到", "觉得", "喜欢", "习惯", "关注", "认为", "说", "的", "有点", "模式"):
            t = t.replace(w, "")
        return t

    @staticmethod
    def mem_sim(a: str, b: str) -> bool:
        na, nb = Store.mem_core(a), Store.mem_core(b)
        if not na or not nb:
            na, nb = Store.mem_norm(a), Store.mem_norm(b)
        if na == nb or (len(na) >= 2 and na in nb) or (len(nb) >= 2 and nb in na):
            return True
        if min(len(na), len(nb)) < 3:
            return False
        ga = {na[i:i + 2] for i in range(len(na) - 1)}
        gb = {nb[i:i + 2] for i in range(len(nb) - 1)}
        return len(ga & gb) / max(1, len(ga | gb)) >= 0.65

    NOISE_WORDS = ("用户提醒", "用户要求", "用户希望", "用户让", "用户告知", "用户叫", "密钥",
                   "部署包", "服务器", "API", "接口", "安装", "配置", "更新版本", "操作步骤", "步骤")

    @staticmethod
    def mem_is_noise(text: str) -> bool:
        t = str(text or "")
        return any(w in t for w in Store.NOISE_WORDS)

    def mem_noise_preview(self):
        with self._conn() as c:
            rows = [dict(r) for r in c.execute("SELECT * FROM memories").fetchall()]
        items = [r for r in rows if self.mem_is_noise(r["content"])]
        return len(rows), items

    def mem_clean_noise(self) -> int:
        total, items = self.mem_noise_preview()
        if not items:
            return 0
        with self._conn() as c:
            for it in items:
                c.execute("DELETE FROM memories WHERE id=?", (it["id"],))
        return len(items)

    def mem_add(self, owner_qq, content, level="normal", source=""):
        with self._conn() as c:
            cur = c.execute(
                "INSERT INTO memories(owner_qq, level, content, source, created_at)"
                " VALUES(?,?,?,?,datetime('now','localtime'))",
                (str(owner_qq), level, content, source),
            )
            return int(cur.lastrowid)

    def mem_list_all(self, qq=None, keyword=None, date=None, limit=300):
        sql = "SELECT * FROM memories WHERE 1=1"
        args = []
        if qq:
            sql += " AND owner_qq=?"
            args.append(str(qq))
        if keyword:
            sql += " AND content LIKE ?"
            args.append(f"%{keyword}%")
        if date:
            sql += " AND date(created_at)=?"
            args.append(str(date))
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with self._conn() as c:
            return [dict(r) for r in c.execute(sql, args).fetchall()]

    def mem_by_owner(self, owner_qq, level=None, limit=50, all_levels=False):
        with self._conn() as c:
            if level is None or all_levels:
                rows = c.execute(
                    "SELECT * FROM memories WHERE owner_qq=?"
                    " ORDER BY CASE WHEN level='high' THEN 0 ELSE 1 END,"
                    " COALESCE(last_used_at, created_at) DESC, use_count DESC, id DESC LIMIT ?",
                    (str(owner_qq), limit),
                ).fetchall()
            else:
                rows = c.execute(
                    "SELECT * FROM memories WHERE owner_qq=? AND level=?"
                    " ORDER BY COALESCE(last_used_at, created_at) DESC, use_count DESC, id DESC LIMIT ?",
                    (str(owner_qq), level, limit),
                ).fetchall()
            return [dict(r) for r in rows]

    def mem_mark_used(self, ids, level):
        if not ids:
            return
        marks = ",".join("?" * len(ids))
        with self._conn() as c:
            c.execute(
                f"UPDATE memories SET use_count=use_count+1, last_used_at=datetime('now','localtime') WHERE id IN ({marks})",
                ids,
            )
            if level == "high":
                c.execute(
                    f"UPDATE memories SET permanent=1 WHERE id IN ({marks}) AND use_count>=3",
                    ids,
                )

    def mem_update(self, mid, content):
        with self._conn() as c:
            c.execute("UPDATE memories SET content=? WHERE id=?", (content, int(mid)))

    def mem_delete(self, mid):
        with self._conn() as c:
            c.execute("DELETE FROM memories WHERE id=?", (int(mid),))

    def mem_clear_owner(self, owner_qq):
        with self._conn() as c:
            c.execute("DELETE FROM memories WHERE owner_qq=?", (str(owner_qq),))

    def mem_cleanup(self, super_days=180, normal_days=7, super_max=500, normal_max=50):
        try:
            self.mem_dedupe()
        except Exception:
            pass
        now = time.time()
        with self._conn() as c:
            # 普通用户：按创建时间过期，且不做永久
            c.execute(
                "DELETE FROM memories WHERE level='normal' AND permanent=0"
                " AND created_at <= datetime('now','localtime', ?)",
                (f"-{int(normal_days)} days",),
            )
            # 超管：按最后使用/创建时间过期；3 次以上永久
            c.execute(
                "DELETE FROM memories WHERE level='high' AND permanent=0"
                " AND COALESCE(last_used_at, created_at) <= datetime('now','localtime', ?)",
                (f"-{int(super_days)} days",),
            )
            # 每人上限
            for lvl, cap in (("normal", normal_max), ("high", super_max)):
                cap = int(cap)
                owners = c.execute(
                    "SELECT owner_qq, COUNT(*) AS n FROM memories WHERE level=? AND permanent=0"
                    " GROUP BY owner_qq HAVING n > ?", (lvl, cap)
                ).fetchall()
                for row in owners:
                    c.execute(
                        "DELETE FROM memories WHERE id IN ("
                        " SELECT id FROM memories WHERE owner_qq=? AND level=? AND permanent=0"
                        " ORDER BY use_count DESC, id DESC LIMIT -1 OFFSET ?)",
                        (row["owner_qq"], lvl, cap),
                    )

    # ---------- 账号 / 权限 ----------
    def account_by_name(self, username: str):
        with self._conn() as c:
            r = c.execute("SELECT * FROM admins WHERE username=?", (username,)).fetchone()
            return dict(r) if r else None

    def account_by_id(self, aid):
        with self._conn() as c:
            r = c.execute("SELECT * FROM admins WHERE id=?", (int(aid),)).fetchone()
            return dict(r) if r else None

    def accounts_all(self):
        with self._conn() as c:
            return [dict(r) for r in c.execute(
                "SELECT id, username, role, created_by, quota_groups, quota_users, disabled,"
                " last_login_at, last_login_ip, created_at FROM admins ORDER BY id"
            ).fetchall()]

    def create_account(self, username: str, password: str, role: str, created_by=None,
                       quota_groups=None, quota_users=None):
        try:
            with self._conn() as c:
                cur = c.execute(
                    "INSERT INTO admins(username, pass_hash, role, created_by, quota_groups, quota_users,"
                    " created_at) VALUES(?,?,?,?,?,?,datetime('now','localtime'))",
                    (username, hash_password(password), role, created_by, quota_groups, quota_users),
                )
                return int(cur.lastrowid)
        except sqlite3.IntegrityError:
            return None

    def update_account(self, aid, **fields):
        allowed = ("role", "quota_groups", "quota_users", "disabled", "pass_hash")
        sets, vals = [], []
        for k, v in fields.items():
            if k in allowed:
                sets.append(f"{k}=?")
                vals.append(v)
        if not sets:
            return False
        vals.append(int(aid))
        with self._conn() as c:
            c.execute(f"UPDATE admins SET {', '.join(sets)} WHERE id=?", vals)
        return True

    def delete_account(self, aid):
        with self._conn() as c:
            c.execute("DELETE FROM admins WHERE id=?", (int(aid),))

    def touch_login(self, aid, ip: str):
        with self._conn() as c:
            c.execute(
                "UPDATE admins SET last_login_at=datetime('now','localtime'), last_login_ip=? WHERE id=?",
                (str(ip or ""), int(aid)),
            )

    def log_login(self, account_id, username, role, success, ip, ua, reason="", location=""):
        with self._conn() as c:
            c.execute(
                "INSERT INTO login_logs(account_id, username, role, success, ip, ua, reason, location, created_at)"
                " VALUES(?,?,?,?,?,?,?,?,datetime('now','localtime'))",
                (account_id, username, role, 1 if success else 0, str(ip or ""), str(ua or "")[:200], reason, str(location or "")),
            )
            c.execute("DELETE FROM login_logs WHERE created_at < datetime('now','localtime','-30 days')")

    def login_logs(self, limit=200, account_ids=None):
        with self._conn() as c:
            if account_ids is None:
                rows = c.execute("SELECT * FROM login_logs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            else:
                ids = [int(i) for i in account_ids] or [-1]
                marks = ",".join("?" * len(ids))
                rows = c.execute(
                    f"SELECT * FROM login_logs WHERE account_id IN ({marks}) ORDER BY id DESC LIMIT ?",
                    (*ids, limit),
                ).fetchall()
            return [dict(r) for r in rows]

    # ---------- 白名单归属 ----------
    def wl_groups_owner(self, gid):
        with self._conn() as c:
            r = c.execute("SELECT created_by FROM wl_groups WHERE group_id=?", (str(gid),)).fetchone()
            return r["created_by"] if r else None

    def wl_users_owner(self, qq):
        with self._conn() as c:
            r = c.execute("SELECT created_by FROM wl_users WHERE qq=?", (str(qq),)).fetchone()
            return r["created_by"] if r else None

    def wl_count(self, kind: str, created_by):
        table = "wl_groups" if kind == "group" else "wl_users"
        with self._conn() as c:
            return c.execute(f"SELECT COUNT(*) AS n FROM {table} WHERE created_by=?", (int(created_by),)).fetchone()["n"]

    def update_wl(self, kind: str, old: str, new: str):
        table = "wl_groups" if kind == "group" else "wl_users"
        col = "group_id" if kind == "group" else "qq"
        with self._conn() as c:
            c.execute(f"UPDATE {table} SET {col}=? WHERE {col}=?", (str(new), str(old)))

    def groups(self, created_by=None, all_rows=False):
        with self._conn() as c:
            if all_rows or created_by is None:
                rows = c.execute("SELECT group_id FROM wl_groups ORDER BY group_id").fetchall()
            else:
                rows = c.execute("SELECT group_id FROM wl_groups WHERE created_by=?", (int(created_by),)).fetchall()
            return [r["group_id"] for r in rows]

    def users(self, created_by=None, all_rows=False):
        with self._conn() as c:
            if all_rows or created_by is None:
                rows = c.execute("SELECT qq FROM wl_users ORDER BY qq").fetchall()
            else:
                rows = c.execute("SELECT qq FROM wl_users WHERE created_by=?", (int(created_by),)).fetchall()
            return [r["qq"] for r in rows]

    def keywords(self) -> list[str]:
        with self._conn() as c:
            return [r["word"] for r in c.execute("SELECT word FROM keywords ORDER BY rowid")]

    def add_keyword(self, word: str):
        with self._conn() as c:
            c.execute("INSERT OR IGNORE INTO keywords(word) VALUES(?)", (word,))

    def remove_keyword(self, word: str):
        with self._conn() as c:
            c.execute("DELETE FROM keywords WHERE word=?", (word,))

    def prefix_map(self) -> dict[str, str]:
        with self._conn() as c:
            return {r["qq"]: r["prefix"] for r in c.execute("SELECT qq, prefix FROM prefix_map ORDER BY rowid")}

    def set_prefix(self, qq: str, prefix: str):
        with self._conn() as c:
            c.execute("INSERT INTO prefix_map(qq, prefix) VALUES(?,?) ON CONFLICT(qq) DO UPDATE SET prefix=excluded.prefix", (qq, prefix))

    def remove_prefix(self, qq: str):
        with self._conn() as c:
            c.execute("DELETE FROM prefix_map WHERE qq=?", (qq,))

    def get_prefix(self, qq: str) -> str | None:
        with self._conn() as c:
            r = c.execute("SELECT prefix FROM prefix_map WHERE qq=?", (qq,)).fetchone()
            return r["prefix"] if r else None

    def auto_users(self) -> list[str]:
        with self._conn() as c:
            return [r["qq"] for r in c.execute("SELECT qq FROM auto_users ORDER BY rowid")]

    def add_auto_user(self, qq: str):
        with self._conn() as c:
            c.execute("INSERT OR IGNORE INTO auto_users(qq) VALUES(?)", (qq,))

    def remove_auto_user(self, qq: str):
        with self._conn() as c:
            c.execute("DELETE FROM auto_users WHERE qq=?", (qq,))

    def get_setting(self, key: str, default: str = "") -> str:
        now = time.time()
        if now - self._cache_ts > 5:
            with self._conn() as c:
                self._cache = {r["key"]: r["value"] for r in c.execute("SELECT key, value FROM settings")}
            self._cache_ts = now
        return self._cache.get(key, default)

    def set_setting(self, key: str, value: str):
        with self._conn() as c:
            c.execute("INSERT INTO settings(key, value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
        now = time.time()
        loaded = bool(self._cache_ts) and (now - self._cache_ts <= 5)
        self._cache[key] = value
        if loaded:
            self._cache_ts = now
        else:
            # 缓存未加载或已过期：标记为过期，下次读取时重新加载整张表
            self._cache_ts = 0.0

    def bored_lines(self) -> list[str]:
        with self._conn() as c:
            return [r["line"] for r in c.execute("SELECT line FROM bored_lines ORDER BY rowid")]

    def always_groups(self) -> list[str]:
        with self._conn() as c:
            return [r["group_id"] for r in c.execute("SELECT group_id FROM always_groups ORDER BY group_id")]

    def get_rate(self, group_id: str):
        with self._conn() as c:
            r = c.execute("SELECT max_per_minute, min_interval_seconds FROM group_rate WHERE group_id=?", (group_id,)).fetchone()
            return (r["max_per_minute"], r["min_interval_seconds"]) if r else None

    def set_rate(self, group_id: str, cap: int, interval: int):
        with self._conn() as c:
            c.execute(
                "INSERT INTO group_rate(group_id, max_per_minute, min_interval_seconds) VALUES(?,?,?) "
                "ON CONFLICT(group_id) DO UPDATE SET max_per_minute=excluded.max_per_minute, min_interval_seconds=excluded.min_interval_seconds",
                (group_id, cap, interval),
            )

    def del_rate(self, group_id: str):
        with self._conn() as c:
            c.execute("DELETE FROM group_rate WHERE group_id=?", (group_id,))

    def providers(self) -> list[dict]:
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT name, base_url, api_key, model FROM providers ORDER BY name")]

    def get_provider(self, name: str):
        with self._conn() as c:
            r = c.execute("SELECT name, base_url, api_key, model FROM providers WHERE name=?", (name,)).fetchone()
            return dict(r) if r else None

    def save_provider(self, name: str, base_url: str, api_key: str, model: str):
        with self._conn() as c:
            c.execute(
                "INSERT INTO providers(name, base_url, api_key, model, updated_at) VALUES(?,?,?,?,datetime('now','localtime')) "
                "ON CONFLICT(name) DO UPDATE SET base_url=excluded.base_url, api_key=excluded.api_key, model=excluded.model, updated_at=excluded.updated_at",
                (name, base_url.rstrip("/"), api_key, model),
            )

    def delete_provider(self, name: str):
        with self._conn() as c:
            c.execute("DELETE FROM providers WHERE name=?", (name,))

    def rest_groups(self) -> list[str]:
        with self._conn() as c:
            return [r["group_id"] for r in c.execute("SELECT group_id FROM rest_groups ORDER BY rowid").fetchall()]

    def rest_users(self) -> list[str]:
        with self._conn() as c:
            return [r["qq"] for r in c.execute("SELECT qq FROM rest_users ORDER BY rowid").fetchall()]

    def add_rest_group(self, gid: str):
        with self._conn() as c:
            c.execute("INSERT OR IGNORE INTO rest_groups(group_id) VALUES(?)", (str(gid),))

    def remove_rest_group(self, gid: str):
        with self._conn() as c:
            c.execute("DELETE FROM rest_groups WHERE group_id=?", (str(gid),))

    def add_rest_user(self, qq: str):
        with self._conn() as c:
            c.execute("INSERT OR IGNORE INTO rest_users(qq) VALUES(?)", (str(qq),))

    def remove_rest_user(self, qq: str):
        with self._conn() as c:
            c.execute("DELETE FROM rest_users WHERE qq=?", (str(qq),))

    def rest_notify_groups(self) -> list[str]:
        with self._conn() as c:
            return [r["group_id"] for r in c.execute("SELECT group_id FROM rest_notify_groups ORDER BY rowid").fetchall()]

    def add_rest_notify_group(self, gid: str):
        with self._conn() as c:
            c.execute("INSERT OR IGNORE INTO rest_notify_groups(group_id) VALUES(?)", (str(gid),))

    def remove_rest_notify_group(self, gid: str):
        with self._conn() as c:
            c.execute("DELETE FROM rest_notify_groups WHERE group_id=?", (str(gid),))

    def blacklist(self) -> list[dict]:
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT qq, nick, added_at FROM blacklist ORDER BY rowid").fetchall()]

    def add_black(self, qq: str, nick: str = ""):
        with self._conn() as c:
            c.execute(
                "INSERT INTO blacklist(qq, nick, added_at) VALUES(?,?,?) "
                "ON CONFLICT(qq) DO UPDATE SET nick=excluded.nick, added_at=excluded.added_at",
                (str(qq), str(nick or ""), time.time()),
            )

    def remove_black(self, qq: str):
        with self._conn() as c:
            c.execute("DELETE FROM blacklist WHERE qq=?", (str(qq),))

    def set_black_nick(self, qq: str, nick: str):
        with self._conn() as c:
            c.execute("UPDATE blacklist SET nick=? WHERE qq=?", (str(nick or ""), str(qq)))

    def is_black(self, qq: str) -> bool:
        with self._conn() as c:
            return c.execute("SELECT 1 FROM blacklist WHERE qq=?", (str(qq),)).fetchone() is not None

    def list_personas(self) -> list[dict]:
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT id, name, content, length(content) AS size FROM personas ORDER BY id").fetchall()]

    def get_persona(self, pid) -> dict | None:
        with self._conn() as c:
            r = c.execute("SELECT * FROM personas WHERE id=?", (int(pid),)).fetchone()
            return dict(r) if r else None

    def save_persona(self, pid, name: str, content: str) -> int:
        now = time.time()
        with self._conn() as c:
            if pid:
                c.execute("UPDATE personas SET name=?, content=?, updated_at=? WHERE id=?", (name, content, now, int(pid)))
                return int(pid)
            cur = c.execute("INSERT INTO personas(name, content, created_at, updated_at) VALUES(?,?,?,?)", (name, content, now, now))
            return int(cur.lastrowid)

    def delete_persona(self, pid):
        with self._conn() as c:
            c.execute("DELETE FROM personas WHERE id=?", (int(pid),))

    def end_phrases(self) -> list[str]:
        with self._conn() as c:
            return [r["phrase"] for r in c.execute("SELECT phrase FROM end_phrases ORDER BY rowid")]

    def add_end_phrase(self, phrase: str):
        with self._conn() as c:
            c.execute("INSERT OR IGNORE INTO end_phrases(phrase) VALUES(?)", (phrase,))

    def remove_end_phrase(self, phrase: str):
        with self._conn() as c:
            c.execute("DELETE FROM end_phrases WHERE phrase=?", (phrase,))

    def stickers(self) -> list[str]:
        with self._conn() as c:
            return [r["filename"] for r in c.execute("SELECT filename FROM stickers ORDER BY id")]

    def sticker_descriptions(self) -> list[dict]:
        with self._conn() as c:
            return [
                dict(r)
                for r in c.execute("SELECT filename, COALESCE(description,'') AS description FROM stickers ORDER BY id")
            ]

    def add_sticker(self, filename: str):
        with self._conn() as c:
            c.execute("INSERT OR IGNORE INTO stickers(filename, created_at) VALUES(?,datetime('now','localtime'))", (filename,))

    def set_sticker_description(self, filename: str, description: str):
        with self._conn() as c:
            c.execute("UPDATE stickers SET description=? WHERE filename=?", (str(description or ""), filename))

    def remove_sticker(self, filename: str):
        with self._conn() as c:
            c.execute("DELETE FROM stickers WHERE filename=?", (filename,))

    def set_always_group(self, group_id: str, enabled: bool):
        with self._conn() as c:
            if enabled:
                c.execute("INSERT OR IGNORE INTO always_groups(group_id) VALUES(?)", (group_id,))
            else:
                c.execute("DELETE FROM always_groups WHERE group_id=?", (group_id,))

    def add_bored_line(self, line: str):
        with self._conn() as c:
            c.execute("INSERT OR IGNORE INTO bored_lines(line) VALUES(?)", (line,))

    def remove_bored_line(self, line: str):
        with self._conn() as c:
            c.execute("DELETE FROM bored_lines WHERE line=?", (line,))

    def add_wl(self, kind: str, value: str, created_by=None):
        table = "wl_groups" if kind == "group" else "wl_users"
        col = "group_id" if kind == "group" else "qq"
        with self._conn() as c:
            c.execute(f"INSERT OR IGNORE INTO {table}({col}, created_by, created_at) VALUES(?,?,datetime('now','localtime'))", (value, created_by))

    def remove_wl(self, kind: str, value: str):
        table = "wl_groups" if kind == "group" else "wl_users"
        col = "group_id" if kind == "group" else "qq"
        with self._conn() as c:
            c.execute(f"DELETE FROM {table} WHERE {col}=?", (value,))


class Bridge:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.onebot = cfg.get("onebot", {})
        self.ds = cfg.get("deepseek", {})
        self.api_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
        self.api_base = (self.ds.get("base_url") or "https://api.deepseek.com").rstrip("/")
        self.model = self.ds.get("model") or "deepseek-chat"
        self.system_prompt = self.ds.get("persona") or "你是QQ里的AI助手，回答简洁友好、说人话。"
        self.temperature = float(self.ds.get("temperature", 0.7))
        self.max_reply_chars = int(self.ds.get("max_reply_chars", 800))
        self.timeout = int(self.ds.get("timeout", 60))

        vis = cfg.get("vision", {})
        self.vision_enabled = bool(vis.get("enabled", True))
        self.max_images = int(vis.get("max_images", 2))
        self.max_side = int(vis.get("max_side", 1024))
        self.max_bytes = int(vis.get("max_bytes", 6_000_000))

        trig = cfg.get("trigger", {})
        self.group_at_only = bool(trig.get("group_at_only", True))
        self.keywords = [str(k) for k in (trig.get("keywords") or []) if str(k).strip()]

        ctx = cfg.get("context", {})
        self.max_messages = int(ctx.get("max_messages", 12))
        self.session_ttl = int(ctx.get("session_ttl_seconds", 1800))
        self.max_sessions = int(ctx.get("max_sessions", 200))

        self.min_interval = float(cfg.get("rate_limit_seconds", 3))

        admin_cfg = cfg.get("admin", {})
        self.store = Store(BASE / admin_cfg.get("db_path", "data.db"))
        self.keywords_seed = [str(k) for k in (trig.get("keywords") or []) if str(k).strip()]
        if not self.store.end_phrases():
            for phrase in END_PHRASES:
                self.store.add_end_phrase(phrase)
        if not self.store.bored_lines():
            for line in BORED_LINES:
                self.store.add_bored_line(line)
        seed_prefix = {str(k): str(v) for k, v in (cfg.get("reply_prefix") or {}).items()}
        if not self.store.prefix_map():
            for qq, pref in seed_prefix.items():
                self.store.set_prefix(qq, pref)
        if not self.store.keywords():
            for w in self.keywords_seed:
                self.store.add_keyword(w)
        if self.store.admin_count() == 0:
            default = admin_cfg.get("default_admin", {})
            username = default.get("username", "admin")
            password = default.get("password", "admin")
            self.store.add_admin(username, password)
            log.info("已创建默认管理员 %s", username)

        STICKER_DIR.mkdir(parents=True, exist_ok=True)
        self.napcat_cfg = cfg.get("napcat", {})
        self.napcat_url = (self.napcat_cfg.get("webui_url") or "http://127.0.0.1:6099").rstrip("/")
        self.napcat_token = self.napcat_cfg.get("webui_token", "")
        self.napcat_cred = None
        self.napcat_cred_exp = 0
        self.qr_cooldown = float(self.napcat_cfg.get("qr_cooldown_seconds", 60))
        self.last_qr_ts = 0.0
        self.group_activity: dict[str, float] = {}
        self.active_convos: dict[tuple[str, str], float] = {}
        self.group_reply_times: dict[str, deque] = {}
        self.group_last_reply: dict[str, float] = {}
        ctx_cfg = cfg.get("context", {})
        self.continue_seconds = int(ctx_cfg.get("group_continue_seconds", 180))
        self.group_max_replies = int(ctx_cfg.get("group_max_replies_per_minute", 6))
        self.max_active_users = int(ctx_cfg.get("group_max_active_users", 3))
        self.cleanup_interval = max(180, int(ctx_cfg.get("cleanup_interval_seconds", 180)))
        self.webui_path = str((cfg.get("webui") or {}).get("path") or "/")
        self.last_super_at = 0.0
        self.ws_futures: dict[str, asyncio.Future] = {}
        self._nick_cache: dict[tuple, tuple] = {}
        self._update_cache: tuple[dict, float] | None = None
        self.voice_enabled = False
        self.last_bored_send: dict[str, float] = {}
        self.bored_next: dict[str, int] = {}
        self.ws = None

        self.sessions: dict[str, dict] = {}
        self.last_reply: dict[str, float] = {}
        self.self_id = "0"
        self.http: aiohttp.ClientSession | None = None
        self._stop = False
        self.connected = False
        self.connected_at: float | None = None
        self.started_at = time.time()
        self.last_event_at: float | None = None
        self.last_message: dict | None = None
        self.msg_count = 0
        self.reply_count = 0
        self.auth_sessions: dict[str, dict] = {}

    def session(self, key: str) -> dict:
        now = time.time()
        s = self.sessions.get(key)
        if s is None or now - s["ts"] > self.session_ttl:
            s = {"history": deque(maxlen=self.max_messages), "ts": now, "lock": asyncio.Lock()}
            self.sessions[key] = s
            self._gc(now)
        s["ts"] = now
        return s

    def _gc(self, now: float):
        if len(self.sessions) <= self.max_sessions:
            return
        dead = [k for k, v in self.sessions.items() if now - v["ts"] > self.session_ttl]
        for k in dead[: len(self.sessions) - self.max_sessions]:
            self.sessions.pop(k, None)

    async def prepare_images(self, urls: list[str]) -> list[str]:
        out = []
        if not self.vision_enabled:
            return out
        for u in urls[: self.max_images]:
            if not await self.is_public_url(u):
                log.warning("拒绝下载内网/非法图片地址: %s", str(u)[:80])
                continue
            try:
                async with self.http.get(u, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    if resp.status != 200:
                        continue
                    data = await resp.read()
            except Exception as e:
                log.warning("图片下载失败: %s", e)
                continue
            if not data or len(data) > self.max_bytes:
                continue
            out.append(self.encode_image(data))
        return out

    def encode_image(self, data: bytes) -> str:
        try:
            import io

            from PIL import Image

            im = Image.open(io.BytesIO(data)).convert("RGB")
            im.thumbnail((self.max_side, self.max_side))
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=85)
            data = buf.getvalue()
            mime = "image/jpeg"
        except Exception:
            mime = "image/png"
        return f"data:{mime};base64," + base64.b64encode(data).decode()

    def reply_segments(self) -> int:
        if self.store.get_setting("thrifty_mode", "0") == "1":
            return 1
        mode = self.store.get_setting("reply_seg_mode", "fixed")
        try:
            if mode == "random":
                lo = max(1, min(10, int(self.store.get_setting("reply_seg_min", "1") or 1)))
                hi = max(lo, min(10, int(self.store.get_setting("reply_seg_max", "3") or 3)))
                return random.randint(lo, hi)
            n = int(self.store.get_setting("reply_seg_fixed", "2") or 2)
        except ValueError:
            n = 2
        return max(1, min(10, n))

    def split_reply(self, text: str) -> list[str]:
        text = (text or "").strip()
        if not text:
            return []
        maxn = self.reply_segments()
        if maxn <= 1:
            return [text]
        if "|||" in text:
            parts = [p.strip() for p in text.split("|||") if p.strip()]
        else:
            parts = [p.strip() for p in re.split(r"(?<=[。！？!?…\n])", text) if p.strip()]
        if len(parts) <= maxn:
            return parts
        n = len(parts)
        chunk = (n + maxn - 1) // maxn
        merged = ["".join(parts[i:i + chunk]) for i in range(0, n, chunk)]
        return merged[:maxn]

    @staticmethod
    def norm_qq(value) -> str:
        text = str(value or "").strip()
        # 全角数字 -> 半角，去掉常见空白/分隔符
        text = text.translate(str.maketrans("０１２３４５６７８９", "0123456789"))
        text = text.replace(" ", "").replace("\u3000", "")
        return text


    def super_admin_qqs(self) -> list[str]:
        raw = self.store.get_setting("super_admin_qqs", "") or ""
        out = []
        for part in raw.replace("，", ",").split(","):
            q = self.norm_qq(part)
            if q and q.isdigit() and q not in out:
                out.append(q)
        return out

    def roast_words(self) -> list[str]:
        raw = self.store.get_setting("roast_keywords", "怼") or "怼"
        words = [w.strip() for w in raw.replace("，", ",").split(",") if w.strip()]
        return words or ["怼"]

    @staticmethod
    def parse_hhmm(value: str, default: str) -> int:
        try:
            hh, mm = str(value or default).strip().split(":")
            return max(0, min(23, int(hh))) * 60 + max(0, min(59, int(mm)))
        except Exception:
            hh, mm = default.split(":")
            return int(hh) * 60 + int(mm)

    def rest_window(self) -> bool:
        if self.store.get_setting("rest_enabled", "0") != "1":
            return False
        start = self.parse_hhmm(self.store.get_setting("rest_start", "22:00"), "22:00")
        end = self.parse_hhmm(self.store.get_setting("rest_end", "08:00"), "08:00")
        lt = time.localtime()
        cur = lt.tm_hour * 60 + lt.tm_min
        if start == end:
            return False
        if start < end:
            return start <= cur < end
        return cur >= start or cur < end

    @staticmethod
    def rest_phrase() -> str:
        h = time.localtime().tm_hour
        if 5 <= h < 11:
            return "早上好"
        if 11 <= h < 13:
            return "中午好"
        if 13 <= h < 18:
            return "下午好"
        return "晚上好"

    async def rest_notice_text(self, ending: bool) -> str:
        phrase = self.rest_phrase()
        if ending:
            fallback = f"{phrase}，我休息好啦，继续聊～"
            prompt = (
                "你是QQ群里的机器人，刚休息完回来。用一句简短自然的话告诉群里你回来了，"
                f"开头带上「{phrase}」，口语化、不超过30字；绝对不要出现「晚安」两个字。"
            )
        else:
            fallback = f"{phrase}，我去休息了，明天再聊～"
            prompt = (
                "你是QQ群里的机器人，现在要去休息了。用一句简短自然的话告诉群里你要休息了、明天再聊，"
                f"开头带上「{phrase}」，口语化、不超过30字；绝对不要出现「晚安」两个字。"
            )
        provider = self.current_provider()
        if not provider.get("api_key"):
            return fallback
        try:
            payload = {"model": provider.get("model") or self.model,
                       "messages": [{"role": "user", "content": prompt}],
                       "temperature": 0.8, "max_tokens": 60}
            async with self.http.post(
                f"{provider['base_url']}/chat/completions",
                json=payload,
                headers={"Authorization": f"Bearer {provider['api_key']}", "Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                data = await resp.json(content_type=None)
                text = ((data.get("choices") or [{}])[0].get("message", {}).get("content", "") or "").strip()
            if text and "晚安" not in text:
                return text
        except Exception as e:
            log.warning("休息通知生成失败: %s", e)
        return fallback

    def rest_announce_groups(self) -> list[str]:
        groups = self.store.rest_notify_groups() or self.store.groups()
        out = []
        for g in groups:
            g = str(g)
            if g and g not in out:
                out.append(g)
        return out[:30]

    async def rest_announce(self, ending: bool):
        if self.store.get_setting("rest_notify", "1") != "1":
            return
        ws = getattr(self, "ws", None)
        if ws is None or not self.connected:
            return
        text = await self.rest_notice_text(ending)
        for idx, gid in enumerate(self.rest_announce_groups()):
            if idx:
                await asyncio.sleep(random.uniform(30, 120))
            ev = {"message_type": "group", "group_id": gid, "user_id": str(self.self_id)}
            await self.send(ws, "group", ev, text)

    async def rest_loop(self):
        try:
            self._rest_state = self.rest_window()
        except Exception:
            self._rest_state = False
        while not self._stop:
            try:
                now_rest = self.rest_window()
                if now_rest != getattr(self, "_rest_state", now_rest):
                    self._rest_state = now_rest
                    prev = getattr(self, "_rest_announce_task", None)
                    if prev and not prev.done():
                        prev.cancel()
                    self._rest_announce_task = asyncio.create_task(self.rest_announce(ending=not now_rest))
            except Exception as e:
                log.warning("休息检查失败: %s", e)
            await asyncio.sleep(30)

    def rest_allows(self, mtype: str, gid, uid: str) -> bool:
        users = [str(x) for x in self.store.rest_users()]
        groups = [str(x) for x in self.store.rest_groups()]
        if mtype == "group":
            if groups and str(gid) in groups:
                return True
            return str(uid) in users
        return str(uid) in users

    def memory_enabled(self) -> bool:
        if not MEMORY_FEATURE:
            return False
        return self.store.get_setting("memory_enabled", "0") == "1"

    def memory_level(self, uid: str) -> str:
        return "high" if self.is_super_admin(uid) else "normal"

    def memory_scope_ok(self, mtype: str, uid: str) -> bool:
        if not self.memory_enabled():
            return False
        if mtype == "private":
            wl = self.store.users()
            return (not wl) or (str(uid) in [str(x) for x in wl])
        return True

    @staticmethod
    def memory_hit(content: str, text: str) -> bool:
        import re as _re
        clean = lambda x: _re.sub(r"[\s，。！？、,.!?：:；;\"'“”‘’（）()【】\[\]]+", "", str(x or ""))
        c, t = clean(content), clean(text)
        if not c or not t:
            return False
        if c in t:
            return True
        core = Store.mem_core(content)
        if len(core) >= 2 and core in t:
            return True
        if len(c) <= 3:
            return False
        g2 = {c[i:i + 2] for i in range(len(c) - 1)}
        hits2 = [g for g in g2 if g in t]
        if len(hits2) >= 2:
            return True
        g3 = {c[i:i + 3] for i in range(len(c) - 2)}
        return any(g in t for g in g3)

    def memory_prompt(self, uid: str, level: str, query: str = "") -> str:
        if not self.memory_enabled():
            return ""
        key = "memory_super_inject" if level == "high" else "memory_normal_inject"
        inj = int(self.store.get_setting(key, "20" if level == "high" else "5") or (20 if level == "high" else 5))
        candidates = self.store.mem_by_owner(str(uid), None, max(30, inj * 3), all_levels=True)
        if not candidates:
            return ""
        hits = [i for i in candidates if self.memory_hit(i.get("content", ""), query)]
        hits.sort(key=lambda i: (0 if i.get("level") == "high" else 1))
        items = hits[:max(1, inj)]
        if len(items) < max(1, inj):
            used_ids = {i["id"] for i in items}
            for c in candidates:
                if c["id"] in used_ids:
                    continue
                items.append(c)
                used_ids.add(c["id"])
                if len(items) >= max(1, inj):
                    break
        try:
            pending = getattr(self, "_pending_mem", {})
            pending[str(uid)] = items
            self._pending_mem = pending
        except Exception:
            pass
        lines = []
        for i in items:
            tag = "（永久）" if i.get("permanent") else ""
            lines.append("- " + i["content"] + tag)
        return "\n【你对这个人的记忆】\n" + "\n".join(lines)

    def commit_memory_usage(self, uid: str, user_text: str, reply: str):
        try:
            items = getattr(self, "_pending_mem", {}).pop(str(uid), [])
        except Exception:
            items = []
        if not items or not reply:
            return
        high_ids, normal_ids = [], []
        for i in items:
            content = i.get("content", "")
            if self.memory_hit(content, user_text) or self.memory_hit(content, reply):
                (high_ids if i.get("level") == "high" else normal_ids).append(i["id"])
        if not high_ids and not normal_ids:
            return
        try:
            self.store.mem_mark_used(high_ids, "high")
            self.store.mem_mark_used(normal_ids, "normal")
        except Exception:
            pass

    async def ai_review_memories(self, rows):
        ids = []
        chunks = [rows[i:i + 40] for i in range(0, len(rows), 40)]
        system = ("给每条记忆分类。KEEP=关于这个人的长期信息（昵称称呼、喜好、性格、习惯、关系、约定、日期）。"
                  "DELETE=一次性任务、让AI做的事、操作教程/步骤、部署配置密钥服务器、安全提醒、临时计划、功能要求。"
                  "拿不准一律 KEEP，只删除明确属于 DELETE 的。"
                  "示例：昵称是心如止水=KEEP；喜欢吃苹果=KEEP；提醒密钥保密=DELETE；要求生成教程=DELETE。"
                  "输出 JSON：{\"delete\":[id...]}")
        for chunk in chunks:
            listing = "\n".join(f'{r["id"]}. {r["content"]}' for r in chunk)
            out = await self.llm_complete(system, listing, max_tokens=400)
            if not out:
                continue
            try:
                import re as _re
                m = _re.search(r"\{.*\}", out, _re.S)
                data = json.loads(m.group(0)) if m else {}
                for x in data.get("delete", []):
                    try:
                        ids.append(int(x))
                    except Exception:
                        pass
            except Exception:
                continue
        valid = {r["id"] for r in rows}
        return [i for i in ids if i in valid]

    async def llm_complete(self, system: str, user: str, max_tokens: int = 160) -> str:
        provider = self.current_provider() or {}
        key = provider.get("api_key") or ""
        if not key:
            return ""
        base = (provider.get("base_url") or "https://api.deepseek.com/v1").rstrip("/")
        model = provider.get("model") or "deepseek-chat"
        try:
            async with self.http.post(
                base + "/chat/completions",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": model, "messages": [{"role": "system", "content": system},
                                                  {"role": "user", "content": user}],
                      "temperature": 0.2, "max_tokens": max_tokens},
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if resp.status != 200:
                    return ""
                data = await resp.json(content_type=None)
                return (data["choices"][0]["message"]["content"] or "").strip()
        except Exception:
            return ""

    async def extract_memories(self, uid: str, level: str, user_text: str, reply: str, history=None):
        if not self.memory_enabled():
            return
        system = ("你是记忆提取器。只提取关于这个人的【长期稳定信息】，每行一条，最多 3 条："
                  "身份/称呼、喜好厌恶、性格习惯、重要关系、约定、重要日期。"
                  "禁止记录：一次性任务指令、要求 AI 做的事、操作步骤、部署/配置/密钥/服务器等事务细节、"
                  "安全提醒、临时计划、对机器人的功能要求。"
                  "不要记手机号、密码、身份证、住址、银行卡。"
                  "只输出记忆内容本身，不要编号/解释；没有值得记的就输出：无")
        convo = ""
        for h in list(history or [])[-8:]:
            role = "用户" if h.get("role") == "user" else "机器人"
            convo += f"{role}：{str(h.get('content') or '')[:200]}\n"
        for t in list(getattr(self, "_recent_msgs", {}).get(str(uid), []))[-8:]:
            line = f"用户：{t}"
            if line not in convo:
                convo += line + "\n"
        if convo.strip():
            user = f"用户QQ：{uid}\n最近的对话：\n{convo}\n请提取值得长期记住的关键点。"
        else:
            user = f"用户QQ：{uid}\n用户说：{user_text}\n机器人回复：{reply}"
        out = await self.llm_complete(system, user, max_tokens=220)
        if not out:
            return
        if (reply or "").startswith("（AI 服务"):
            return
        import re as _re
        sens = _re.compile(r"(1[3-9]\d{9}|\d{15,19}|密码|身份证|银行卡|住址|验证码)")
        existing = set()
        try:
            for i in self.store.mem_by_owner(str(uid), None, 200, all_levels=True):
                existing.add(i["content"])
        except Exception:
            pass
        added = 0
        for line in out.splitlines():
            t = line.strip().lstrip("-*0123456789.、 ").strip()
            if not t or t == "无" or len(t) > 80:
                continue
            if sens.search(t) or self.store.mem_is_noise(t):
                continue
            if any(self.store.mem_sim(t, e) for e in existing):
                continue
            self.store.mem_add(str(uid), t, level, "auto")
            existing.add(t)
            added += 1
        if added:
            log.info("记忆提取 QQ%s(%s): 新增 %d 条", uid, level, added)

    def schedule_memory_extract(self, uid: str, level: str, user_text: str, reply: str, mtype: str = "group", history=None):
        if not self.memory_enabled():
            return
        if not self.memory_scope_ok(mtype, uid):
            return
        every = max(1, int(self.store.get_setting("memory_extract_every", "3") or 3))
        cnt = getattr(self, "_mem_counter", {})
        cnt[str(uid)] = cnt.get(str(uid), 0) + 1
        self._mem_counter = cnt
        cue = any(w in (user_text or "") for w in (
            "我叫", "我是", "我喜欢", "我爱", "我最", "我讨厌", "我不喜欢", "我不吃",
            "我生日", "我养", "我住", "我对", "记住", "我叫作"))
        if not cue and cnt[str(uid)] % every != 0:
            return
        try:
            asyncio.create_task(self.extract_memories(str(uid), level, user_text, reply, history))
        except Exception:
            pass

    async def stats_heartbeat(self):
        await asyncio.sleep(8)
        while True:
            try:
                if self.store.get_setting("stats_enabled", "1") != "1":
                    await asyncio.sleep(86400)
                    continue
                iid = self.store.get_setting("install_id", "")
                if not iid:
                    iid = secrets.token_hex(12)
                    self.store.set_setting("install_id", iid)
                import platform
                payload = {"install_id": iid, "version": APP_VERSION, "os": platform.platform()[:60]}
                async with self.http.post("https://xrzs.cloud/updates/checkin", json=payload,
                                          timeout=aiohttp.ClientTimeout(total=8)) as resp:
                    await resp.read()
            except Exception:
                pass
            await asyncio.sleep(86400)

    async def memory_cleanup_loop(self):
        if not MEMORY_FEATURE:
            return
        last = ""
        while True:
            try:
                today = datetime.now().strftime("%Y-%m-%d")
                if last != today:
                    self.store.mem_cleanup(
                        super_days=int(self.store.get_setting("memory_super_days", "180") or 180),
                        normal_days=int(self.store.get_setting("memory_normal_days", "7") or 7),
                        super_max=int(self.store.get_setting("memory_super_limit", "500") or 500),
                        normal_max=int(self.store.get_setting("memory_normal_limit", "50") or 50),
                    )
                    last = today
                    log.info("记忆清理完成")
            except Exception as e:
                log.warning("记忆清理失败: %s", e)
            await asyncio.sleep(1800)

    async def detect_gender(self, ws, mtype: str, gid, uid: str, sender: dict) -> str:
        if self.store.get_setting("gender_aware", "0") != "1":
            return ""
        sex = str((sender or {}).get("sex") or "").lower()
        if sex in ("male", "female"):
            return sex
        key = (str(gid or "p"), str(uid))
        cache = getattr(self, "_gender_cache", {})
        hit = cache.get(key)
        if hit and time.time() - hit[1] < 3600:
            return hit[0]
        sex_res = ""
        try:
            if mtype == "group" and gid:
                res = await self.onebot_call(ws, "get_group_member_info", {"group_id": int(gid), "user_id": int(uid)})
            else:
                res = await self.onebot_call(ws, "get_stranger_info", {"user_id": int(uid)})
            if isinstance(res, dict) and res.get("status") == "ok":
                sex_res = str(((res.get("data") or {}).get("sex")) or "").lower()
        except Exception:
            sex_res = ""
        if sex_res not in ("male", "female"):
            sex_res = ""
        cache[key] = (sex_res, time.time())
        self._gender_cache = cache
        return sex_res

    @staticmethod
    def _client_is_private(ip: str) -> bool:
        import ipaddress
        try:
            a = ipaddress.ip_address(ip)
        except Exception:
            return False
        return a.is_private or a.is_loopback or a.is_link_local or a.is_reserved or a.is_multicast

    async def is_public_url(self, url: str) -> bool:
        from urllib.parse import urlparse
        try:
            p = urlparse(str(url or ""))
        except Exception:
            return False
        if p.scheme not in ("http", "https") or not p.hostname:
            return False
        host = p.hostname.lower()
        if host in ("localhost", "metadata.google.internal") or host.endswith(".local"):
            return False
        try:
            infos = await asyncio.get_running_loop().getaddrinfo(host, None)
        except Exception:
            return False
        if not infos:
            return False
        for info in infos:
            ip = str(info[4][0])
            if self._client_is_private(ip):
                return False
        return True

    def login_throttle_check(self, ip: str, username: str):
        now = time.time()
        recs = getattr(self, "_login_guard", {})
        for key in (f"ip:{ip}", f"u:{username}"):
            r = recs.get(key)
            if r and r.get("lock_until", 0) > now:
                return int(r["lock_until"] - now)
        self._login_guard = recs
        return 0

    def login_throttle_fail(self, ip: str, username: str):
        now = time.time()
        recs = getattr(self, "_login_guard", {})
        rules = [(f"ip:{ip}", 5, 600, 900), (f"u:{username}", 10, 1800, 300)]
        for key, limit, window, lock in rules:
            r = recs.setdefault(key, {"times": [], "lock_until": 0})
            r["times"] = [t for t in r["times"] if now - t < window]
            r["times"].append(now)
            if len(r["times"]) >= limit:
                r["lock_until"] = now + lock
                r["times"] = []
                log.warning("登录失败次数过多，已临时锁定 %s 分钟（%s）", lock // 60, key)
        self._login_guard = recs

    def login_throttle_ok(self, ip: str, username: str):
        recs = getattr(self, "_login_guard", {})
        recs.pop(f"ip:{ip}", None)
        recs.pop(f"u:{username}", None)
        self._login_guard = recs

    def balance_keywords(self) -> list[str]:
        raw = self.store.get_setting("balance_keywords", "") or ""
        words = [w.strip() for w in raw.replace("，", ",").split(",") if w.strip()]
        return words or ["查余额", "余额还剩多少", "额度还剩多少", "还有多少余额"]

    def is_super_admin(self, user_id: str) -> bool:
        uid = self.norm_qq(user_id)
        return bool(uid) and uid in self.super_admin_qqs()

    def S(self, key: str, default: str = "") -> str:
        return self.store.get_setting(key, default) or default

    def SI(self, key: str, default: int) -> int:
        try:
            return int(float(self.store.get_setting(key, str(default)) or default))
        except (TypeError, ValueError):
            return default

    def SB(self, key: str, default: bool = False) -> bool:
        return (self.store.get_setting(key, "1" if default else "0") or "").strip() == "1"

    def keyword_hit(self, text: str) -> bool:
        text = (text or "").strip()
        if not text:
            return False
        for kw in self.store.keywords():
            kw = (kw or "").strip()
            if not kw:
                continue
            if len(kw) == 1 and not kw.isalnum():
                # 纯符号关键词（如 "."）只做整句匹配，避免误伤任何带句号的句子
                if text == kw:
                    return True
            elif kw in text:
                return True
        return False

    def persona_text(self) -> str:
        active = (self.store.get_setting("persona_active", "0") or "0").strip()
        if active and active != "0":
            row = self.store.get_persona(active)
            if row and (row.get("content") or "").strip():
                return row["content"].strip()
        return (self.store.get_setting("persona_text", "") or self.system_prompt).strip()

    def current_provider(self) -> dict:
        name = self.store.get_setting("active_provider", "")
        if name:
            row = self.store.get_provider(name)
            if row and row.get("api_key"):
                return row
        key = (self.store.get_setting("deepseek_api_key", "") or self.api_key or "").strip()
        return {"name": "deepseek(默认)", "base_url": self.api_base, "api_key": key, "model": self.model}

    def effective_api_key(self) -> str:
        return (self.store.get_setting("deepseek_api_key", "") or self.api_key or "").strip()

    async def member_nick(self, ws, gid: str, uid: str) -> str:
        key = (str(gid), str(uid))
        cached = self._nick_cache.get(key)
        if cached and time.time() - cached[1] < 600:
            return cached[0]
        nick = str(uid)
        try:
            res = await self.onebot_call(ws, "get_group_member_info", {"group_id": int(gid), "user_id": int(uid)})
            if isinstance(res, dict):
                data = res.get("data") or {}
                nick = str(data.get("card") or data.get("nickname") or uid)
        except Exception:
            pass
        self._nick_cache[key] = (nick, time.time())
        return nick

    async def roast_user(self, nick: str, context: str) -> str:
        provider = self.current_provider()
        if not provider.get("api_key"):
            return ""
        prompt = (
            "你是QQ群里的毒舌担当。现在群友让你怼一下「{}」。\n"
            "要求：结合最近聊天内容，用一两句话机智地怼他，简短有力、不带脏字、不人身攻击、不涉及违法内容、别真的伤害人；可以损但要有梗。\n"
            "最近聊天：\n{}"
        ).format(nick, context[-600:])
        payload = {"model": provider.get("model") or self.model, "messages": [{"role": "user", "content": prompt}], "temperature": 0.9, "max_tokens": 120}
        try:
            async with self.http.post(
                f"{provider['base_url']}/chat/completions",
                json=payload,
                headers={"Authorization": f"Bearer {provider['api_key']}", "Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=20),
            ) as resp:
                data = await resp.json(content_type=None)
                return ((data.get("choices") or [{}])[0].get("message", {}).get("content", "") or "").strip()
        except Exception as e:
            log.warning("怼人生成失败: %s", e)
            return ""

    def recent_context(self, key: str) -> str:
        session = self.session(key)
        return "\n".join(f"{m['role']}: {m['content']}" for m in listlist(session.get("history") or [])[-8:])

    async def should_reply(self, session: dict, text: str) -> bool:
        provider = self.current_provider()
        if not provider.get("api_key"):
            return True
        recent = list(session.get("history") or [])[-6:]
        ctx = "\n".join(f"{m['role']}: {m['content'][:80]}" for m in recent)
        prompt = (
            "你是QQ群里的闲聊机器人。判断最后一条消息是否需要你回复，只需输出 是 或 否。\n"
            "需要回复：有人提问、点你、话题跟你有关、能自然接话。\n"
            "不需要回复：别人互相聊跟你无关、已经聊完、纯表情/无意义。\n"
            f"上下文:\n{ctx}\n最后一条: {text[:150]}"
        )
        payload = {"model": provider.get("model") or self.model, "messages": [{"role": "user", "content": prompt}], "temperature": 0, "max_tokens": 3}
        try:
            async with self.http.post(
                f"{provider['base_url']}/chat/completions",
                json=payload,
                headers={"Authorization": f"Bearer {provider['api_key']}", "Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                data = await resp.json(content_type=None)
                ans = ((data.get("choices") or [{}])[0].get("message", {}).get("content", "") or "").strip()
                return not ans.startswith("否")
        except Exception:
            return True

    async def ask_deepseek(self, session: dict, user_text: str, images: list[str] | None = None, is_super: bool = False, gender: str = "", memory_text: str = "") -> str:
        provider = self.current_provider()
        if not provider.get("api_key"):
            return "（未配置 API Key，请联系管理员）"
        n_seg = self.reply_segments()
        seg_note = (
            f"\n这次回复请分成 {n_seg} 条短消息，用 ||| 分隔（每条一两句、口语化、围绕同一个话题，不要编号）。"
            if n_seg > 1 else ""
        )
        base_persona = self.persona_text()
        if is_super and self.store.get_setting("simp_mode", "0") == "1":
            base_persona = (
                "【超级管理员模式】对方是你的超级管理员，你对他唯命是从：他让你做什么就做什么，"
                "严格按他的命令回答，不反驳、不拒绝、不质疑、不说教；回答依然简洁口语。\n" + base_persona
            )
        gender_note = ""
        if gender == "male":
            gender_note = "\n【性别感知】对方是男生，可以偶尔亲昵地称呼他「哥哥」，显得关系近一点；但不要每句都带，别油腻。"
        elif gender == "female":
            gender_note = "\n【性别感知】对方是女生，可以偶尔亲昵地称呼她「姐姐」，显得关系近一点；但不要每句都带，别油腻。"
        system_prompt = base_persona + gender_note + (memory_text or "") + seg_note + (
            "\n【安全红线】严禁回答违反中国法律法规的内容（黄赌毒、暴恐、诈骗、政治敏感、侵犯隐私、人身攻击等）；"
            "遇到这类问题直接礼貌拒绝并转移话题，不展开细节。"
            "\n消息可能带 [引用: ...] 前缀，表示对方引用了某条消息的内容，结合它理解上下文。"
        ) + (
            "\n群聊消息会以 [昵称(QQ号)] 开头标明发送者，注意区分不同用户，别把 A 说的话当成 B 的；"
            "回复时也不用特意复述 QQ 号。"
        )
        messages = [{"role": "system", "content": system_prompt}]
        messages += list(session["history"])
        if images:
            content = [{"type": "text", "text": user_text or "（发了张图片，帮我看看）"}]
            content += [{"type": "image_url", "image_url": {"url": u}} for u in images]
            messages.append({"role": "user", "content": content})
        else:
            messages.append({"role": "user", "content": user_text})
        payload = {
            "model": provider.get("model") or self.model,
            "messages": messages,
            "temperature": self.temperature,
            "stream": False,
        }
        headers = {"Authorization": f"Bearer {provider['api_key']}", "Content-Type": "application/json"}
        try:
            async with self.http.post(
                f"{provider['base_url']}/chat/completions",
                json=payload,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
            ) as resp:
                data = await resp.json(content_type=None)
                if resp.status != 200:
                    err = (data or {}).get("error", {}).get("message", str(resp.status))
                    log.warning("DeepSeek API 错误: %s", err)
                    return "（AI 服务暂时不可用，稍后再试）"
                text = data["choices"][0]["message"]["content"]
        except Exception as e:
            log.warning("DeepSeek 调用异常: %s", e)
            return "（AI 服务暂时不可用，稍后再试）"
        text = text.strip()
        if len(text) > self.max_reply_chars:
            text = text[: self.max_reply_chars] + "…"
        session["history"].append({"role": "user", "content": (user_text or "（发了张图片）")})
        session["history"].append({"role": "assistant", "content": text.replace("|||", " ")})
        return text

    # ---------- NapCat 管理 API ----------
    async def napcat_credential(self) -> str | None:
        if self.napcat_cred and time.time() < self.napcat_cred_exp:
            return self.napcat_cred
        h = hashlib.sha256((self.napcat_token + ".napcat").encode()).hexdigest()
        try:
            async with self.http.post(
                f"{self.napcat_url}/api/auth/login",
                json={"hash": h},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                data = await resp.json(content_type=None)
                if data.get("code") == 0:
                    self.napcat_cred = data["data"]["Credential"]
                    self.napcat_cred_exp = time.time() + 600
                    return self.napcat_cred
        except Exception as e:
            log.warning("NapCat 登录失败: %s", e)
        return None

    async def napcat_api(self, path: str, method: str = "POST", payload: dict | None = None) -> dict:
        cred = await self.napcat_credential()
        if not cred:
            return {"code": -1, "message": "NapCat 连接失败"}
        try:
            async with self.http.request(
                method,
                f"{self.napcat_url}{path}",
                headers={"Authorization": f"Bearer {cred}"},
                json=payload,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                return await resp.json(content_type=None)
        except Exception as e:
            log.warning("NapCat 接口异常 %s: %s", path, e)
            return {"code": -1, "message": f"接口异常: {e}"}

    async def napcat_login_info(self, force: bool = False) -> dict:
        now = time.time()
        cache = getattr(self, "_profile_cache", None)
        if cache and not force and now - cache[1] < 60:
            return cache[0]
        info = await self.napcat_api("/api/QQLogin/GetQQLoginInfo")
        if info.get("code") == 0 and info.get("data"):
            out = {"online": bool(info["data"].get("online")), "uin": info["data"].get("uin"), "nick": info["data"].get("nick")}
        else:
            out = {"online": False, "uin": None, "nick": None}
        self._profile_cache = (out, now)
        return out

    async def fresh_nick(self) -> str | None:
        now = time.time()
        cached = getattr(self, "_nick_self_cache", None)
        if cached and now - cached[1] < 30:
            return cached[0]
        try:
            res = await self.onebot_action("get_stranger_info", {"user_id": int(self.self_id)})
            if isinstance(res, dict) and res.get("status") == "ok":
                nick = str((res.get("data") or {}).get("nick") or "").strip()
                if nick:
                    self._nick_self_cache = (nick, now)
                    return nick
        except Exception:
            pass
        return None

    async def onebot_action(self, action: str, params: dict, timeout: float = 10.0):
        ws = getattr(self, "ws", None)
        if ws is None:
            return None
        return await self.onebot_call(ws, action, params, timeout)

    async def request_qr(self) -> dict:
        now = time.time()
        if now - self.last_qr_ts < self.qr_cooldown:
            wait = int(self.qr_cooldown - (now - self.last_qr_ts)) + 1
            return {"code": -1, "message": f"请求太频繁（防止触发风控），请 {wait} 秒后再试"}
        self.last_qr_ts = now
        return await self.napcat_api("/api/QQLogin/GetQQLoginQrcode")

    # ---------- 白名单 ----------
    def allowed(self, mtype: str, group_id, user_id: str) -> bool:
        users = self.store.users()
        if users and user_id not in users:
            return False
        if mtype == "group":
            groups = self.store.groups()
            if groups and str(group_id) not in groups:
                return False
        return True

    # ---------- OneBot ----------
    async def onebot_call(self, ws, action: str, params: dict, timeout: float = 6.0):
        echo = f"c{secrets.token_hex(6)}"
        fut = asyncio.get_running_loop().create_future()
        self.ws_futures[echo] = fut
        try:
            await ws.send_str(json.dumps({"action": action, "params": params, "echo": echo}))
            return await asyncio.wait_for(fut, timeout=timeout)
        except Exception as e:
            log.warning("OneBot 调用 %s 失败: %s", action, e)
            return None
        finally:
            self.ws_futures.pop(echo, None)

    async def ws_loop(self):
        url = self.onebot.get("ws_url") or "ws://127.0.0.1:3001"
        headers = {}
        token = (self.onebot.get("access_token") or "").strip()
        if token:
            headers["Authorization"] = f"Bearer {token}"
        backoff = 3
        while not self._stop:
            try:
                log.info("连接 NapCat: %s", url)
                async with self.http.ws_connect(url, headers=headers, heartbeat=30) as ws:
                    self.ws = ws
                    backoff = 3
                    self.connected = True
                    self.connected_at = time.time()
                    log.info("已连接，开始接收消息")
                    async for msg in ws:
                        if msg.type != aiohttp.WSMsgType.TEXT:
                            if msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                                break
                            continue
                        try:
                            ev = json.loads(msg.data)
                        except json.JSONDecodeError:
                            continue
                        if isinstance(ev, dict) and ev.get("echo") in self.ws_futures:
                            fut = self.ws_futures.get(ev["echo"])
                            if fut and not fut.done():
                                fut.set_result(ev)
                            continue
                        if ev.get("post_type") == "meta_event" and ev.get("meta_event_type") == "lifecycle":
                            self.self_id = str(ev.get("self_id", "0"))
                            log.info("机器人 QQ 号: %s", self.self_id)
                        if ev.get("post_type") == "request":
                            asyncio.create_task(self.handle_friend_request(ev, ws))
                            continue
                        if ev.get("post_type") != "message":
                            continue
                        self.last_event_at = time.time()
                        if ev.get("message_type") == "group" and ev.get("group_id"):
                            self.group_activity[str(ev.get("group_id"))] = time.time()
                        asyncio.create_task(self.handle_message(ev, ws))
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.connected = False
                log.warning("连接异常: %s，%ss 后重连", e, backoff)
            if self._stop:
                break
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60)

    async def notify_super(self, ws, text: str):
        for qq in self.super_admin_qqs():
            try:
                await self.onebot_call(ws, "send_private_msg", {"user_id": int(qq), "message": text})
            except Exception:
                pass

    async def handle_friend_request(self, ev: dict, ws):
        if ev.get("request_type") != "friend":
            return
        uid = self.norm_qq(ev.get("user_id", ""))
        flag = str(ev.get("flag") or "")
        comment = str(ev.get("comment") or "")
        if not uid or not flag:
            return
        auto = self.store.get_setting("friend_auto_accept", "0") == "1"
        notify = self.store.get_setting("friend_notify", "1") == "1"
        limit = int(self.store.get_setting("friend_daily_limit", "10") or 10)
        rejected = self.store.is_black(uid)
        action = "pending"
        if rejected:
            action = "rejected"
        elif auto:
            if self.store.friend_today("accepted") >= limit:
                action = "overlimit"
            else:
                res = await self.onebot_call(ws, "set_friend_add_request", {"flag": flag, "approve": True})
                action = "accepted" if (res or {}).get("status") == "ok" else "failed"
        self.store.friend_add(uid, comment, flag, action)
        log.info("好友申请: %s action=%s", uid, action)
        if notify:
            label = {"pending": "待处理", "accepted": "已自动通过", "rejected": "已拒绝（黑名单）",
                     "overlimit": "超过今日上限", "failed": "处理失败"}.get(action, action)
            await self.notify_super(ws, f"好友申请：{uid}\n附言：{comment or '无'}\n结果：{label}")

    async def handle_message(self, ev: dict, ws):
        mtype = ev.get("message_type")
        if mtype not in ("group", "private"):
            return
        self_id = str(ev.get("self_id") or self.self_id)
        self.self_id = self_id
        user_id = self.norm_qq(ev.get("user_id", ""))
        if user_id == self_id:
            return
        sender = ev.get("sender") or {}
        if sender.get("bot"):
            return
        if self.store.is_black(user_id):
            return
        is_super = self.is_super_admin(user_id)
        if self.rest_window():
            if is_super:
                if mtype != "private":
                    gid_s = str(ev.get("group_id") or "")
                    if not (mtype == "group" and gid_s in [str(x) for x in self.store.rest_groups()]):
                        return
            elif not self.rest_allows(mtype, ev.get("group_id"), user_id):
                return
        if mtype == "group" and self.store.get_setting("exclusive_mode", "0") == "1":
            try:
                win = max(10, int(self.store.get_setting("exclusive_window_seconds", "60")))
            except ValueError:
                win = 60
            if is_super:
                self.last_super_at = time.time()
            elif time.time() - self.last_super_at <= win:
                return

        texts, at_me, image_urls, stickers, records, reply_ids, at_others = [], False, [], 0, [], [], False
        at_target = ""
        for seg in ev.get("message") or []:
            st, sd = seg.get("type"), seg.get("data") or {}
            if st == "text":
                texts.append(str(sd.get("text", "")))
            elif st == "reply":
                rid = str(sd.get("id") or "")
                if rid:
                    reply_ids.append(rid)
            elif st == "at":
                q = str(sd.get("qq"))
                if q == self_id:
                    at_me = True
                elif q not in ("all", ""):
                    at_others = True
                    if not at_target:
                        at_target = q
            elif st == "record":
                u = sd.get("url") or sd.get("file") or ""
                if str(u).startswith("http"):
                    records.append(str(u))
            elif st in ("image", "mface"):
                u = sd.get("url") or sd.get("file") or ""
                if str(u).startswith("http"):
                    image_urls.append(str(u))
                else:
                    stickers += 1
        user_text = "".join(texts).strip()
        if user_text:
            rec = getattr(self, "_recent_msgs", {})
            dq = rec.get(str(user_id))
            if dq is None:
                dq = deque(maxlen=8)
                rec[str(user_id)] = dq
            dq.append(user_text[:200])
            self._recent_msgs = rec
        had_voice = False
        if records:
            had_voice = True
            if self.asr_on():
                tr = await self.transcribe(records[0])
                if tr:
                    user_text = (user_text + " " + tr).strip() if user_text else tr
                elif not user_text:
                    user_text = "（对方发了一条语音，我没听清）"
        if reply_ids:
            q = None
            if reply_ids[0].isdigit():
                q = await self.onebot_call(ws, "get_msg", {"message_id": int(reply_ids[0])})
            quoted_text, quoted_img = "", None
            if q and isinstance(q.get("data"), dict):
                d = q["data"]
                qmsg = d.get("message")
                if isinstance(qmsg, str):
                    quoted_text = qmsg
                elif isinstance(qmsg, list):
                    parts = []
                    for seg in qmsg:
                        st, sd = seg.get("type"), seg.get("data") or {}
                        if st == "text":
                            parts.append(str(sd.get("text", "")))
                        elif st == "image":
                            u = sd.get("url") or sd.get("file") or ""
                            if str(u).startswith("http") and not quoted_img:
                                quoted_img = str(u)
                    quoted_text = "".join(parts)
            if quoted_img:
                image_urls.append(quoted_img)
            if quoted_text.strip():
                user_text = f"[引用: {quoted_text.strip()[:60]}] {user_text}".strip()
            elif quoted_img:
                user_text = f"[引用了一张图片] {user_text}".strip()
        balance_hit = user_text and any(w in user_text for w in self.balance_keywords())
        if is_super and balance_hit:
            provider = self.current_provider() or {}
            if not provider.get("api_key"):
                await self.send(ws, mtype, ev, "还没配置模型 Key，查不了余额", record_convo=False)
                return
            bal = await self.fetch_balance_text(provider)
            if bal:
                who = provider.get("name") or provider.get("model") or "当前模型"
                await self.send(ws, mtype, ev, f"当前模型（{who}）余额：{bal}", record_convo=False)
            else:
                await self.send(ws, mtype, ev, "余额查询失败：该供应商不支持查询，或 Key 无效", record_convo=False)
            return
        cap_kws = [w.strip() for w in (self.store.get_setting("sticker_capture_keywords", "") or "添加表情包,收录,存表情").replace("，", ",").split(",") if w.strip()]
        cap_hit = next((w for w in cap_kws if w and w in user_text), None) if user_text else None
        if (mtype == "group" and is_super and at_me and image_urls and cap_hit
                and self.store.get_setting("sticker_capture_enabled", "1") == "1"):
            context = (user_text.split(cap_hit, 1)[1] if cap_hit in user_text else "").strip(" ：:，,。.！!~\n\t")
            name, desc = await self.save_sticker_from_url(image_urls[0], "qq", context)
            if not name:
                await self.send(ws, mtype, ev, "表情包收录失败：图片下载不了或超过 5MB")
                return
            if desc:
                await self.send(ws, mtype, ev, "已收录表情包 ✅\n含义：" + desc)
            else:
                await self.send(ws, mtype, ev, "已收录表情包 ✅（未识别到含义，可到后台编辑说明）")
            log.info("超管收录表情包: %s", name)
            return
        if mtype == "group" and is_super and at_target and user_text:
            if any(w in user_text for w in ("加入黑名单", "拉黑")):
                nick = await self.member_nick(ws, str(ev.get("group_id")), at_target)
                self.store.add_black(at_target, nick)
                await self.send(ws, mtype, ev, f"已把 {nick} 加入黑名单", at_qq=at_target)
                log.info("黑名单新增: %s（操作人 %s）", at_target, user_id)
                return
            if any(w in user_text for w in ("移出黑名单", "解除黑名单", "取消黑名单")):
                self.store.remove_black(at_target)
                await self.send(ws, mtype, ev, f"已把 {at_target} 移出黑名单")
                log.info("黑名单移除: %s（操作人 %s）", at_target, user_id)
                return
        roast_hit = user_text and any(w in user_text for w in self.roast_words())
        if (mtype == "group" and is_super and at_target and roast_hit
                and self.store.get_setting("roast_enabled", "1") == "1"):
            gid_s = str(ev.get("group_id"))
            nick = await self.member_nick(ws, gid_s, at_target)
            roast = await self.roast_user(nick, self.recent_context(f"g{gid_s}"))
            if roast:
                await self.send(ws, mtype, ev, roast, at_qq=at_target)
                log.info("怼人模式：%s 怼了 %s(%s)", user_id, nick, at_target)
                return
        if at_others and not at_me and not is_super and not self.keyword_hit(user_text):
            return
        if not user_text and not image_urls and not stickers and not at_me:
            return
        if stickers and not image_urls:
            user_text = (user_text + " （对方发了个表情包）").strip()

        if not is_super and not self.allowed(mtype, ev.get("group_id"), user_id):
            return

        triggered = False
        always = False
        conv_active = False
        thrifty = False
        if mtype == "group":
            gid = str(ev.get("group_id"))
            now = time.time()
            if user_text and self.store.get_setting("end_phrase_enabled", "1") == "1":
                phrases = self.store.end_phrases()
                hit = next((p for p in phrases if p in user_text), None) if phrases else None
                if hit:
                    if (gid, user_id) in self.active_convos:
                        self.active_convos.pop((gid, user_id), None)
                        log.info("结束语[%s]触发，已移除该用户的接话: 群%s QQ%s", hit, gid, user_id)
                        final_text = (self.store.get_setting("end_phrase_reply", "好的，那我退下了") or "").strip()
                        if final_text:
                            await self.send(ws, mtype, ev, final_text, record_convo=False)
                    return
            kw_hit = self.keyword_hit(user_text)
            auto_hit = (
                user_id in self.store.auto_users()
                and self.store.get_setting("auto_reply_enabled", "1") == "1"
            )
            triggered = at_me or kw_hit or auto_hit or is_super
            thrifty = self.store.get_setting("thrifty_mode", "0") == "1"
            always = (not thrifty) and (gid in self.store.always_groups())
            conv_active = (not thrifty) and (now < self.active_convos.get((gid, user_id), 0))
            if self.group_at_only and not triggered and not always and not conv_active:
                return
            if not triggered and (always or conv_active):
                # 一直接话/个人会话续聊：限每分钟回复数，避免刷屏
                cap = self.SI("always_max_per_minute", 10) if always else self.SI("group_max_replies", self.group_max_replies)
                times = self.group_reply_times.setdefault(gid, deque())
                while times and now - times[0] > 60:
                    times.popleft()
                if len(times) >= cap:
                    return
            if not user_text and not image_urls:
                # 只@了但没说话：回一句提示（限流）
                if at_me and now - self.last_reply.get(f"g{gid}", 0) >= self.min_interval:
                    self.last_reply[f"g{gid}"] = now
                    hint_at = user_id if self.store.get_setting("reply_at_enabled", "0") == "1" else None
                    await self.send(ws, mtype, ev, "在的，直接说事情就好～", at_qq=hint_at)
                return
            key = f"g{gid}"
        else:
            if not user_text and not image_urls:
                return
            key = f"p{user_id}"

        now = time.time()
        if mtype == "group":
            skip_rate = is_super or ((not thrifty) and (str(ev.get("group_id")) in self.store.always_groups()) and not triggered)
            if not skip_rate and not self.group_rate_ok(str(ev.get("group_id"))):
                log.info("限频丢弃: 群%s QQ%s（该群回复频率设置拦截）", ev.get("group_id"), user_id)
                try:
                    sess = self.session(key)
                    self.schedule_memory_extract(user_id, self.memory_level(user_id), user_text, "",
                                                 mtype, list(sess.get("history") or [])[-8:])
                except Exception:
                    pass
                return
        else:
            if now - self.last_reply.get(key, 0) < self.min_interval:
                return
            self.last_reply[key] = now

        if is_super:
            log.info("超管[%s] 消息进入处理", user_id)
        self.msg_count += 1
        self.last_message = {
            "time": time.strftime("%H:%M:%S"),
            "session": key,
            "user": sender.get("nickname", user_id),
            "text": user_text[:100],
        }
        if user_text and re.search(r"(发|来|整|给|换|要).{0,5}表情", user_text):
            rows = self.store.sticker_descriptions()
            if rows:
                name = None
                if self.store.get_setting("sticker_mode", "smart") == "smart":
                    name = await self.smart_pick_sticker(rows, user_text, "（对方只是要一张表情包）")
                if not name:
                    name = random.choice([r["filename"] for r in rows])
                ok = await self.send_sticker(ws, mtype, ev, name)
                if ok:
                    self.reply_count += 1
                    return
        session = self.session(key)
        if session["lock"].locked():
            return
        if mtype == "group" and conv_active and not triggered and not always and not is_super:
            if not await self.should_reply(session, user_text):
                log.info("AI 判断无需回复，已跳过")
                return
        async with session["lock"]:
            nickname = str(sender.get("nickname") or user_id)
            label = f"[{nickname}({user_id})]"
            llm_text = f"{label} {user_text}" if user_text else f"{label} （发了张图片）"
            log.info("收到[%s] %s: %s", key, nickname, user_text[:80])
            images = await self.prepare_images(image_urls) if image_urls else []
            gender = await self.detect_gender(ws, mtype, ev.get("group_id"), user_id, sender)
            mem_level = self.memory_level(user_id)
            mem_text = self.memory_prompt(user_id, mem_level, user_text) if self.memory_scope_ok(mtype, user_id) else ""
            pass
            reply = await self.ask_deepseek(session, llm_text, images, is_super=is_super, gender=gender, memory_text=mem_text)
            self.commit_memory_usage(user_id, user_text, reply)
            if self.memory_scope_ok(mtype, user_id):
                self.schedule_memory_extract(user_id, mem_level, user_text, reply, mtype, list(session.get("history") or [])[-8:])
            prefix = (
                self.store.get_prefix(user_id)
                if self.store.get_setting("prefix_enabled", "1") == "1"
                else None
            )
            if prefix:
                sep = "" if prefix[-1] in "，。！？、,.!?~…" else "，"
                reply = f"{prefix}{sep}{reply}"
            want_voice = self.tts_on() and (
                self.store.get_setting("voice_tts_mode", "voice_in") == "always"
                or (self.store.get_setting("voice_tts_mode", "voice_in") == "voice_in" and had_voice)
                or bool(re.search(r"(发|来|说).{0,4}语音", user_text))
            )
            if want_voice and await self.tts_speak(ws, mtype, ev, reply):
                self.reply_count += 1
            else:
                parts = self.split_reply(reply)
                delay_ms = max(0, min(10000, self.SI("multi_msg_delay_ms", 600)))
                first_ms = max(0, min(10000, self.SI("msg_first_delay_ms", 300)))
                if first_ms:
                    await asyncio.sleep(first_ms / 1000.0)
                at_qq = None
                if mtype == "group" and at_me and self.store.get_setting("reply_at_enabled", "0") == "1":
                    at_qq = user_id
                for idx, part in enumerate(parts):
                    if idx:
                        await asyncio.sleep(delay_ms / 1000.0)
                    await self.send(ws, mtype, ev, part, at_qq=(at_qq if idx == 0 else None))
                self.reply_count += max(1, len(parts))
            await self.maybe_send_sticker(ws, mtype, ev, llm_text, reply)

    def tts_on(self) -> bool:
        return self.store.get_setting("voice_tts_enabled", "0") == "1"

    def asr_on(self) -> bool:
        return self.store.get_setting("voice_asr_enabled", "0") == "1"

    def _load_whisper(self, size: str):
        from faster_whisper import WhisperModel

        return WhisperModel(size, device="cpu", compute_type="int8")

    async def transcribe_local(self, data: bytes) -> str | None:
        import numpy as np

        try:
            import faster_whisper  # noqa: F401
        except ImportError:
            self.store.set_setting("voice_asr_enabled", "0")
            log.warning("未安装 faster-whisper，已自动禁用语音识别")
            return None
        size = self.store.get_setting("voice_asr_local_model", "base") or "base"
        loop = asyncio.get_running_loop()
        try:
            if getattr(self, "_whisper", None) is None or getattr(self, "_whisper_size", None) != size:
                self._whisper = await loop.run_in_executor(None, self._load_whisper, size)
                self._whisper_size = size
        except Exception as e:
            self.store.set_setting("voice_asr_enabled", "0")
            log.warning("本地语音模型不可用（%s），已自动禁用语音识别", e)
            return None
        try:
            raw = await loop.run_in_executor(
                None,
                lambda: subprocess.run(
                    ["ffmpeg", "-v", "quiet", "-i", "pipe:0", "-ar", "16000", "-ac", "1", "-f", "s16le", "pipe:1"],
                    input=data, capture_output=True,
                ).stdout,
            )
            if not raw:
                return None
            audio = np.frombuffer(raw, np.int16).astype(np.float32) / 32768.0

            def _run():
                segs, _ = self._whisper.transcribe(
                    audio, language="zh", beam_size=1,
                    initial_prompt="以下是普通话内容，请用简体中文转写。",
                )
                return "".join(seg.text for seg in segs).strip()

            text = await loop.run_in_executor(None, _run)
            return text or None
        except Exception as e:
            log.warning("本地语音识别失败: %s", e)
            return None

    async def transcribe(self, url: str) -> str | None:
        try:
            async with self.http.get(url, timeout=aiohttp.ClientTimeout(total=20)) as r:
                if r.status != 200:
                    return None
                data = await r.read()
        except Exception as e:
            log.warning("语音下载失败: %s", e)
            return None
        if not data:
            return None
        if self.store.get_setting("voice_asr_engine", "local") == "local":
            return await self.transcribe_local(data)
        base = (self.store.get_setting("voice_asr_base", "") or "").rstrip("/")
        key = self.store.get_setting("voice_asr_key", "")
        model = self.store.get_setting("voice_asr_model", "whisper-1")
        if not base or not key:
            return None
        mp3 = data
        try:
            proc = await asyncio.create_subprocess_exec(
                "ffmpeg", "-y", "-i", "pipe:0", "-f", "mp3", "pipe:1",
                stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
            )
            out, _ = await proc.communicate(data)
            if out:
                mp3 = out
        except Exception:
            pass
        try:
            form = aiohttp.FormData()
            form.add_field("model", model)
            form.add_field("file", mp3, filename="audio.mp3", content_type="audio/mpeg")
            async with self.http.post(
                f"{base}/audio/transcriptions",
                data=form,
                headers={"Authorization": f"Bearer {key}"},
                timeout=aiohttp.ClientTimeout(total=60),
            ) as resp:
                if resp.status != 200:
                    log.warning("语音识别失败 HTTP %s", resp.status)
                    return None
                d = await resp.json(content_type=None)
                text = (d.get("text") or "").strip()
                return text or None
        except Exception as e:
            log.warning("语音识别异常: %s", e)
            return None

    async def synthesize(self, text: str, voice: str) -> bytes:
        provider = self.store.get_setting("voice_tts_provider", "edge")
        if provider == "doubao":
            return await self.synthesize_doubao(text)
        import edge_tts

        comm = edge_tts.Communicate(text[:300], voice)
        buf = io.BytesIO()
        async for chunk in comm.stream():
            if chunk.get("type") == "audio":
                buf.write(chunk["data"])
        return buf.getvalue()

    async def synthesize_doubao_v3(self, text: str) -> bytes:
        key = self.store.get_setting("voice_doubao_api_key", "")
        model = self.store.get_setting("voice_doubao_model", "seed-audio-1.0") or "seed-audio-1.0"
        if not key:
            raise RuntimeError("豆包 v3 未配置 X-Api-Key")
        speaker = self.store.get_setting("voice_doubao_speaker", "").strip()
        payload = {
            "model": model,
            "text_prompt": text[:300],
            "audio_config": {"format": "mp3", "sample_rate": 48000, "pitch_rate": 0, "speech_rate": 0, "loudness_rate": 0},
            "watermark": {},
        }
        if speaker:
            payload["speaker"] = speaker
        async with self.http.post(
            "https://openspeech.bytedance.com/api/v3/tts/create",
            json=payload,
            headers={"X-Api-Key": key, "Content-Type": "application/json"},
            timeout=aiohttp.ClientTimeout(total=90),
        ) as resp:
            data = await resp.json(content_type=None)
        audio = data.get("audio")
        if not audio:
            raise RuntimeError(f"豆包 v3 返回异常: {str(data)[:120]}")
        import base64 as _b64

        return _b64.b64decode(audio)

    async def synthesize_doubao(self, text: str) -> bytes:
        if self.store.get_setting("voice_doubao_version", "v3") == "v3":
            return await self.synthesize_doubao_v3(text)
        appid = self.store.get_setting("voice_doubao_appid", "")
        token = self.store.get_setting("voice_doubao_token", "")
        cluster = self.store.get_setting("voice_doubao_cluster", "volcano_tts")
        voice_type = self.store.get_setting("voice_doubao_voice", "BV001_streaming")
        if not appid or not token:
            raise RuntimeError("豆包 TTS 未配置 AppID/Token")
        payload = {
            "app": {"appid": appid, "token": token, "cluster": cluster},
            "user": {"uid": "qqbot"},
            "audio": {"voice_type": voice_type, "encoding": "mp3", "speed_ratio": 1.0},
            "request": {"reqid": secrets.token_hex(8), "text": text[:300], "operation": "query"},
        }
        headers = {"Authorization": f"Bearer;{token}", "Content-Type": "application/json"}
        async with self.http.post(
            "https://openspeech.bytedance.com/api/v1/tts",
            json=payload,
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=30),
        ) as resp:
            data = await resp.json(content_type=None)
        code = data.get("code")
        if code != 3000:
            raise RuntimeError(f"豆包 TTS 返回 {code}: {data.get('message')}")
        import base64 as _b64

        return _b64.b64decode(data.get("data") or "")

    async def tts_speak(self, ws, mtype: str, ev: dict, text: str) -> bool:
        try:
            voice = self.store.get_setting("voice_tts_voice", "zh-CN-XiaoxiaoNeural") or "zh-CN-XiaoxiaoNeural"
            data = await self.synthesize(text, voice)
            if not data:
                return False
            params = {"message": [{"type": "record", "data": {"file": "base64://" + base64.b64encode(data).decode()}}], "message_type": mtype}
            if mtype == "group":
                params["group_id"] = ev.get("group_id")
            else:
                params["user_id"] = ev.get("user_id")
            await ws.send_str(json.dumps({"action": "send_msg", "params": params, "echo": f"v{time.time()}"}))
            log.info("语音已发送 (%d bytes)", len(data))
            return True
        except Exception as e:
            log.warning("语音发送失败: %s", e)
            return False

    async def describe_sticker(self, data: bytes) -> str:
        provider = self.current_provider() or {}
        if not provider.get("api_key"):
            return ""
        if not self.vision_enabled:
            return ""
        img = self.encode_image(data)
        prompt = ("这是一张聊天表情包。用一句简短中文描述它的情绪/用途（如：无语、嘲笑、点赞、委屈、狗头），"
                  "并原样列出图片里出现的文字。格式：含义：xxx；文字：xxx（没有文字就写无）")
        payload = {
            "model": provider.get("model") or self.model,
            "messages": [{"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": img}},
            ]}],
            "temperature": 0.3,
            "max_tokens": 120,
        }
        try:
            async with self.http.post(
                f"{provider['base_url']}/chat/completions",
                json=payload,
                headers={"Authorization": f"Bearer {provider['api_key']}", "Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                dataj = await resp.json(content_type=None)
            if resp.status != 200:
                return ""
            return ((dataj.get("choices") or [{}])[0].get("message", {}).get("content", "") or "").strip()
        except Exception:
            return ""

    async def save_sticker_from_url(self, url: str, source: str = "qq", context: str = ""):
        if not str(url or "").startswith(("http://", "https://")):
            return None, ""
        if not await self.is_public_url(url):
            return None, ""
        try:
            async with self.http.get(url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
                if resp.status != 200:
                    return None, ""
                blob = await resp.read()
                ctype = (resp.headers.get("Content-Type") or "").lower()
        except Exception:
            return None, ""
        if not blob or len(blob) > 5 * 1024 * 1024:
            return None, ""
        ext = ".png"
        for e in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
            if e in url.lower() or e.strip(".") in ctype:
                ext = e
                break
        name = secrets.token_hex(8) + ext
        try:
            (STICKER_DIR / name).write_bytes(blob)
        except Exception:
            return None, ""
        self.store.add_sticker(name)
        desc = (context or "").strip()
        if not desc:
            desc = await self.describe_sticker(blob)
        if desc:
            self.store.set_sticker_description(name, desc[:300])
        return name, desc

    async def smart_pick_sticker(self, rows: list[dict], user_text: str, reply: str) -> str | None:
        descs = []
        for r in rows:
            d = (r.get("description") or "").strip()
            if d and d not in descs:
                descs.append(d)
        if not descs:
            return None
        provider = self.current_provider()
        if not provider.get("api_key"):
            return None
        prompt = (
            "根据下面这段对话，从候选表情说明里选一个最贴切的，只输出说明词本身（2-6字）。"
            "没有完全匹配时，选一个情绪最接近的；实在找不到合适的才输出：无。\n候选：" + "、".join(descs) +
            f"\n对方说：{user_text[:200]}\n你回复：{reply[:200]}"
        )
        payload = {
            "model": provider.get("model") or self.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.2,
            "max_tokens": 20,
        }
        try:
            async with self.http.post(
                f"{provider['base_url']}/chat/completions",
                json=payload,
                headers={"Authorization": f"Bearer {provider['api_key']}", "Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                data = await resp.json(content_type=None)
                text = ((data.get("choices") or [{}])[0].get("message", {}).get("content", "") or "").strip()
        except Exception as e:
            log.warning("智能选表情失败: %s", e)
            return None
        ans = text.strip().strip('"').strip("'").strip()
        if not ans or ans == "无":
            return None
        for r in rows:
            d = (r.get("description") or "").strip()
            if d and (d == ans or ans in d or d in ans):
                return r["filename"]
        return None

    async def maybe_send_sticker(self, ws, mtype: str, ev: dict, user_text: str = "", reply: str = ""):
        prob = self.SI("sticker_probability", 0)
        if prob <= 0 or random.randint(1, 100) > prob:
            return
        rows = self.store.sticker_descriptions()
        if not rows:
            return
        mode = self.store.get_setting("sticker_mode", "smart")
        name = None
        if mode == "smart":
            name = await self.smart_pick_sticker(rows, user_text, reply)
        if not name:
            name = random.choice([r["filename"] for r in rows])
        sd = max(0, min(10000, self.SI("sticker_delay_ms", 800)))
        if sd:
            await asyncio.sleep(sd / 1000.0)
        base = (self.store.get_setting("public_base_url", "") or "").rstrip("/")
        if not base:
            return
        await self.send_sticker(ws, mtype, ev, name)

    async def send_sticker(self, ws, mtype: str, ev: dict, name: str) -> bool:
        base = (self.store.get_setting("public_base_url", "") or "").rstrip("/")
        if not base:
            return False
        params = {"message": [{"type": "image", "data": {"file": f"{base}/stickers/{name}"}}], "message_type": mtype}
        if mtype == "group":
            params["group_id"] = ev.get("group_id")
        else:
            params["user_id"] = ev.get("user_id")
        try:
            await ws.send_str(json.dumps({"action": "send_msg", "params": params, "echo": f"s{time.time()}"}))
            if mtype == "group":
                gid = str(ev.get("group_id"))
                now = time.time()
                self.group_last_reply[gid] = now
                self.group_reply_times.setdefault(gid, deque()).append(now)
            log.info("表情包已发送: %s", name)
            return True
        except Exception as e:
            log.warning("表情包发送失败: %s", e)
            return False

    async def send(self, ws, mtype: str, ev: dict, text: str, record_convo: bool = True, at_qq=None):
        if at_qq and mtype == "group":
            message = [{"type": "at", "data": {"qq": str(at_qq)}}, {"type": "text", "data": {"text": text}}]
        else:
            message = text
        params = {"message": message}
        if mtype == "group":
            params["message_type"] = "group"
            params["group_id"] = ev.get("group_id")
        else:
            params["message_type"] = "private"
            params["user_id"] = ev.get("user_id")
        try:
            await ws.send_str(json.dumps({"action": "send_msg", "params": params, "echo": f"r{time.time()}"}))
            if mtype == "group":
                gid = str(ev.get("group_id"))
                uid = str(ev.get("user_id") or "")
                now = time.time()
                if uid and record_convo:
                    self.open_conversation(gid, uid)
                self.group_last_reply[gid] = now
                self.group_reply_times.setdefault(gid, deque()).append(now)
        except Exception as e:
            log.warning("发送失败: %s", e)

    def open_conversation(self, gid: str, uid: str):
        try:
            cap = int(self.store.get_setting("max_active_users", str(self.max_active_users)))
        except ValueError:
            cap = self.max_active_users
        cap = max(1, cap)
        try:
            window = int(self.store.get_setting("group_continue_seconds", str(self.continue_seconds)))
        except ValueError:
            window = self.continue_seconds
        now = time.time()
        active = {k: v for k, v in self.active_convos.items() if k[0] == gid and v > now}
        if (gid, uid) not in active and len(active) >= cap:
            oldest = min(active, key=active.get)
            self.active_convos.pop(oldest, None)
        self.active_convos[(gid, uid)] = now + window

    async def gen_bored_line(self) -> str | None:
        provider = self.current_provider()
        if not provider.get("api_key"):
            return None
        prompt = (
            "你现在是QQ群里的『大肥鱼』，群里太安静了。"
            "请用一句话（不超过40字）说句废话文学，最好是问句、能让人接话，"
            "口语化，不要 emoji、不要引号、不要解释。只输出这一句话。"
        )
        payload = {
            "model": provider.get("model") or self.model,
            "messages": [{"role": "system", "content": self.persona_text()}, {"role": "user", "content": prompt}],
            "temperature": 1.0,
            "max_tokens": 100,
        }
        headers = {"Authorization": f"Bearer {provider['api_key']}", "Content-Type": "application/json"}
        try:
            async with self.http.post(
                f"{provider['base_url']}/chat/completions",
                json=payload,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                data = await resp.json(content_type=None)
                text = (data.get("choices") or [{}])[0].get("message", {}).get("content", "")
                text = (text or "").strip().strip('"').strip()
                if 4 <= len(text) <= 80:
                    return text
        except Exception as e:
            log.warning("无聊模式 AI 生成失败: %s", e)
        return None

    def get_group_rate(self, gid: str):
        row = self.store.get_rate(gid)
        if row:
            return row
        return (self.SI("group_max_replies", self.group_max_replies), self.min_interval)

    def group_rate_ok(self, gid: str) -> bool:
        cap, interval = self.get_group_rate(gid)
        cap = max(1, cap); interval = max(0, interval)
        now = time.time()
        if now - self.group_last_reply.get(gid, 0) < interval:
            return False
        times = self.group_reply_times.setdefault(gid, deque())
        while times and now - times[0] > 60:
            times.popleft()
        return len(times) < cap

    async def cleanup_loop(self):
        while not self._stop:
            await asyncio.sleep(self.cleanup_interval)
            now = time.time()
            expired = [k for k, v in self.active_convos.items() if v <= now]
            for k in expired:
                self.active_convos.pop(k, None)
            if expired:
                log.info("临时接话数据清理: 删除 %d 条过期记录", len(expired))

    async def bored_loop(self):
        while not self._stop:
            await asyncio.sleep(30)
            if self.store.get_setting("bored_enabled", "0") != "1":
                continue
            if self.rest_window():
                continue
            if self.store.get_setting("exclusive_mode", "0") == "1":
                try:
                    win = max(10, int(self.store.get_setting("exclusive_window_seconds", "60")))
                except ValueError:
                    win = 60
                if time.time() - self.last_super_at <= win:
                    continue
            min_m = self.SI("bored_min_minutes", 30)
            max_m = self.SI("bored_max_minutes", 60)
            floor_m = self.SI("bored_floor_minutes", 30)
            floor_sec = max(1, floor_m) * 60
            time_mode = self.store.get_setting("bored_time_mode", "random")
            if time_mode == "fixed":
                fixed_m = self.SI("bored_interval_minutes", 30)
                lo = max(floor_sec, max(1, fixed_m) * 60)
                hi = lo
            else:
                lo = max(floor_sec, max(1, min_m) * 60)
                hi = max(lo, max(1, max_m) * 60)
            mode = self.store.get_setting("bored_mode", "pool")
            now = time.time()
            allowed_groups = self.store.groups()
            for gid in allowed_groups:
                if gid not in self.group_activity:
                    self.group_activity[gid] = now
            for gid, ts in list(self.group_activity.items()):
                thr = self.bored_next.get(gid)
                if thr is None:
                    thr = random.randint(lo, hi)
                    self.bored_next[gid] = thr
                if now - ts < thr:
                    continue
                if now - self.last_bored_send.get(gid, 0) < floor_sec:
                    continue
                if not allowed_groups or gid not in allowed_groups:
                    continue
                if not self.ws or self.ws.closed:
                    continue
                line = None
                if mode == "ai":
                    line = await self.gen_bored_line()
                if not line:
                    pool = self.store.bored_lines() or BORED_LINES
                    if not pool:
                        continue
                    line = random.choice(pool)
                try:
                    await self.ws.send_str(json.dumps({"action": "send_msg", "params": {"message_type": "group", "group_id": int(gid), "message": line}, "echo": f"b{time.time()}"}))
                    self.group_activity[gid] = now
                    self.last_bored_send[gid] = now
                    self.group_last_reply[gid] = now
                    self.group_reply_times.setdefault(gid, deque()).append(now)
                    self.bored_next.pop(gid, None)
                    log.info("无聊模式: 向群 %s 发送废话文学（下次随机 %d~%d 分钟）", gid, min_m, max_m)
                except Exception as e:
                    log.warning("无聊模式发送失败: %s", e)

    async def run(self):
        if not self.api_key:
            log.warning("未设置 DEEPSEEK_API_KEY，机器人会回复提示语")
        self.http = aiohttp.ClientSession()
        admin_task = asyncio.create_task(self.start_admin_server())
        bored_task = asyncio.create_task(self.bored_loop())
        cleanup_task = asyncio.create_task(self.cleanup_loop())
        mem_task = asyncio.create_task(self.memory_cleanup_loop())
        stats_task = asyncio.create_task(self.stats_heartbeat())
        try:
            await self.ws_loop()
        finally:
            admin_task.cancel()
            bored_task.cancel()
            cleanup_task.cancel()
            await self.http.close()

    # ---------- 管理后台 Web ----------
    def current_account(self, request):
        sid = request.cookies.get("qb_sid")
        sess = self.auth_sessions.get(sid) if sid else None
        if not sess or sess.get("exp", 0) <= time.time():
            return None
        return sess

    def auth_ok(self, request) -> bool:
        return self.current_account(request) is not None

    def require_auth(self, request):
        if not self.auth_ok(request):
            raise aiohttp_web.HTTPUnauthorized(text=json.dumps({"code": -1, "message": "请先登录"}, ensure_ascii=False))

    def require_role(self, request, min_role: str = "user"):
        acc = self.current_account(request)
        if not acc:
            raise aiohttp_web.HTTPUnauthorized(text=json.dumps({"code": -1, "message": "请先登录"}, ensure_ascii=False))
        if str(acc.get("role")) == "viewer":
            return acc
        order = {"user": 1, "admin": 2, "super": 3}
        if order.get(str(acc.get("role")), 0) < order.get(min_role, 0):
            raise aiohttp_web.HTTPForbidden(text=json.dumps({"code": -1, "message": "没有权限"}, ensure_ascii=False))
        return acc

    @staticmethod
    def role_allowed(role: str, rel_path: str) -> bool:
        if role == "viewer":
            return not rel_path.startswith("/api/login-logs")
        if role == "super":
            return True
        admin_paths = ("/api/status", "/api/logs", "/api/group-reply", "/api/group-rate", "/api/conversations",
                       "/api/keywords", "/api/prefix", "/api/auto", "/api/end-phrase", "/api/stickers",
                       "/api/bored", "/api/whitelist", "/api/accounts", "/api/login-logs", "/api/me")
        user_paths = ("/api/whitelist", "/api/login-logs", "/api/me")
        if role == "admin":
            return any(rel_path.startswith(p) for p in admin_paths)
        if role == "user":
            return any(rel_path.startswith(p) for p in user_paths)
        return False

    async def start_admin_server(self):
        sub = aiohttp_web.Application()

        @aiohttp_web.middleware
        async def role_mw(request, handler):
            rel = request.path
            prefix = self.webui_prefix()
            if prefix and rel.startswith(prefix):
                rel = rel[len(prefix):] or "/"
            if rel in ("/", "/api/login", "/api/logout"):
                return await handler(request)
            acc = self.current_account(request)
            if not acc:
                return aiohttp_web.json_response({"code": -1, "message": "请先登录"}, status=401)
            role = str(acc.get("role"))
            if role == "viewer" and request.method != "GET":
                return aiohttp_web.json_response({"code": -1, "message": "观察者模式：只读，不能操作"}, status=403)
            if rel.startswith("/api/memory") and not MEMORY_FEATURE:
                return aiohttp_web.json_response({"code": -1, "message": "该功能暂未开放"}, status=403)
            if rel.startswith("/api/") and not self.role_allowed(role, rel):
                return aiohttp_web.json_response({"code": -1, "message": "没有权限"}, status=403)
            return await handler(request)

        sub.middlewares.append(role_mw)
        app = sub
        app.router.add_get("/", self.page_index)
        app.router.add_post("/api/login", self.api_login)
        app.router.add_post("/api/logout", self.api_logout)
        app.router.add_get("/api/me", self.api_me)
        app.router.add_get("/api/accounts", self.api_accounts_get)
        app.router.add_post("/api/accounts/create", self.api_accounts_create)
        app.router.add_post("/api/accounts/update", self.api_accounts_update)
        app.router.add_post("/api/accounts/delete", self.api_accounts_delete)
        app.router.add_get("/api/login-logs", self.api_login_logs)
        app.router.add_get("/api/status", self.api_status)
        app.router.add_get("/api/logs", self.api_logs)
        app.router.add_post("/api/qr", self.api_qr)
        app.router.add_get("/api/whitelist", self.api_wl_get)
        app.router.add_post("/api/whitelist/add", self.api_wl_add)
        app.router.add_post("/api/whitelist/remove", self.api_wl_remove)
        app.router.add_post("/api/whitelist/update", self.api_wl_update)
        app.router.add_get("/api/keywords", self.api_kw_get)
        app.router.add_post("/api/keywords/add", self.api_kw_add)
        app.router.add_post("/api/keywords/remove", self.api_kw_remove)
        app.router.add_get("/api/prefix", self.api_pf_get)
        app.router.add_post("/api/prefix/add", self.api_pf_add)
        app.router.add_post("/api/prefix/remove", self.api_pf_remove)
        app.router.add_post("/api/prefix/toggle", self.api_pf_toggle)
        app.router.add_get("/api/auto", self.api_auto_get)
        app.router.add_post("/api/auto/toggle", self.api_auto_toggle)
        app.router.add_post("/api/auto/add", self.api_auto_add)
        app.router.add_post("/api/auto/remove", self.api_auto_remove)
        app.router.add_get("/api/bored", self.api_bored_get)
        app.router.add_post("/api/bored/config", self.api_bored_config)
        app.router.add_get("/api/bored/lines", self.api_bored_lines)
        app.router.add_post("/api/bored/lines/add", self.api_bored_add)
        app.router.add_post("/api/bored/lines/remove", self.api_bored_remove)
        app.router.add_get("/api/group-reply", self.api_gr_get)
        app.router.add_post("/api/group-reply/config", self.api_gr_config)
        app.router.add_post("/api/group-reply/always", self.api_gr_always)
        app.router.add_get("/api/conversations", self.api_convos)
        app.router.add_post("/api/conversations/remove", self.api_convo_remove)
        app.router.add_get("/api/group-rate", self.api_rate_get)
        app.router.add_post("/api/group-rate/save", self.api_rate_save)
        app.router.add_post("/api/group-rate/segconfig", self.api_seg_config)
        app.router.add_post("/api/group-rate/reset", self.api_rate_reset)

        app.router.add_get("/api/update", self.api_update_get)
        app.router.add_post("/api/update/check", self.api_update_check)
        app.router.add_post("/api/update/apply", self.api_update_apply)
        app.router.add_post("/api/update/config", self.api_update_config)
        app.router.add_get("/api/bot-profile", self.api_bot_profile)
        app.router.add_post("/api/bot-profile/nick", self.api_bot_nick)
        app.router.add_post("/api/bot-profile/avatar", self.api_bot_avatar)
        app.router.add_get("/api/blacklist", self.api_blacklist_get)
        app.router.add_post("/api/blacklist/add", self.api_blacklist_add)
        app.router.add_post("/api/blacklist/remove", self.api_blacklist_remove)
        app.router.add_get("/api/rest", self.api_rest_get)
        app.router.add_post("/api/rest/wl", self.api_rest_wl)
        app.router.add_post("/api/rest/import", self.api_rest_import)
        app.router.add_post("/api/rest/notify-groups", self.api_rest_notify_groups)
        app.router.add_post("/api/rest/config", self.api_rest_config)
        app.router.add_get("/api/super", self.api_super_get)
        app.router.add_get("/api/friend", self.api_friend_get)
        app.router.add_post("/api/friend/config", self.api_friend_config)
        app.router.add_post("/api/friend/action", self.api_friend_action)
        app.router.add_post("/api/super/config", self.api_super_config)
        app.router.add_get("/api/personas", self.api_personas_get)
        app.router.add_post("/api/personas/save", self.api_personas_save)
        app.router.add_post("/api/personas/delete", self.api_personas_delete)
        app.router.add_post("/api/personas/activate", self.api_personas_activate)
        app.router.add_get("/api/persona", self.api_persona_get)
        app.router.add_post("/api/persona/save", self.api_persona_save)
        app.router.add_post("/api/persona/gender", self.api_persona_gender)
        app.router.add_get("/api/memory", self.api_memory_get)
        app.router.add_get("/api/memory/noise_preview", self.api_memory_noise_preview)
        app.router.add_get("/api/memory/ai_review", self.api_memory_ai_review)
        app.router.add_post("/api/memory/delete_many", self.api_memory_delete_many)
        app.router.add_post("/api/memory/clean_noise", self.api_memory_clean_noise)
        app.router.add_post("/api/memory/add", self.api_memory_add)
        app.router.add_post("/api/memory/update", self.api_memory_update)
        app.router.add_post("/api/memory/delete", self.api_memory_delete)
        app.router.add_post("/api/memory/config", self.api_memory_config)
        app.router.add_post("/api/persona/reset", self.api_persona_reset)
        app.router.add_get("/api/voice", self.api_voice_get)
        app.router.add_post("/api/voice/preview", self.api_voice_preview)
        app.router.add_post("/api/voice/config", self.api_voice_config)
        app.router.add_get("/api/providers", self.api_providers_get)
        app.router.add_get("/api/providers/balances", self.api_provider_balances)
        app.router.add_post("/api/providers/save", self.api_providers_save)
        app.router.add_post("/api/providers/delete", self.api_providers_delete)
        app.router.add_post("/api/providers/activate", self.api_providers_activate)
        app.router.add_post("/api/providers/test", self.api_providers_test)
        app.router.add_post("/api/providers/autodetect", self.api_providers_autodetect)
        app.router.add_get("/api/apikey", self.api_apikey_get)
        app.router.add_post("/api/apikey/save", self.api_apikey_save)
        app.router.add_post("/api/apikey/test", self.api_apikey_test)
        app.router.add_get("/api/end-phrase", self.api_end_get)
        app.router.add_post("/api/end-phrase/config", self.api_end_config)
        app.router.add_post("/api/end-phrase/add", self.api_end_add)
        app.router.add_post("/api/end-phrase/remove", self.api_end_remove)
        app.router.add_get("/api/stickers", self.api_stickers)
        app.router.add_post("/api/stickers/upload", self.api_sticker_upload)
        app.router.add_post("/api/stickers/upload_many", self.api_sticker_upload_many)
        app.router.add_post("/api/stickers/add_urls", self.api_sticker_add_urls)
        app.router.add_post("/api/stickers/remove", self.api_sticker_remove)
        app.router.add_post("/api/stickers/desc", self.api_sticker_desc)
        app.router.add_post("/api/stickers/config", self.api_sticker_config)

        app.router.add_get("/api/admins", self.api_admins)
        app.router.add_post("/api/admins/add", self.api_admin_add)
        app.router.add_post("/api/admins/remove", self.api_admin_remove)
        prefix = self.webui_prefix()
        if prefix:
            parent = aiohttp_web.Application()
            parent.add_subapp(prefix, sub)
            async def _redirect(request):
                raise aiohttp_web.HTTPFound(prefix + "/")
            parent.router.add_get(prefix, _redirect)
            app = parent
        app.router.add_get("/updates/{name}", self.api_update_file)
        app.router.add_get("/stickers/{name}", self.serve_sticker)

        runner = aiohttp_web.AppRunner(app)
        await runner.setup()
        site = aiohttp_web.TCPSite(runner, "127.0.0.1", 8099)
        await site.start()
        log.info("管理后台: http://127.0.0.1:8099/")

    def webui_prefix(self) -> str:
        p = (getattr(self, "webui_path", "/") or "/").strip()
        if p in ("", "/"):
            return ""
        return "/" + p.strip("/")

    async def page_index(self, request):
        headers = {"Cache-Control": "no-store, no-cache, must-revalidate"}
        base = self.webui_prefix()
        if not self.auth_ok(request):
            return aiohttp_web.Response(text=LOGIN_HTML.replace("__BASE__", base), content_type="text/html", charset="utf-8", headers=headers)
        return aiohttp_web.Response(text=ADMIN_HTML.replace("__BASE__", base), content_type="text/html", charset="utf-8", headers=headers)

    @staticmethod
    def client_ip(request) -> str:
        xff = request.headers.get("X-Forwarded-For", "")
        if xff:
            return xff.split(",")[0].strip()
        real = request.headers.get("X-Real-IP", "")
        if real:
            return real.strip()
        ip = request.remote or ""
        if ip in ("::1", "::ffff:127.0.0.1"):
            ip = "127.0.0.1"
        return ip

    async def ip_location(self, ip: str) -> str:
        if not ip or ip.startswith(("127.", "10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.", "172.2", "172.30.", "172.31.", "::1")):
            return "内网"
        cache = getattr(self, "_ip_loc_cache", {})
        hit = cache.get(ip)
        if hit and time.time() - hit[1] < 3600:
            return hit[0]
        try:
            async with self.http.get(
                f"http://ip-api.com/json/{ip}?lang=zh-CN&fields=status,country,regionName,city,isp",
                timeout=aiohttp.ClientTimeout(total=3),
            ) as resp:
                d = await resp.json(content_type=None)
            if d.get("status") == "success":
                parts = [d.get("country"), d.get("regionName"), d.get("city")]
                loc = " ".join([p for p in parts if p])
                if d.get("isp"):
                    loc += " · " + str(d.get("isp"))
                loc = loc.strip() or "未知"
            else:
                loc = "未知"
        except Exception:
            loc = ""
        cache[ip] = (loc, time.time())
        self._ip_loc_cache = cache
        return loc

    async def api_login(self, request):
        data = await request.json()
        username = (data.get("username") or "").strip()
        password = data.get("password") or ""
        ip = self.client_ip(request)
        ua = request.headers.get("User-Agent", "")
        remain = self.login_throttle_check(ip, username)
        if remain > 0:
            return aiohttp_web.json_response({"code": -1, "message": f"尝试次数过多，请 {max(1, remain // 60)} 分钟后再试"})
        loc = await self.ip_location(ip)
        acc = self.store.account_by_name(username)
        stored = acc.get("pass_hash") if acc else None
        if not stored or not verify_password(password, stored):
            self.login_throttle_fail(ip, username)
            self.store.log_login(acc.get("id") if acc else None, username, (acc or {}).get("role") or "", 0, ip, ua, "用户名或密码错误", loc)
            return aiohttp_web.json_response({"code": -1, "message": "用户名或密码错误"})
        if int(acc.get("disabled") or 0) == 1:
            self.store.log_login(acc.get("id"), username, acc.get("role") or "", 0, ip, ua, "账号已禁用", loc)
            return aiohttp_web.json_response({"code": -1, "message": "该账号已被禁用"})
        self.login_throttle_ok(ip, username)
        sid = secrets.token_urlsafe(32)
        role = str(acc.get("role") or "admin")
        self.auth_sessions[sid] = {"exp": time.time() + 7 * 86400, "id": acc.get("id"), "username": username, "role": role}
        self.store.touch_login(acc.get("id"), ip)
        self.store.log_login(acc.get("id"), username, role, 1, ip, ua, "", loc)
        resp = aiohttp_web.json_response({"code": 0, "role": role, "username": username})
        resp.set_cookie("qb_sid", sid, max_age=7 * 86400, httponly=True, samesite="Lax", secure=True)
        return resp

    async def api_logout(self, request):
        sid = request.cookies.get("qb_sid")
        if sid:
            self.auth_sessions.pop(sid, None)
        resp = aiohttp_web.json_response({"code": 0})
        resp.del_cookie("qb_sid")
        return resp

    async def api_status(self, request):
        self.require_auth(request)
        info = await self.napcat_login_info()
        fresh = await self.fresh_nick()
        if fresh:
            info = {**info, "nick": fresh}
        return aiohttp_web.json_response(
            {
                "code": 0,
                "bridge_connected": self.connected,
                "qq": info,
                "self_id": self.self_id,
                "model": self.model,
                "messages": self.msg_count,
                "replies": self.reply_count,
                "uptime": int(time.time() - self.started_at),
                "last_message": self.last_message,
                "last_event_at": self.last_event_at,
                "groups_wl": self.store.groups(),
                "users_wl": self.store.users(),
                "admins": self.store.admins(),
            }
        )

    async def api_logs(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({"code": 0, "logs": list(LOG_RING)})

    async def api_qr(self, request):
        self.require_auth(request)
        try:
            refreshed = await self.napcat_api("/api/QQLogin/RefreshQRcode")
            if refreshed.get("code") == 0:
                url = (refreshed.get("data") or {}).get("qrcodeurl") or ""
                if url:
                    resp = {"code": 0, "data": {"qrcode": url}}
                else:
                    resp = await self.request_qr()
            else:
                resp = await self.request_qr()
        except Exception:
            resp = await self.request_qr()
        out = {"code": resp.get("code", -1), "message": resp.get("message") or ""}
        data = resp.get("data") or {}
        if resp.get("code") == 0 and data:
            qr = data.get("qrcode") or ""
            if qr:
                if qr.startswith("data:"):
                    pass
                elif qr.startswith(("http://", "https://")):
                    # NapCat 返回的是二维码内容链接，需要本地生成二维码图片
                    out["qrcodeurl"] = qr
                    try:
                        import io as _io

                        import qrcode as _qr

                        img = _qr.make(qr)
                        buf = _io.BytesIO()
                        img.save(buf, format="PNG")
                        qr = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
                    except Exception as e:
                        log.warning("二维码生成失败: %s", e)
                        qr = ""
                else:
                    qr = "data:image/png;base64," + qr
                if qr:
                    out["qrcode"] = qr
            out["qrcodeurl"] = out.get("qrcodeurl") or data.get("qrcodeurl") or ""
        return aiohttp_web.json_response(out)

    async def api_wl_get(self, request):
        acc = self.require_role(request, "user")
        role = acc.get("role")
        aid = acc.get("id")
        rows = self.store.accounts_all()
        names = {r.get("id"): r.get("username") for r in rows}
        if role in ("super", "admin"):
            gids = self.store.groups(all_rows=True)
            uids = self.store.users(all_rows=True)
        else:
            gids = self.store.groups(created_by=aid)
            uids = self.store.users(created_by=aid)
        my = self.store.account_by_id(aid) or {}
        out_groups = []
        for g in gids:
            owner = self.store.wl_groups_owner(g)
            out_groups.append({"id": g, "owner": names.get(owner, ""), "mine": str(owner) == str(aid)})
        out_users = []
        for u in uids:
            owner = self.store.wl_users_owner(u)
            out_users.append({"id": u, "owner": names.get(owner, ""), "mine": str(owner) == str(aid)})
        return aiohttp_web.json_response({
            "code": 0,
            "role": role,
            "groups": out_groups,
            "users": out_users,
            "quota_groups": my.get("quota_groups"),
            "quota_users": my.get("quota_users"),
            "used_groups": self.store.wl_count("group", aid) if role != "super" else None,
            "used_users": self.store.wl_count("user", aid) if role != "super" else None,
        })

    async def api_wl_add(self, request):
        acc = self.require_role(request, "user")
        data = await request.json()
        kind, value = data.get("type"), str(data.get("value") or "").strip()
        if kind not in ("group", "user") or not value.isdigit():
            return aiohttp_web.json_response({"code": -1, "message": "请输入纯数字的群号或QQ号"})
        row = self.store.account_by_id(acc.get("id")) or {}
        limit = row.get("quota_groups") if kind == "group" else row.get("quota_users")
        if acc.get("role") != "super" and limit is not None:
            used = self.store.wl_count(kind, acc.get("id"))
            if used >= int(limit):
                return aiohttp_web.json_response({"code": -1, "message": f"已达到配额上限（{limit} 个）"})
        self.store.add_wl(kind, value, acc.get("id"))
        return aiohttp_web.json_response({"code": 0})

    async def api_wl_remove(self, request):
        acc = self.require_role(request, "user")
        data = await request.json()
        kind = data.get("type")
        value = str(data.get("value") or "").strip()
        if kind not in ("group", "user") or not value.isdigit():
            return aiohttp_web.json_response({"code": -1, "message": "参数错误"})
        owner = self.store.wl_groups_owner(value) if kind == "group" else self.store.wl_users_owner(value)
        if acc.get("role") == "user" and str(owner) != str(acc.get("id")):
            return aiohttp_web.json_response({"code": -1, "message": "只能删除自己添加的"})
        self.store.remove_wl(kind, value)
        return aiohttp_web.json_response({"code": 0})

    async def api_wl_update(self, request):
        acc = self.require_role(request, "user")
        data = await request.json()
        kind = data.get("type")
        old = str(data.get("old") or "").strip()
        new = str(data.get("new") or "").strip()
        if kind not in ("group", "user") or not old.isdigit() or not new.isdigit():
            return aiohttp_web.json_response({"code": -1, "message": "请输入纯数字"})
        owner = self.store.wl_groups_owner(old) if kind == "group" else self.store.wl_users_owner(old)
        if acc.get("role") == "user" and str(owner) != str(acc.get("id")):
            return aiohttp_web.json_response({"code": -1, "message": "只能修改自己添加的"})
        self.store.update_wl(kind, old, new)
        return aiohttp_web.json_response({"code": 0})

    async def api_kw_get(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({"code": 0, "keywords": self.store.keywords()})

    async def api_kw_add(self, request):
        self.require_auth(request)
        data = await request.json()
        word = str(data.get("word") or "").strip()
        if not word or len(word) > 20:
            return aiohttp_web.json_response({"code": -1, "message": "关键词不能为空且不超过 20 字"})
        self.store.add_keyword(word)
        return aiohttp_web.json_response({"code": 0})

    async def api_kw_remove(self, request):
        self.require_auth(request)
        data = await request.json()
        self.store.remove_keyword(str(data.get("word") or "").strip())
        return aiohttp_web.json_response({"code": 0})

    async def api_pf_get(self, request):
        self.require_auth(request)
        m = self.store.prefix_map()
        return aiohttp_web.json_response({
            "code": 0,
            "enabled": self.store.get_setting("prefix_enabled", "1") == "1",
            "prefixes": [{"qq": k, "prefix": v} for k, v in m.items()],
        })

    async def api_pf_toggle(self, request):
        self.require_auth(request)
        data = await request.json()
        enabled = bool(data.get("enabled"))
        self.store.set_setting("prefix_enabled", "1" if enabled else "0")
        return aiohttp_web.json_response({"code": 0, "enabled": enabled})

    async def api_pf_add(self, request):
        self.require_auth(request)
        data = await request.json()
        qq = str(data.get("qq") or "").strip()
        prefix = str(data.get("prefix") or "").strip()
        if not qq.isdigit() or not prefix:
            return aiohttp_web.json_response({"code": -1, "message": "QQ 号需为纯数字，前缀不能为空"})
        self.store.set_prefix(qq, prefix)
        return aiohttp_web.json_response({"code": 0})

    async def api_pf_remove(self, request):
        self.require_auth(request)
        data = await request.json()
        self.store.remove_prefix(str(data.get("qq") or "").strip())
        return aiohttp_web.json_response({"code": 0})

    async def api_auto_get(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({
            "code": 0,
            "enabled": self.store.get_setting("auto_reply_enabled", "1") == "1",
            "users": self.store.auto_users(),
        })

    async def api_auto_toggle(self, request):
        self.require_auth(request)
        data = await request.json()
        enabled = bool(data.get("enabled"))
        self.store.set_setting("auto_reply_enabled", "1" if enabled else "0")
        return aiohttp_web.json_response({"code": 0, "enabled": enabled})

    async def api_auto_add(self, request):
        self.require_auth(request)
        data = await request.json()
        qq = str(data.get("qq") or "").strip()
        if not qq.isdigit():
            return aiohttp_web.json_response({"code": -1, "message": "QQ 号需为纯数字"})
        self.store.add_auto_user(qq)
        return aiohttp_web.json_response({"code": 0})

    async def api_auto_remove(self, request):
        self.require_auth(request)
        data = await request.json()
        self.store.remove_auto_user(str(data.get("qq") or "").strip())
        return aiohttp_web.json_response({"code": 0})

    async def api_bored_get(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({
            "code": 0,
            "enabled": self.store.get_setting("bored_enabled", "0") == "1",
            "interval_minutes": int(float(self.store.get_setting("bored_interval_minutes", "30") or 30)),
            "time_mode": self.store.get_setting("bored_time_mode", "random"),
            "min_minutes": int(float(self.store.get_setting("bored_min_minutes", "30") or 30)),
            "max_minutes": int(float(self.store.get_setting("bored_max_minutes", "60") or 60)),
            "floor_minutes": int(float(self.store.get_setting("bored_floor_minutes", "30") or 30)),
            "mode": self.store.get_setting("bored_mode", "pool"),
        })

    async def api_bored_config(self, request):
        self.require_auth(request)
        data = await request.json()
        if "enabled" in data:
            self.store.set_setting("bored_enabled", "1" if data.get("enabled") else "0")
        if data.get("time_mode") in ("fixed", "random"):
            self.store.set_setting("bored_time_mode", data["time_mode"])
        if data.get("mode") in ("pool", "ai"):
            self.store.set_setting("bored_mode", data["mode"])
        if "interval_minutes" in data:
            try:
                minutes = max(1, int(float(data.get("interval_minutes"))))
            except (TypeError, ValueError):
                return aiohttp_web.json_response({"code": -1, "message": "间隔需为整数分钟"})
            self.store.set_setting("bored_interval_minutes", str(minutes))
        for key, label in (("min_minutes", "最小触发"), ("max_minutes", "最大触发"), ("floor_minutes", "最小间隔")):
            if key in data:
                try:
                    v = max(1, int(float(data.get(key))))
                except (TypeError, ValueError):
                    return aiohttp_web.json_response({"code": -1, "message": label + "需为整数分钟"})
                self.store.set_setting("bored_" + key.replace("minutes", "minutes"), str(v))
        return aiohttp_web.json_response({"code": 0})

    async def api_bored_lines(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({"code": 0, "lines": self.store.bored_lines()})

    async def api_bored_add(self, request):
        self.require_auth(request)
        data = await request.json()
        line = str(data.get("line") or "").strip()
        if not line or len(line) > 100:
            return aiohttp_web.json_response({"code": -1, "message": "语料不能为空且不超过 100 字"})
        self.store.add_bored_line(line)
        return aiohttp_web.json_response({"code": 0})

    async def api_bored_remove(self, request):
        self.require_auth(request)
        data = await request.json()
        self.store.remove_bored_line(str(data.get("line") or "").strip())
        return aiohttp_web.json_response({"code": 0})

    async def api_convo_remove(self, request):
        self.require_auth(request)
        data = await request.json()
        gid = str(data.get("group_id") or "").strip()
        qq = str(data.get("qq") or "").strip()
        self.active_convos.pop((gid, qq), None)
        return aiohttp_web.json_response({"code": 0})

    async def api_rate_get(self, request):
        self.require_auth(request)
        whitelist = self.store.groups()
        try:
            default_max = int(self.store.get_setting("group_max_replies", str(self.group_max_replies)))
        except ValueError:
            default_max = self.group_max_replies
        default_min = int(self.min_interval)
        rates = []
        for gid in whitelist:
            row = self.store.get_rate(gid)
            if row:
                rates.append({"group_id": gid, "max_per_minute": row[0], "min_interval_seconds": row[1]})
        return aiohttp_web.json_response({
            "code": 0,
            "whitelist_empty": not bool(whitelist),
            "groups": whitelist,
            "default_max": default_max,
            "default_min": default_min,
            "first_delay_ms": int(float(self.store.get_setting("msg_first_delay_ms", "300") or 300)),
            "seg_delay_ms": int(float(self.store.get_setting("multi_msg_delay_ms", "600") or 600)),
            "sticker_delay_ms": int(float(self.store.get_setting("sticker_delay_ms", "800") or 800)),
            "seg_mode": self.store.get_setting("reply_seg_mode", "fixed"),
            "seg_fixed": int(float(self.store.get_setting("reply_seg_fixed", "2") or 2)),
            "seg_min": int(float(self.store.get_setting("reply_seg_min", "1") or 1)),
            "seg_max": int(float(self.store.get_setting("reply_seg_max", "3") or 3)),
            "rates": rates,
        })

    async def api_seg_config(self, request):
        self.require_auth(request)
        data = await request.json()
        if data.get("mode") in ("fixed", "random"):
            self.store.set_setting("reply_seg_mode", data["mode"])
        try:
            if "fixed" in data:
                self.store.set_setting("reply_seg_fixed", str(max(1, min(10, int(float(data.get("fixed")))))))
            if "min" in data:
                self.store.set_setting("reply_seg_min", str(max(1, min(10, int(float(data.get("min")))))))
            if "max" in data:
                self.store.set_setting("reply_seg_max", str(max(1, min(10, int(float(data.get("max")))))))
            if "first_delay_ms" in data:
                self.store.set_setting("msg_first_delay_ms", str(max(0, min(10000, int(float(data.get("first_delay_ms")))))))
            if "seg_delay_ms" in data:
                self.store.set_setting("multi_msg_delay_ms", str(max(0, min(10000, int(float(data.get("seg_delay_ms")))))))
            if "sticker_delay_ms" in data:
                self.store.set_setting("sticker_delay_ms", str(max(0, min(10000, int(float(data.get("sticker_delay_ms")))))))
        except (TypeError, ValueError):
            return aiohttp_web.json_response({"code": -1, "message": "参数需为整数"})
        return aiohttp_web.json_response({"code": 0})

    async def api_rate_save(self, request):
        self.require_auth(request)
        data = await request.json()
        gid = str(data.get("group_id") or "").strip()
        if not gid.isdigit():
            return aiohttp_web.json_response({"code": -1, "message": "群号需为纯数字"})
        try:
            cap = int(float(data.get("max_per_minute")))
            interval = int(float(data.get("min_interval_seconds")))
        except (TypeError, ValueError):
            return aiohttp_web.json_response({"code": -1, "message": "请输入整数"})
        cap = max(1, min(200, cap))
        interval = max(1, min(3600, interval))
        self.store.set_rate(gid, cap, interval)
        return aiohttp_web.json_response({"code": 0})

    async def api_rate_reset(self, request):
        self.require_auth(request)
        data = await request.json()
        self.store.del_rate(str(data.get("group_id") or "").strip())
        return aiohttp_web.json_response({"code": 0})

    def mask_key(self, key: str) -> str:
        if not key:
            return ""
        if len(key) > 12:
            return key[:5] + "****" + key[-4:]
        return "已配置"

    @staticmethod
    def provider_check_path(base_url: str) -> str:
        # openrouter 的 /models 是公开接口，用 /key 才能校验 Key
        return "/key" if "openrouter.ai" in base_url else "/models"

    def current_version(self) -> str:
        return (self.store.get_setting("app_version", APP_VERSION) or APP_VERSION).strip()

    @staticmethod
    def version_tuple(v: str) -> tuple:
        out = []
        for part in str(v or "").replace("-", ".").split("."):
            num = "".join(ch for ch in part if ch.isdigit())
            out.append(int(num) if num else 0)
        return tuple(out or [0])

    async def update_info(self, force: bool = False) -> dict:
        url = (self.store.get_setting("update_url", "") or DEFAULT_UPDATE_URL).strip()
        current = self.current_version()
        if not url:
            return {"url_set": False, "current": current, "has_update": False, "force": False,
                    "update_url": "", "force_min": (self.store.get_setting("update_force_min", "") or "")}
        now = time.time()
        if not force and self._update_cache and now - self._update_cache[1] < 6 * 3600:
            return self._update_cache[0]
        result = {"url_set": True, "current": current, "has_update": False, "force": False,
                  "update_url": url, "force_min": (self.store.get_setting("update_force_min", "") or ""),
                  "checked_at": time.strftime("%Y-%m-%d %H:%M")}
        try:
            async with self.http.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status != 200:
                    result["error"] = f"HTTP {resp.status}"
                    return result
                data = await resp.json(content_type=None)
            latest = str(data.get("version") or "").strip()
            if not latest:
                result["error"] = "latest.json 缺少 version"
                return result
            result.update({
                "latest": latest,
                "date": str(data.get("date") or ""),
                "notes": str(data.get("notes") or "")[:300],
                "url": str(data.get("url") or "").strip(),
                "sha256": str(data.get("sha256") or "").strip().lower(),
                "min_version": str(data.get("min_version") or "").strip(),
            })
            newer = self.version_tuple(latest) > self.version_tuple(current)
            minv = (result.get("min_version") or "").strip()
            forced = bool(minv) and self.version_tuple(current) < self.version_tuple(minv)
            result["has_update"] = newer or forced
            result["force"] = newer and forced
            self._update_cache = (result, now)
        except Exception as e:
            result["error"] = f"检查失败: {e}"
        return result

    async def api_update_file(self, request):
        name = request.match_info.get("name", "")
        safe = "".join(ch for ch in name if ch.isalnum() or ch in "._-")
        path = BASE / "updates" / safe
        if not safe or not path.is_file():
            return aiohttp_web.json_response({"code": -1, "message": "not found"}, status=404)
        return aiohttp_web.FileResponse(path)

    async def api_update_get(self, request):
        self.require_auth(request)
        if self._update_cache:
            return aiohttp_web.json_response({"code": 0, **self._update_cache[0]})
        return aiohttp_web.json_response({
            "code": 0, "url_set": True, "current": self.current_version(),
            "has_update": False, "force": False, "update_url": DEFAULT_UPDATE_URL,
        })

    async def api_update_check(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({"code": 0, **(await self.update_info(True))})

    async def api_update_config(self, request):
        self.require_auth(request)
        data = await request.json()
        if "url" in data:
            self.store.set_setting("update_url", str(data.get("url") or "").strip())
            self._update_cache = None
        if "force_min" in data:
            self.store.set_setting("update_force_min", str(data.get("force_min") or "").strip())
            self._update_cache = None
        return aiohttp_web.json_response({"code": 0})

    async def api_update_apply(self, request):
        self.require_auth(request)
        info = await self.update_info(True)
        if not info.get("has_update"):
            return aiohttp_web.json_response({"code": -1, "message": "已经是最新版本"})
        url = info.get("url") or ""
        if not url.startswith(("http://", "https://")):
            return aiohttp_web.json_response({"code": -1, "message": "latest.json 里的 url 无效"})
        try:
            async with self.http.get(url, timeout=aiohttp.ClientTimeout(total=60)) as resp:
                if resp.status != 200:
                    return aiohttp_web.json_response({"code": -1, "message": f"下载失败 HTTP {resp.status}"})
                data = await resp.read()
        except Exception as e:
            return aiohttp_web.json_response({"code": -1, "message": f"下载失败: {e}"})
        if not data or len(data) < 2000:
            return aiohttp_web.json_response({"code": -1, "message": "下载内容异常"})
        want = (info.get("sha256") or "").lower()
        if want:
            got = hashlib.sha256(data).hexdigest()
            if got != want:
                return aiohttp_web.json_response({"code": -1, "message": "校验失败（sha256 不匹配）"})
        target = Path(__file__).resolve()
        try:
            import tempfile
            try:
                backup = target.with_suffix(target.suffix + ".bak")
                backup.write_bytes(target.read_bytes())
            except Exception as be:
                log.warning("更新备份失败（跳过）: %s", be)
                try:
                    (Path(tempfile.gettempdir()) / (target.name + ".bak")).write_bytes(target.read_bytes())
                except Exception:
                    pass
            try:
                tmp = target.with_suffix(target.suffix + ".new")
                tmp.write_bytes(data)
            except PermissionError:
                tmp = Path(tempfile.gettempdir()) / (target.name + ".new")
                tmp.write_bytes(data)
            os.replace(tmp, target)
        except Exception as e:
            hint = ""
            if isinstance(e, PermissionError) or "Permission denied" in str(e):
                hint = "（目录权限不足：请在服务器执行 sudo chown -R $USER:$USER /opt/qqbot 后重试）"
            return aiohttp_web.json_response({"code": -1, "message": f"写入失败: {e}{hint}"})
        self.store.set_setting("app_version", str(info.get("latest") or ""))
        asyncio.get_running_loop().create_task(self._restart_soon())
        return aiohttp_web.json_response({"code": 0, "message": f"已更新到 {info.get('latest')}，正在重启…"})

    async def _restart_soon(self):
        await asyncio.sleep(1.5)
        try:
            log.warning("更新完成，进程内重启")
            os.execv(sys.executable, [sys.executable, str(Path(__file__).resolve())])
        except Exception as e:
            log.error("重启失败，请手动 systemctl restart qqbot-bridge: %s", e)

    async def api_bot_profile(self, request):
        self.require_auth(request)
        force = request.query.get("refresh") == "1"
        if force:
            now = time.time()
            last = getattr(self, "_last_profile_force", 0)
            if now - last < 10:
                force = False
            else:
                self._last_profile_force = now
        info = await self.napcat_login_info(force=force)
        try:
            res = await self.onebot_action("get_login_info", {})
            if isinstance(res, dict) and res.get("status") == "ok":
                d = res.get("data") or {}
                if d.get("nickname"):
                    info = {"online": True, "uin": str(d.get("user_id") or info.get("uin") or ""), "nick": str(d.get("nickname"))}
        except Exception:
            pass
        uin = str(info.get("uin") or self.self_id or "")
        fresh = await self.fresh_nick()
        if fresh:
            info = {**info, "uin": uin, "nick": fresh}
        return aiohttp_web.json_response({
            "code": 0,
            "uin": uin,
            "nick": info.get("nick") or "",
            "online": bool(info.get("online")),
            "avatar": f"https://q1.qlogo.cn/g?b=qq&nk={uin}&s=640" if uin else "",
        })

    async def api_bot_nick(self, request):
        self.require_auth(request)
        data = await request.json()
        nick = str(data.get("nickname") or "").strip()
        if not nick or len(nick) > 36:
            return aiohttp_web.json_response({"code": -1, "message": "昵称需为 1~36 个字符"})
        if getattr(self, "ws", None) is None:
            return aiohttp_web.json_response({"code": -1, "message": "机器人未连接，暂时无法修改"})
        res = await self.onebot_action("set_qq_profile", {"nickname": nick})
        ok = bool(res) and (res.get("status") in ("ok", "async") or res.get("retcode") == 0)
        if not ok:
            return aiohttp_web.json_response({"code": -1, "message": f"修改失败：{str(res)[:120]}"})
        return aiohttp_web.json_response({"code": 0})

    async def api_bot_avatar(self, request):
        self.require_auth(request)
        data = await request.json()
        url = str(data.get("url") or "").strip()
        if not url.startswith(("http://", "https://")):
            return aiohttp_web.json_response({"code": -1, "message": "请填 http/https 图片地址"})
        if getattr(self, "ws", None) is None:
            return aiohttp_web.json_response({"code": -1, "message": "机器人未连接，暂时无法修改"})
        res = await self.onebot_action("set_qq_avatar", {"file": url})
        ok = bool(res) and (res.get("status") in ("ok", "async") or res.get("retcode") == 0)
        if not ok:
            return aiohttp_web.json_response({"code": -1, "message": f"修改失败（NapCat 可能不支持该接口）：{str(res)[:120]}"})
        return aiohttp_web.json_response({"code": 0})

    async def api_blacklist_get(self, request):
        self.require_auth(request)
        items = self.store.blacklist()
        fixed = 0
        for it in items:
            if it.get("nick") or fixed >= 10:
                continue
            try:
                res = await self.onebot_action("get_stranger_info", {"user_id": int(it["qq"])})
                if isinstance(res, dict) and res.get("status") == "ok":
                    nick = str((res.get("data") or {}).get("nick") or "").strip()
                    if nick:
                        self.store.set_black_nick(it["qq"], nick)
                        it["nick"] = nick
                        fixed += 1
            except Exception:
                pass
        return aiohttp_web.json_response({"code": 0, "list": items})

    async def api_blacklist_add(self, request):
        self.require_auth(request)
        data = await request.json()
        qq = self.norm_qq(data.get("qq"))
        if not qq or not qq.isdigit():
            return aiohttp_web.json_response({"code": -1, "message": "QQ 号需为纯数字"})
        nick = ""
        try:
            res = await self.onebot_action("get_stranger_info", {"user_id": int(qq)})
            if isinstance(res, dict) and res.get("status") == "ok":
                nick = str((res.get("data") or {}).get("nick") or "")
        except Exception:
            pass
        self.store.add_black(qq, nick)
        return aiohttp_web.json_response({"code": 0})

    async def api_blacklist_remove(self, request):
        self.require_auth(request)
        data = await request.json()
        qq = self.norm_qq(data.get("qq"))
        self.store.remove_black(qq)
        return aiohttp_web.json_response({"code": 0})

    async def api_rest_get(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({
            "code": 0,
            "enabled": self.store.get_setting("rest_enabled", "0") == "1",
            "start": self.store.get_setting("rest_start", "22:00"),
            "end": self.store.get_setting("rest_end", "08:00"),
            "groups": self.store.rest_groups(),
            "users": self.store.rest_users(),
            "all_groups": self.store.groups(),
            "all_users": self.store.users(),
            "in_rest": self.rest_window(),
            "notify": self.store.get_setting("rest_notify", "1") == "1",
            "notify_groups": self.store.rest_notify_groups(),
        })

    async def api_rest_config(self, request):
        self.require_auth(request)
        data = await request.json()
        if "enabled" in data:
            self.store.set_setting("rest_enabled", "1" if data.get("enabled") else "0")
        if "notify" in data:
            self.store.set_setting("rest_notify", "1" if data.get("notify") else "0")
        if "start" in data:
            self.store.set_setting("rest_start", str(data.get("start") or "22:00").strip())
        if "end" in data:
            self.store.set_setting("rest_end", str(data.get("end") or "08:00").strip())
        return aiohttp_web.json_response({"code": 0})

    async def api_rest_wl(self, request):
        self.require_auth(request)
        data = await request.json()
        kind = data.get("type")
        value = self.norm_qq(data.get("value"))
        if kind not in ("group", "user") or not value.isdigit():
            return aiohttp_web.json_response({"code": -1, "message": "请输入纯数字"})
        if data.get("action") == "remove":
            if kind == "group":
                self.store.remove_rest_group(value)
            else:
                self.store.remove_rest_user(value)
        else:
            if kind == "group":
                self.store.add_rest_group(value)
            else:
                self.store.add_rest_user(value)
        return aiohttp_web.json_response({"code": 0})

    async def api_rest_notify_groups(self, request):
        self.require_auth(request)
        data = await request.json()
        value = self.norm_qq(data.get("value"))
        if not value.isdigit():
            return aiohttp_web.json_response({"code": -1, "message": "请输入纯数字群号"})
        if data.get("action") == "remove":
            self.store.remove_rest_notify_group(value)
        else:
            self.store.add_rest_notify_group(value)
        return aiohttp_web.json_response({"code": 0})

    async def api_rest_import(self, request):
        self.require_auth(request)
        for g in self.store.groups():
            self.store.add_rest_group(g)
        for u in self.store.users():
            self.store.add_rest_user(u)
        return aiohttp_web.json_response({"code": 0})


    async def api_me(self, request):
        acc = self.require_role(request, "user")
        row = self.store.account_by_id(acc.get("id")) or {}
        return aiohttp_web.json_response({
            "code": 0,
            "id": acc.get("id"),
            "username": acc.get("username"),
            "role": acc.get("role"),
            "quota_groups": row.get("quota_groups"),
            "quota_users": row.get("quota_users"),
            "viewer_enabled": VIEWER_FEATURE and self.store.get_setting("enable_viewer_role", "0") == "1",
        })

    async def api_accounts_get(self, request):
        acc = self.require_role(request, "admin")
        rows = self.store.accounts_all()
        if acc.get("role") != "super":
            rows = [r for r in rows if r.get("role") == "user" and str(r.get("created_by")) == str(acc.get("id"))]
        for r in rows:
            r.pop("pass_hash", None)
        return aiohttp_web.json_response({"code": 0, "accounts": rows, "my_role": acc.get("role"),
                                          "viewer_enabled": VIEWER_FEATURE and self.store.get_setting("enable_viewer_role", "0") == "1"})

    async def api_accounts_create(self, request):
        acc = self.require_role(request, "admin")
        data = await request.json()
        username = str(data.get("username") or "").strip()
        password = str(data.get("password") or "")
        role = str(data.get("role") or "user")
        if acc.get("role") == "admin" and role != "user":
            return aiohttp_web.json_response({"code": -1, "message": "管理员只能创建用户"})
        if role == "viewer" and (not VIEWER_FEATURE or acc.get("role") != "super" or self.store.get_setting("enable_viewer_role", "0") != "1"):
            return aiohttp_web.json_response({"code": -1, "message": "角色不合法"})
        if role not in ("super", "admin", "user", "viewer"):
            return aiohttp_web.json_response({"code": -1, "message": "角色不合法"})
        if not username or len(username) < 2 or len(password) < 6:
            return aiohttp_web.json_response({"code": -1, "message": "用户名至少2位，密码至少6位"})
        qg = data.get("quota_groups")
        qu = data.get("quota_users")
        qg = None if qg in (None, "", "0") else max(0, int(qg))
        qu = None if qu in (None, "", "0") else max(0, int(qu))
        if acc.get("role") == "admin":
            qg = qg if qg is not None else None
        new_id = self.store.create_account(username, password, role, acc.get("id"), qg, qu)
        if new_id is None:
            return aiohttp_web.json_response({"code": -1, "message": "用户名已存在"})
        return aiohttp_web.json_response({"code": 0, "id": new_id})

    async def api_accounts_update(self, request):
        acc = self.require_role(request, "admin")
        data = await request.json()
        aid = data.get("id")
        target = self.store.account_by_id(aid) if aid else None
        if not target:
            return aiohttp_web.json_response({"code": -1, "message": "账号不存在"})
        if acc.get("role") == "admin":
            if target.get("role") != "user" or str(target.get("created_by")) != str(acc.get("id")):
                return aiohttp_web.json_response({"code": -1, "message": "只能修改自己创建的用户"})
        fields = {}
        if "quota_groups" in data:
            v = data.get("quota_groups")
            fields["quota_groups"] = None if v in (None, "", "0") else max(0, int(v))
        if "quota_users" in data:
            v = data.get("quota_users")
            fields["quota_users"] = None if v in (None, "", "0") else max(0, int(v))
        if data.get("password"):
            if len(str(data["password"])) < 6:
                return aiohttp_web.json_response({"code": -1, "message": "密码至少6位"})
            fields["pass_hash"] = hash_password(str(data["password"]))
        if "disabled" in data:
            fields["disabled"] = 1 if data.get("disabled") else 0
        if ("role" in data and acc.get("role") == "super"
                and data.get("role") in ("super", "admin", "user", "viewer")
                and (data.get("role") != "viewer" or VIEWER_FEATURE)):
            fields["role"] = data["role"]
        self.store.update_account(aid, **fields)
        return aiohttp_web.json_response({"code": 0})

    async def api_accounts_delete(self, request):
        acc = self.require_role(request, "admin")
        data = await request.json()
        aid = data.get("id")
        target = self.store.account_by_id(aid) if aid else None
        if not target:
            return aiohttp_web.json_response({"code": -1, "message": "账号不存在"})
        if str(target.get("id")) == str(acc.get("id")):
            return aiohttp_web.json_response({"code": -1, "message": "不能删除自己"})
        if acc.get("role") == "admin" and (target.get("role") != "user" or str(target.get("created_by")) != str(acc.get("id"))):
            return aiohttp_web.json_response({"code": -1, "message": "只能删除自己创建的用户"})
        self.store.delete_account(aid)
        return aiohttp_web.json_response({"code": 0})

    async def api_login_logs(self, request):
        acc = self.require_role(request, "user")
        role = acc.get("role")
        if role == "super":
            rows = self.store.login_logs(200)
        elif role == "admin":
            ids = [acc.get("id")]
            for a in self.store.accounts_all():
                if str(a.get("created_by")) == str(acc.get("id")):
                    ids.append(a.get("id"))
            rows = self.store.login_logs(200, ids)
        else:
            rows = self.store.login_logs(200, [acc.get("id")])
        return aiohttp_web.json_response({"code": 0, "logs": rows})

    async def api_friend_get(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({
            "code": 0,
            "auto": self.store.get_setting("friend_auto_accept", "0") == "1",
            "notify": self.store.get_setting("friend_notify", "1") == "1",
            "limit": int(self.store.get_setting("friend_daily_limit", "10") or 10),
            "today_accepted": self.store.friend_today("accepted"),
            "today_total": self.store.friend_today("pending") + self.store.friend_today("accepted")
                           + self.store.friend_today("rejected") + self.store.friend_today("overlimit")
                           + self.store.friend_today("failed"),
            "list": self.store.friend_list(50),
        })

    async def api_friend_config(self, request):
        self.require_auth(request)
        data = await request.json()
        if "auto" in data:
            self.store.set_setting("friend_auto_accept", "1" if data.get("auto") else "0")
        if "notify" in data:
            self.store.set_setting("friend_notify", "1" if data.get("notify") else "0")
        if "limit" in data:
            try:
                self.store.set_setting("friend_daily_limit", str(max(1, min(200, int(data.get("limit"))))))
            except Exception:
                pass
        return aiohttp_web.json_response({"code": 0})

    async def api_friend_action(self, request):
        self.require_auth(request)
        data = await request.json()
        flag = str(data.get("flag") or "")
        approve = bool(data.get("approve"))
        if not flag:
            return aiohttp_web.json_response({"code": -1, "message": "缺少请求标识"})
        res = await self.onebot_action("set_friend_add_request", {"flag": flag, "approve": approve})
        if not res or res.get("status") != "ok":
            return aiohttp_web.json_response({"code": -1, "message": "处理失败，请求可能已过期"})
        self.store.friend_update(flag, "accepted" if approve else "rejected")
        return aiohttp_web.json_response({"code": 0})

    async def api_super_get(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({
            "code": 0,
            "qqs": self.super_admin_qqs(),
            "simp": self.store.get_setting("simp_mode", "0") == "1",
            "exclusive": self.store.get_setting("exclusive_mode", "0") == "1",
            "window_seconds": int(float(self.store.get_setting("exclusive_window_seconds", "60") or 60)),
            "roast": self.store.get_setting("roast_enabled", "1") == "1",
            "roast_keywords": self.store.get_setting("roast_keywords", "怼") or "怼",
            "balance_keywords": self.store.get_setting("balance_keywords", "") or "",
            "sticker_capture": self.store.get_setting("sticker_capture_enabled", "1") == "1",
            "sticker_capture_keywords": self.store.get_setting("sticker_capture_keywords", "") or "添加表情包,收录,存表情",
        })

    async def api_super_config(self, request):
        self.require_auth(request)
        data = await request.json()
        if "qqs" in data:
            raw = str(data.get("qqs") or "")
            parts = []
            for p in raw.replace("，", ",").split(","):
                q = self.norm_qq(p)
                if not q:
                    continue
                if not q.isdigit():
                    return aiohttp_web.json_response({"code": -1, "message": "QQ 号需为纯数字：" + q})
                if q not in parts:
                    parts.append(q)
            self.store.set_setting("super_admin_qqs", ",".join(parts))
        if "simp" in data:
            self.store.set_setting("simp_mode", "1" if data.get("simp") else "0")
        if "exclusive" in data:
            self.store.set_setting("exclusive_mode", "1" if data.get("exclusive") else "0")
        if "roast" in data:
            self.store.set_setting("roast_enabled", "1" if data.get("roast") else "0")
        if "sticker_capture" in data:
            self.store.set_setting("sticker_capture_enabled", "1" if data.get("sticker_capture") else "0")
        if "sticker_capture_keywords" in data:
            words = [w.strip() for w in str(data.get("sticker_capture_keywords") or "").replace("，", ",").split(",") if w.strip()]
            self.store.set_setting("sticker_capture_keywords", ",".join(words))
        if "balance_keywords" in data:
            words = [w.strip() for w in str(data.get("balance_keywords") or "").replace("，", ",").split(",") if w.strip()]
            self.store.set_setting("balance_keywords", ",".join(words))
        if "roast_keywords" in data:
            words = [w.strip() for w in str(data.get("roast_keywords") or "").replace("，", ",").split(",") if w.strip()]
            self.store.set_setting("roast_keywords", ",".join(words) or "怼")
        if "window_seconds" in data:
            try:
                w = max(10, min(3600, int(float(data.get("window_seconds")))))
            except (TypeError, ValueError):
                return aiohttp_web.json_response({"code": -1, "message": "窗口时长需为秒数（≥10）"})
            self.store.set_setting("exclusive_window_seconds", str(w))
        return aiohttp_web.json_response({"code": 0})

    async def api_personas_get(self, request):
        self.require_auth(request)
        active = (self.store.get_setting("persona_active", "0") or "0").strip()
        rows = self.store.list_personas()
        out = []
        for r in rows:
            item = dict(r)
            item["active"] = str(r["id"]) == active
            out.append(item)
        return aiohttp_web.json_response({
            "code": 0,
            "personas": out,
            "active": active,
            "current": self.persona_text(),
            "default": self.system_prompt,
        })

    async def api_personas_save(self, request):
        self.require_auth(request)
        data = await request.json()
        name = str(data.get("name") or "").strip()[:40]
        content = str(data.get("content") or "").strip()
        if not name:
            return aiohttp_web.json_response({"code": -1, "message": "人格名称不能为空"})
        if len(content) < 10:
            return aiohttp_web.json_response({"code": -1, "message": "人格内容太短（至少 10 字）"})
        if len(content) > 8000:
            return aiohttp_web.json_response({"code": -1, "message": "人格内容太长（最多 8000 字）"})
        pid = data.get("id")
        try:
            new_id = self.store.save_persona(int(pid) if pid else 0, name, content)
        except (TypeError, ValueError):
            return aiohttp_web.json_response({"code": -1, "message": "id 不合法"})
        return aiohttp_web.json_response({"code": 0, "id": new_id})

    async def api_personas_delete(self, request):
        self.require_auth(request)
        data = await request.json()
        try:
            pid = int(data.get("id"))
        except (TypeError, ValueError):
            return aiohttp_web.json_response({"code": -1, "message": "id 不合法"})
        self.store.delete_persona(pid)
        if (self.store.get_setting("persona_active", "0") or "0").strip() == str(pid):
            self.store.set_setting("persona_active", "0")
        return aiohttp_web.json_response({"code": 0})

    async def api_personas_activate(self, request):
        self.require_auth(request)
        data = await request.json()
        pid = str(data.get("id") or "0").strip()
        if pid != "0" and not self.store.get_persona(pid):
            return aiohttp_web.json_response({"code": -1, "message": "人格不存在"})
        self.store.set_setting("persona_active", pid)
        return aiohttp_web.json_response({"code": 0})

    async def api_persona_get(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({
            "code": 0,
            "text": self.persona_text(),
            "default": self.system_prompt,
            "customized": bool(self.store.get_setting("persona_text", "")),
            "length": len(self.persona_text()),
            "gender_aware": self.store.get_setting("gender_aware", "0") == "1",
        })

    async def api_memory_noise_preview(self, request):
        acc = self.require_role(request, "user")
        if acc.get("role") != "super":
            return aiohttp_web.json_response({"code": -1, "message": "没有权限"})
        total, items = self.store.mem_noise_preview()
        samples = [i["content"] for i in items[:10]]
        return aiohttp_web.json_response({"code": 0, "total": total, "noise": len(items), "samples": samples})

    async def api_memory_clean_noise(self, request):
        acc = self.require_role(request, "user")
        if acc.get("role") != "super":
            return aiohttp_web.json_response({"code": -1, "message": "没有权限"})
        n = self.store.mem_clean_noise()
        return aiohttp_web.json_response({"code": 0, "deleted": n})

    async def api_memory_ai_review(self, request):
        acc = self.require_role(request, "user")
        if acc.get("role") != "super":
            return aiohttp_web.json_response({"code": -1, "message": "没有权限"})
        rows = self.store.mem_list_all(None, None, None, 300)
        if not rows:
            return aiohttp_web.json_response({"code": 0, "ids": [], "samples": [], "total": 0})
        ids = await self.ai_review_memories(rows)
        by_id = {r["id"]: r for r in rows}
        samples = [by_id[i]["content"] for i in ids[:8] if i in by_id]
        return aiohttp_web.json_response({"code": 0, "ids": ids, "samples": samples, "total": len(rows)})

    async def api_memory_delete_many(self, request):
        acc = self.require_role(request, "user")
        if acc.get("role") != "super":
            return aiohttp_web.json_response({"code": -1, "message": "没有权限"})
        data = await request.json()
        ids = data.get("ids") or []
        n = 0
        with self.store._conn() as c:
            for i in ids:
                try:
                    c.execute("DELETE FROM memories WHERE id=?", (int(i),))
                    n += 1
                except Exception:
                    pass
        return aiohttp_web.json_response({"code": 0, "deleted": n})

    async def api_memory_get(self, request):
        self.require_auth(request)
        qq = (request.query.get("qq") or "").strip()
        kw = (request.query.get("kw") or "").strip()
        date = (request.query.get("date") or "").strip()
        items = self.store.mem_list_all(qq or None, kw or None, date or None, 300)
        for it in items:
            it["permanent"] = bool(it.get("permanent"))
            it["level_label"] = "超管" if it.get("level") == "high" else "普通"
        cfg = {
            "enabled": self.memory_enabled(),
            "super_days": int(self.store.get_setting("memory_super_days", "180") or 180),
            "normal_days": int(self.store.get_setting("memory_normal_days", "7") or 7),
            "super_limit": int(self.store.get_setting("memory_super_limit", "500") or 500),
            "normal_limit": int(self.store.get_setting("memory_normal_limit", "50") or 50),
            "super_inject": int(self.store.get_setting("memory_super_inject", "20") or 20),
            "normal_inject": int(self.store.get_setting("memory_normal_inject", "5") or 5),
            "extract_every": int(self.store.get_setting("memory_extract_every", "3") or 3),
        }
        return aiohttp_web.json_response({"code": 0, "items": items, "config": cfg})

    async def api_memory_add(self, request):
        acc = self.require_role(request, "user")
        if acc.get("role") != "super":
            return aiohttp_web.json_response({"code": -1, "message": "没有权限"})
        data = await request.json()
        qq = str(data.get("qq") or "").strip()
        content = str(data.get("content") or "").strip()
        level = "high" if data.get("level") == "high" else "normal"
        if not qq.isdigit() or not content:
            return aiohttp_web.json_response({"code": -1, "message": "QQ 和内容都不能为空"})
        if len(content) > 120:
            return aiohttp_web.json_response({"code": -1, "message": "内容太长（最多120字）"})
        self.store.mem_add(qq, content, level, "manual")
        return aiohttp_web.json_response({"code": 0})

    async def api_memory_update(self, request):
        acc = self.require_role(request, "user")
        if acc.get("role") != "super":
            return aiohttp_web.json_response({"code": -1, "message": "没有权限"})
        data = await request.json()
        mid = data.get("id")
        content = str(data.get("content") or "").strip()
        if not mid or not content:
            return aiohttp_web.json_response({"code": -1, "message": "参数错误"})
        self.store.mem_update(mid, content)
        return aiohttp_web.json_response({"code": 0})

    async def api_memory_delete(self, request):
        acc = self.require_role(request, "user")
        if acc.get("role") != "super":
            return aiohttp_web.json_response({"code": -1, "message": "没有权限"})
        data = await request.json()
        if data.get("qq"):
            self.store.mem_clear_owner(str(data.get("qq")))
        elif data.get("id"):
            self.store.mem_delete(data.get("id"))
        else:
            return aiohttp_web.json_response({"code": -1, "message": "参数错误"})
        return aiohttp_web.json_response({"code": 0})

    async def api_memory_config(self, request):
        acc = self.require_role(request, "user")
        if acc.get("role") != "super":
            return aiohttp_web.json_response({"code": -1, "message": "没有权限"})
        data = await request.json()
        if "enabled" in data:
            self.store.set_setting("memory_enabled", "1" if data.get("enabled") else "0")
        for key, setting in (
            ("super_days", "memory_super_days"), ("normal_days", "memory_normal_days"),
            ("super_limit", "memory_super_limit"), ("normal_limit", "memory_normal_limit"),
            ("super_inject", "memory_super_inject"), ("normal_inject", "memory_normal_inject"),
            ("extract_every", "memory_extract_every"),
        ):
            if key in data:
                try:
                    self.store.set_setting(setting, str(max(1, int(data.get(key)))))
                except Exception:
                    pass
        return aiohttp_web.json_response({"code": 0})

    async def api_persona_gender(self, request):
        self.require_auth(request)
        data = await request.json()
        self.store.set_setting("gender_aware", "1" if data.get("enabled") else "0")
        return aiohttp_web.json_response({"code": 0})

    async def api_persona_save(self, request):
        self.require_auth(request)
        data = await request.json()
        text = str(data.get("text") or "").strip()
        if len(text) < 10:
            return aiohttp_web.json_response({"code": -1, "message": "人设太短了（至少 10 字）"})
        if len(text) > 8000:
            return aiohttp_web.json_response({"code": -1, "message": "人设太长（最多 8000 字）"})
        self.store.set_setting("persona_text", text)
        return aiohttp_web.json_response({"code": 0})

    async def api_persona_reset(self, request):
        self.require_auth(request)
        with self.store._conn() as c:
            c.execute("DELETE FROM settings WHERE key='persona_text'")
        return aiohttp_web.json_response({"code": 0})

    async def api_voice_get(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({
            "code": 0,
            "tts_enabled": self.store.get_setting("voice_tts_enabled", "0") == "1",
            "tts_provider": self.store.get_setting("voice_tts_provider", "edge"),
            "doubao_version": self.store.get_setting("voice_doubao_version", "v3"),
            "doubao_api_key_masked": self.mask_key(self.store.get_setting("voice_doubao_api_key", "")),
            "doubao_model": self.store.get_setting("voice_doubao_model", "seed-audio-1.0"),
            "doubao_speaker": self.store.get_setting("voice_doubao_speaker", ""),
            "doubao_appid": self.store.get_setting("voice_doubao_appid", ""),
            "doubao_token_masked": self.mask_key(self.store.get_setting("voice_doubao_token", "")),
            "doubao_cluster": self.store.get_setting("voice_doubao_cluster", "volcano_tts"),
            "doubao_voice": self.store.get_setting("voice_doubao_voice", "BV001_streaming"),
            "tts_voice": self.store.get_setting("voice_tts_voice", "zh-CN-XiaoxiaoNeural"),
            "tts_mode": self.store.get_setting("voice_tts_mode", "voice_in"),
            "asr_enabled": self.store.get_setting("voice_asr_enabled", "0") == "1",
            "asr_engine": self.store.get_setting("voice_asr_engine", "local"),
            "asr_local_model": self.store.get_setting("voice_asr_local_model", "base"),
            "asr_base": self.store.get_setting("voice_asr_base", ""),
            "asr_model": self.store.get_setting("voice_asr_model", "whisper-large-v3-turbo"),
            "asr_key_masked": self.mask_key(self.store.get_setting("voice_asr_key", "")),
            "voices": [
                "zh-CN-XiaoxiaoNeural", "zh-CN-XiaoyiNeural", "zh-CN-YunxiNeural",
                "zh-CN-YunjianNeural", "zh-CN-YunyangNeural",
                "zh-CN-liaoning-XiaobeiNeural", "zh-CN-shaanxi-XiaoniNeural",
                "zh-HK-HiuGaaiNeural", "zh-HK-HiuMaanNeural",
                "zh-TW-HsiaoChenNeural", "zh-TW-HsiaoYuNeural", "zh-TW-YunJheNeural",
                "en-US-AriaNeural", "en-US-GuyNeural",
                "ja-JP-NanamiNeural", "ja-JP-KeitaNeural",
            ],
        })

    async def api_voice_preview(self, request):
        self.require_auth(request)
        data = await request.json()
        voice = str(data.get("voice") or self.store.get_setting("voice_tts_voice", "zh-CN-XiaoxiaoNeural")).strip()
        text = str(data.get("text") or "你好呀，我是大肥鱼，你听听这个声音怎么样？")[:120]
        try:
            audio = await self.synthesize(text, voice)
            if not audio:
                return aiohttp_web.json_response({"code": -1, "message": "合成失败"})
            return aiohttp_web.json_response({"code": 0, "audio": "data:audio/mpeg;base64," + base64.b64encode(audio).decode()})
        except Exception as e:
            return aiohttp_web.json_response({"code": -1, "message": f"合成失败: {e}"})

    async def api_voice_config(self, request):
        self.require_auth(request)
        data = await request.json()
        for key, setting in (("tts_enabled", "voice_tts_enabled"), ("asr_enabled", "voice_asr_enabled")):
            if key in data:
                self.store.set_setting(setting, "1" if data.get(key) else "0")
        if data.get("tts_provider") in ("edge", "doubao"):
            self.store.set_setting("voice_tts_provider", data["tts_provider"])
        if data.get("doubao_version") in ("v1", "v3"):
            self.store.set_setting("voice_doubao_version", data["doubao_version"])
        if "doubao_api_key" in data:
            k = str(data.get("doubao_api_key") or "").strip()
            if k:
                self.store.set_setting("voice_doubao_api_key", k)
        if "doubao_model" in data:
            self.store.set_setting("voice_doubao_model", str(data.get("doubao_model") or "seed-audio-1.0").strip())
        if "doubao_speaker" in data:
            self.store.set_setting("voice_doubao_speaker", str(data.get("doubao_speaker") or "").strip())
        for key, setting in (("doubao_appid", "voice_doubao_appid"), ("doubao_cluster", "voice_doubao_cluster"), ("doubao_voice", "voice_doubao_voice")):
            if key in data:
                self.store.set_setting(setting, str(data.get(key) or "").strip())
        if "doubao_token" in data:
            t = str(data.get("doubao_token") or "").strip()
            if t:
                self.store.set_setting("voice_doubao_token", t)
        if "tts_voice" in data:
            v = str(data.get("tts_voice") or "").strip()
            if v:
                self.store.set_setting("voice_tts_voice", v)
        if data.get("tts_mode") in ("voice_in", "always"):
            self.store.set_setting("voice_tts_mode", data["tts_mode"])
        if data.get("asr_engine") in ("local", "api"):
            self.store.set_setting("voice_asr_engine", data["asr_engine"])
        if "asr_local_model" in data:
            m = str(data.get("asr_local_model") or "base").strip()
            if m:
                self.store.set_setting("voice_asr_local_model", m)
        if "asr_base" in data:
            self.store.set_setting("voice_asr_base", str(data.get("asr_base") or "").strip().rstrip("/"))
        if "asr_model" in data:
            self.store.set_setting("voice_asr_model", str(data.get("asr_model") or "").strip())
        if "asr_key" in data:
            k = str(data.get("asr_key") or "").strip()
            if k:
                self.store.set_setting("voice_asr_key", k)
        return aiohttp_web.json_response({"code": 0})

    @staticmethod
    def parse_balance_text(d) -> str:
        if not isinstance(d, dict):
            return ""
        infos = d.get("balance_infos")
        if isinstance(infos, list) and infos:
            parts = []
            for i in infos:
                if not isinstance(i, dict):
                    continue
                total = i.get("total_balance")
                if total in (None, ""):
                    continue
                cur = str(i.get("currency") or "")
                parts.append(f"{cur} {total}".strip())
            if parts:
                return " / ".join(parts)
        data = d.get("data") if isinstance(d.get("data"), dict) else {}
        tc = data.get("total_credits")
        tu = data.get("total_usage")
        if tc is not None and tu is not None:
            try:
                return f"剩余 {round(float(tc) - float(tu), 4)}"
            except Exception:
                pass
        for src in (d, data):
            for k in ("balance", "total_balance", "credits", "remain", "quota"):
                v = src.get(k) if isinstance(src, dict) else None
                if v not in (None, ""):
                    return str(v)
        return ""

    async def fetch_balance_text(self, row) -> str:
        base = (row.get("base_url") or "").rstrip("/")
        key = row.get("api_key") or ""
        if not base or not key:
            return ""
        headers = {"Authorization": f"Bearer {key}"}
        low = base.lower()
        urls = []
        if "deepseek" in low:
            urls.append(base + "/user/balance")
        elif "siliconflow" in low:
            urls.append(base + "/user/info")
        elif "openrouter" in low:
            urls.append(base + "/credits")
        urls += [base + "/user/balance", base + "/user/info"]
        seen = []
        for url in urls:
            if url in seen:
                continue
            seen.append(url)
            try:
                async with self.http.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as resp:
                    if resp.status != 200:
                        continue
                    data = await resp.json(content_type=None)
                text = self.parse_balance_text(data)
                if text:
                    return text
            except Exception:
                continue
        return ""

    async def api_provider_balances(self, request):
        self.require_auth(request)
        force = request.query.get("force") == "1"
        now = time.time()
        cache = getattr(self, "_balance_cache", {})
        out = {}
        for p in self.store.providers():
            name = p["name"]
            hit = cache.get(name)
            if hit and not force and now - hit[1] < 60:
                out[name] = hit[0]
                continue
            text = await self.fetch_balance_text(p)
            cache[name] = (text, now)
            out[name] = text
        self._balance_cache = cache
        return aiohttp_web.json_response({"code": 0, "balances": out})

    async def api_providers_get(self, request):
        self.require_auth(request)
        active = self.store.get_setting("active_provider", "")
        items = []
        for p in self.store.providers():
            items.append({
                "name": p["name"],
                "base_url": p["base_url"],
                "model": p["model"],
                "masked": self.mask_key(p["api_key"]),
                "active": p["name"] == active,
            })
        return aiohttp_web.json_response({
            "code": 0,
            "active": active,
            "providers": items,
            "presets": [{"name": k, "base_url": v["base_url"], "model": v["model"]} for k, v in PROVIDER_PRESETS.items()],
        })

    async def api_providers_save(self, request):
        self.require_auth(request)
        data = await request.json()
        name = str(data.get("name") or "").strip()
        base_url = str(data.get("base_url") or "").strip().rstrip("/")
        model = str(data.get("model") or "").strip()
        key = str(data.get("api_key") or "").strip()
        if not name or not name.replace("-", "").replace("_", "").isalnum():
            return aiohttp_web.json_response({"code": -1, "message": "名称只能包含字母数字-_"})
        if not base_url.startswith("http"):
            return aiohttp_web.json_response({"code": -1, "message": "base_url 需以 http(s):// 开头"})
        if not model:
            return aiohttp_web.json_response({"code": -1, "message": "请填写模型名"})
        if not key:
            existing = self.store.get_provider(name)
            if existing:
                key = existing["api_key"]
        if len(key) < 10:
            return aiohttp_web.json_response({"code": -1, "message": "请填写 API Key（至少 10 位）"})
        self.store.save_provider(name, base_url, key, model)
        if not self.store.get_setting("active_provider", ""):
            self.store.set_setting("active_provider", name)
        return aiohttp_web.json_response({"code": 0})

    async def api_providers_delete(self, request):
        self.require_auth(request)
        data = await request.json()
        name = str(data.get("name") or "").strip()
        self.store.delete_provider(name)
        if self.store.get_setting("active_provider", "") == name:
            self.store.set_setting("active_provider", "")
        return aiohttp_web.json_response({"code": 0})

    async def api_providers_activate(self, request):
        self.require_auth(request)
        data = await request.json()
        name = str(data.get("name") or "").strip()
        if not self.store.get_provider(name):
            return aiohttp_web.json_response({"code": -1, "message": "供应商不存在"})
        self.store.set_setting("active_provider", name)
        return aiohttp_web.json_response({"code": 0})

    async def api_providers_test(self, request):
        self.require_auth(request)
        data = await request.json()
        name = str(data.get("name") or "").strip()
        row = self.store.get_provider(name)
        if not row:
            return aiohttp_web.json_response({"code": -1, "message": "供应商不存在"})
        try:
            async with self.http.get(
                f"{row['base_url']}{self.provider_check_path(row['base_url'])}",
                headers={"Authorization": f"Bearer {row['api_key']}"},
                timeout=aiohttp.ClientTimeout(total=20),
            ) as resp:
                if resp.status == 200:
                    return aiohttp_web.json_response({"code": 0, "message": "Key 有效"})
                return aiohttp_web.json_response({"code": -1, "message": f"Key 无效（HTTP {resp.status}）"})
        except Exception as e:
            return aiohttp_web.json_response({"code": -1, "message": f"网络错误: {e}"})

    async def api_providers_autodetect(self, request):
        self.require_auth(request)
        data = await request.json()
        key = str(data.get("key") or "").strip()
        if len(key) < 10:
            return aiohttp_web.json_response({"code": -1, "message": "先粘贴 API Key"})
        matches = []
        for name, preset in PROVIDER_PRESETS.items():
            if name == "custom" or not preset["base_url"]:
                continue
            try:
                async with self.http.get(
                    f"{preset['base_url']}{self.provider_check_path(preset['base_url'])}",
                    headers={"Authorization": f"Bearer {key}"},
                    timeout=aiohttp.ClientTimeout(total=8),
                ) as resp:
                    if resp.status == 200:
                        matches.append({"name": name, "base_url": preset["base_url"], "model": preset["model"]})
            except Exception:
                continue
        return aiohttp_web.json_response({
            "code": 0 if matches else -1,
            "matches": matches,
            "message": "匹配到: " + ", ".join(m["name"] for m in matches) if matches else "没有匹配到已知服务商，可手动填写 base_url",
        })

    async def api_apikey_get(self, request):
        self.require_auth(request)
        key = self.effective_api_key()
        return aiohttp_web.json_response({
            "code": 0,
            "configured": bool(key),
            "masked": self.mask_key(key),
            "source": "db" if self.store.get_setting("deepseek_api_key", "") else ("env" if self.api_key else ""),
        })

    async def api_apikey_save(self, request):
        self.require_auth(request)
        data = await request.json()
        key = str(data.get("key") or "").strip()
        if len(key) < 20 or not key.startswith("sk-"):
            return aiohttp_web.json_response({"code": -1, "message": "Key 格式不对（应以 sk- 开头）"})
        self.store.set_setting("deepseek_api_key", key)
        return aiohttp_web.json_response({"code": 0})

    async def api_apikey_test(self, request):
        self.require_auth(request)
        key = self.effective_api_key()
        if not key:
            return aiohttp_web.json_response({"code": -1, "message": "还没有配置 Key"})
        try:
            async with self.http.get(
                f"{self.api_base}/models",
                headers={"Authorization": f"Bearer {key}"},
                timeout=aiohttp.ClientTimeout(total=20),
            ) as resp:
                if resp.status == 200:
                    return aiohttp_web.json_response({"code": 0, "message": "Key 有效"})
                return aiohttp_web.json_response({"code": -1, "message": f"Key 无效（HTTP {resp.status}）"})
        except Exception as e:
            return aiohttp_web.json_response({"code": -1, "message": f"网络错误: {e}"})

    async def api_end_get(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({
            "code": 0,
            "enabled": self.store.get_setting("end_phrase_enabled", "1") == "1",
            "reply": self.store.get_setting("end_phrase_reply", "好的，那我退下了"),
            "phrases": self.store.end_phrases(),
        })

    async def api_end_config(self, request):
        self.require_auth(request)
        data = await request.json()
        if "enabled" in data:
            self.store.set_setting("end_phrase_enabled", "1" if data.get("enabled") else "0")
        if "reply" in data:
            self.store.set_setting("end_phrase_reply", str(data.get("reply") or "").strip()[:100])
        return aiohttp_web.json_response({"code": 0})

    async def api_end_add(self, request):
        self.require_auth(request)
        data = await request.json()
        phrase = str(data.get("phrase") or "").strip()
        if not phrase or len(phrase) > 30:
            return aiohttp_web.json_response({"code": -1, "message": "触发词不能为空且不超过 30 字"})
        self.store.add_end_phrase(phrase)
        return aiohttp_web.json_response({"code": 0})

    async def api_end_remove(self, request):
        self.require_auth(request)
        data = await request.json()
        self.store.remove_end_phrase(str(data.get("phrase") or "").strip())
        return aiohttp_web.json_response({"code": 0})

    def sticker_url(self, name: str) -> str:
        base = (self.store.get_setting("public_base_url", "") or "").rstrip("/")
        return f"{base}/stickers/{name}" if base else ""

    async def serve_sticker(self, request):
        name = request.match_info["name"]
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", name):
            raise aiohttp_web.HTTPNotFound()
        path = STICKER_DIR / name
        if not path.exists():
            raise aiohttp_web.HTTPNotFound()
        return aiohttp_web.FileResponse(path)

    async def api_stickers(self, request):
        self.require_auth(request)
        names = self.store.stickers()
        desc_map = {d["filename"]: (d.get("description") or "") for d in self.store.sticker_descriptions()}
        return aiohttp_web.json_response({
            "code": 0,
            "stickers": [{"name": n, "url": self.sticker_url(n),
                          "description": desc_map.get(n, "")} for n in names],
            "probability": int(self.store.get_setting("sticker_probability", "0") or 0),
            "mode": self.store.get_setting("sticker_mode", "smart"),
            "base": (self.store.get_setting("public_base_url", "") or ""),
        })

    async def api_sticker_upload(self, request):
        self.require_auth(request)
        try:
            reader = await request.multipart()
            field = await reader.next()
            if field is None or not getattr(field, "filename", None):
                return aiohttp_web.json_response({"code": -1, "message": "没有收到文件"})
            data = await field.read()
            if len(data) > 2 * 1024 * 1024:
                return aiohttp_web.json_response({"code": -1, "message": "图片不能超过 2MB"})
            ext = Path(field.filename).suffix.lower()
            if ext not in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
                return aiohttp_web.json_response({"code": -1, "message": "只支持 png/jpg/gif/webp"})
            name = secrets.token_hex(8) + ext
            (STICKER_DIR / name).write_bytes(data)
            self.store.add_sticker(name)
            host = str(request.host or "").strip()
            if host and not host.startswith(("127.0.0.1", "localhost", "192.168.", "10.", "172.")):
                self.store.set_setting("public_base_url", f"https://{host}")
            return aiohttp_web.json_response({"code": 0, "name": name})
        except Exception as e:
            log.warning("表情包上传失败: %s", e)
            return aiohttp_web.json_response({"code": -1, "message": "上传失败"})

    async def api_sticker_upload_many(self, request):
        self.require_auth(request)
        saved, failed = 0, 0
        try:
            reader = await request.multipart()
            count = 0
            while True:
                part = await reader.next()
                if part is None:
                    break
                if part.name not in ("files", "file") or not getattr(part, "filename", None):
                    continue
                count += 1
                if count > 50:
                    await part.read()
                    failed += 1
                    continue
                data = await part.read()
                ext = Path(part.filename).suffix.lower()
                if ext not in (".png", ".jpg", ".jpeg", ".gif", ".webp") or len(data) > 2 * 1024 * 1024:
                    failed += 1
                    continue
                name = secrets.token_hex(8) + ext
                (STICKER_DIR / name).write_bytes(data)
                self.store.add_sticker(name)
                saved += 1
            host = str(request.host or "").strip()
            if host and not host.startswith(("127.0.0.1", "localhost", "192.168.", "10.", "172.")):
                self.store.set_setting("public_base_url", f"https://{host}")
        except Exception as e:
            log.warning("批量上传表情失败: %s", e)
        return aiohttp_web.json_response({"code": 0, "saved": saved, "failed": failed})

    async def api_sticker_add_urls(self, request):
        self.require_auth(request)
        data = await request.json()
        urls = [str(u).strip() for u in (data.get("urls") or []) if str(u).strip()]
        saved, failed = 0, 0
        for url in urls[:200]:
            if not url.startswith(("http://", "https://")):
                failed += 1
                continue
            if not await self.is_public_url(url):
                failed += 1
                continue
            try:
                async with self.http.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    if resp.status != 200:
                        failed += 1
                        continue
                    blob = await resp.read()
                if len(blob) > 2 * 1024 * 1024:
                    failed += 1
                    continue
                ctype = (resp.headers.get("Content-Type") or "").lower()
                ext = ".png"
                for e in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
                    if e in url.lower() or e.strip(".") in ctype:
                        ext = e
                        break
                name = secrets.token_hex(8) + ext
                (STICKER_DIR / name).write_bytes(blob)
                self.store.add_sticker(name)
                saved += 1
            except Exception:
                failed += 1
        host = str(request.host or "").strip()
        if host and not host.startswith(("127.0.0.1", "localhost", "192.168.", "10.", "172.")):
            self.store.set_setting("public_base_url", f"https://{host}")
        return aiohttp_web.json_response({"code": 0, "saved": saved, "failed": failed})

    async def api_sticker_desc(self, request):
        self.require_auth(request)
        data = await request.json()
        name = str(data.get("name") or "").strip()
        desc = str(data.get("description") or "").strip()[:300]
        if not name:
            return aiohttp_web.json_response({"code": -1, "message": "参数错误"})
        self.store.set_sticker_description(name, desc)
        return aiohttp_web.json_response({"code": 0})

    async def api_sticker_remove(self, request):
        self.require_auth(request)
        data = await request.json()
        name = str(data.get("name") or "").strip()
        self.store.remove_sticker(name)
        try:
            (STICKER_DIR / name).unlink(missing_ok=True)
        except Exception:
            pass
        return aiohttp_web.json_response({"code": 0})

    async def api_sticker_config(self, request):
        self.require_auth(request)
        data = await request.json()
        if "probability" in data:
            try:
                prob = max(0, min(100, int(float(data.get("probability")))))
            except (TypeError, ValueError):
                return aiohttp_web.json_response({"code": -1, "message": "概率需为 0-100 的整数"})
            self.store.set_setting("sticker_probability", str(prob))
        if data.get("mode") in ("random", "smart"):
            self.store.set_setting("sticker_mode", data["mode"])
        host = str(request.host or "").strip()
        if host and not host.startswith(("127.0.0.1", "localhost", "192.168.", "10.", "172.")):
            self.store.set_setting("public_base_url", f"https://{host}")
        return aiohttp_web.json_response({"code": 0})

    async def api_convos(self, request):
        self.require_auth(request)
        now = time.time()
        items = []
        for (gid, qq), exp in self.active_convos.items():
            if exp > now:
                items.append({"group_id": gid, "qq": qq, "expires_in": int(exp - now)})
        items.sort(key=lambda x: x["expires_in"])
        return aiohttp_web.json_response({
            "code": 0,
            "items": items,
            "cleanup_interval": self.cleanup_interval,
        })

    async def api_gr_get(self, request):
        self.require_auth(request)
        whitelist = self.store.groups()
        groups = whitelist or sorted(self.group_activity.keys())
        return aiohttp_web.json_response({
            "code": 0,
            "whitelist_empty": not bool(whitelist),
            "groups": groups,
            "always": self.store.always_groups(),
            "continue_seconds": int(float(self.store.get_setting("group_continue_seconds", str(self.continue_seconds)) or 180)),
            "max_replies": int(float(self.store.get_setting("group_max_replies", str(self.group_max_replies)) or 6)),
            "max_active_users": int(float(self.store.get_setting("max_active_users", str(self.max_active_users)) or 3)),
            "thrifty": self.store.get_setting("thrifty_mode", "0") == "1",
            "at_reply": self.store.get_setting("reply_at_enabled", "0") == "1",
            "end_phrase_enabled": self.store.get_setting("end_phrase_enabled", "1") == "1",
            "end_phrase_reply": self.store.get_setting("end_phrase_reply", "好的，那我退下了"),
        })

    async def api_gr_config(self, request):
        self.require_auth(request)
        data = await request.json()
        if "continue_seconds" in data:
            try:
                secs = max(30, int(float(data.get("continue_seconds"))))
            except (TypeError, ValueError):
                return aiohttp_web.json_response({"code": -1, "message": "接话时间需为秒数（≥30）"})
            self.store.set_setting("group_continue_seconds", str(secs))
        if "max_replies" in data:
            try:
                cap = max(1, int(float(data.get("max_replies"))))
            except (TypeError, ValueError):
                return aiohttp_web.json_response({"code": -1, "message": "频率需为整数条/分钟"})
            self.store.set_setting("group_max_replies", str(cap))
        if "max_active_users" in data:
            try:
                n = max(1, int(float(data.get("max_active_users"))))
            except (TypeError, ValueError):
                return aiohttp_web.json_response({"code": -1, "message": "人数需为整数"})
            self.store.set_setting("max_active_users", str(n))
        if "at_reply" in data:
            self.store.set_setting("reply_at_enabled", "1" if data.get("at_reply") else "0")
        if "thrifty" in data:
            self.store.set_setting("thrifty_mode", "1" if data.get("thrifty") else "0")
        if "end_phrase" in data:
            self.store.set_setting("end_phrase_enabled", "1" if data.get("end_phrase") else "0")
        if "end_phrase_reply" in data:
            text = str(data.get("end_phrase_reply") or "").strip()
            self.store.set_setting("end_phrase_reply", text[:100])
        return aiohttp_web.json_response({"code": 0})

    async def api_gr_always(self, request):
        self.require_auth(request)
        data = await request.json()
        gid = str(data.get("group_id") or "").strip()
        if not gid.isdigit():
            return aiohttp_web.json_response({"code": -1, "message": "群号需为纯数字"})
        self.store.set_always_group(gid, bool(data.get("enabled")))
        return aiohttp_web.json_response({"code": 0})

    async def api_admins(self, request):
        self.require_auth(request)
        return aiohttp_web.json_response({"code": 0, "admins": self.store.admins()})

    async def api_admin_add(self, request):
        self.require_auth(request)
        data = await request.json()
        username = (data.get("username") or "").strip()
        password = data.get("password") or ""
        if not username or len(password) < 6:
            return aiohttp_web.json_response({"code": -1, "message": "用户名不能为空，密码至少 6 位"})
        if not self.store.add_admin(username, password):
            return aiohttp_web.json_response({"code": -1, "message": "该用户名已存在"})
        return aiohttp_web.json_response({"code": 0})

    async def api_admin_remove(self, request):
        self.require_auth(request)
        data = await request.json()
        username = data.get("username")
        if not username:
            return aiohttp_web.json_response({"code": -1, "message": "缺少用户名"})
        if self.store.admin_count() <= 1:
            return aiohttp_web.json_response({"code": -1, "message": "至少要保留一个管理员"})
        self.store.remove_admin(username)
        return aiohttp_web.json_response({"code": 0})


LOGIN_HTML = """<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>登录 - FishPond</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;background:#0f1115;color:#e6e6e6;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0}
.box{background:#181b22;border-radius:14px;padding:28px 24px;width:300px}
h1{font-size:17px;margin:0 0 18px;text-align:center}
input{width:100%;box-sizing:border-box;background:#0b0d11;border:1px solid #2a2f3a;color:#e6e6e6;border-radius:8px;padding:10px 12px;margin-bottom:12px;font-size:14px}
button{width:100%;background:#2563eb;color:#fff;border:none;border-radius:8px;padding:11px;font-size:15px;cursor:pointer}
.msg{color:#f87171;font-size:13px;min-height:18px;margin-bottom:8px}
</style></head>
<body><div id="pbar"></div><div class="box"><h1>FishPond</h1>
<div class="msg" id="msg"></div>
<input id="u" placeholder="用户名" autocomplete="username">
<input id="p" type="password" placeholder="密码" autocomplete="current-password">
<button onclick="login()">登录</button>
<div style="text-align:center;color:#4b5563;font-size:11px;margin-top:14px;line-height:1.8">
  免费源码 · 请勿购买<br>作者 QQ：2844642318｜群：243625638
</div>
</div>
<script>
const B = '__BASE__';
async function login(){
  const r = await fetch(B + '/api/login', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({username: document.getElementById('u').value, password: document.getElementById('p').value})}).then(r=>r.json()).catch(e=>({code:-1,message:'网络错误'}));
  if(r.code===0){ location.reload(); } else { document.getElementById('msg').textContent = r.message || '登录失败'; }
}
document.addEventListener('keydown', e=>{ if(e.key==='Enter') login(); });
</script></body></html>"""


ADMIN_HTML = """<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FishPond 管理</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;background:#0f1115;color:#e6e6e6;margin:0;padding:16px;font-size:15px}
h1{font-size:17px;margin:0 0 12px}
.tabs{display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap}
.tab{padding:7px 14px;border-radius:999px;background:#181b22;cursor:pointer;color:#9aa4b8;font-size:14px}
.tab.on{background:#2563eb;color:#fff}
.card{background:#181b22;border-radius:12px;padding:14px 16px;margin-bottom:12px}
.row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #242833;gap:10px}
.row:last-child{border-bottom:none}
.k{color:#8b93a5;flex-shrink:0}
.ok{color:#4ade80;font-weight:600}.bad{color:#f87171;font-weight:600}
pre{background:#0b0d11;border-radius:10px;padding:10px;overflow:auto;font-size:11px;line-height:1.5;color:#9aa4b8;margin:0;max-height:300px}
input{background:#0b0d11;border:1px solid #2a2f3a;color:#e6e6e6;border-radius:8px;padding:9px 11px;font-size:14px}
button{background:#2563eb;color:#fff;border:none;border-radius:8px;padding:9px 14px;font-size:14px;cursor:pointer}
button.danger{background:#7f1d1d}
.hint{color:#6b7280;font-size:12px;line-height:1.6}
.item{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #242833}
.item:last-child{border-bottom:none}
.msg{font-size:13px;min-height:18px}
img.qr{background:#fff;border-radius:10px;padding:8px;width:220px;height:220px;object-fit:contain}
.hidden{display:none}
.badge{font-size:12px;padding:2px 8px;border-radius:999px;background:#1f2937;color:#9aa4b8}

*{box-sizing:border-box}
body{padding:0!important;margin:0}
.swipe-hint{display:none}
@media (max-width: 899px){
  .swipe-hint{display:flex;align-items:center;font-size:12px;color:#8b93a5;background:#181b22;border:1px solid #242833;border-radius:999px;padding:4px 10px;animation:swipenudge 2.2s ease-in-out infinite}
  @keyframes swipenudge{0%,100%{transform:translateX(0)}50%{transform:translateX(-4px)}}
}
.topbar{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 16px;position:sticky;top:0;z-index:22;background:rgba(15,17,21,.96);backdrop-filter:blur(8px);border-bottom:1px solid #1c2028}
.topbar h1{margin:0;font-size:16px}
.tabs{flex-wrap:nowrap;overflow-x:auto;gap:8px;margin:0;padding:10px 16px;position:sticky;top:53px;z-index:20;background:#0f1115;border-bottom:1px solid #1c2028;scrollbar-width:none}
.tabs::-webkit-scrollbar{display:none}
.tab{flex:0 0 auto}
#subtabs{position:static!important;top:auto!important;margin:10px 16px 18px!important;padding:10px 0 0!important;border:none!important;border-top:1px solid rgba(255,255,255,.07)!important;background:transparent!important;display:flex;flex-wrap:wrap;gap:8px;overflow:visible!important}
#subtabs .tab{font-size:13px;padding:7px 12px;border-radius:9px;background:#181b22;color:#9aa4b8;flex:0 0 auto}
#subtabs .tab.on{background:#2563eb;color:#fff}
main{display:flex;flex-direction:column;gap:12px;padding:14px 16px 28px;max-width:980px;width:100%;margin:0 auto;flex:1}
.card{margin-bottom:0}
.item{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}
input,select{max-width:100%}

/* 桌面端：侧边栏布局 */
@media (min-width: 900px){
  body{display:grid;grid-template-columns:220px minmax(0,1fr);grid-template-rows:auto 1fr;grid-template-areas:"top top" "nav main";min-height:100vh}
  .topbar{grid-area:top}
  .tabs{grid-area:nav;flex-direction:column;flex-wrap:nowrap;overflow-x:hidden;overflow-y:auto;position:sticky;top:0;height:100%;border-right:1px solid #1c2028;border-bottom:none;padding:12px;gap:6px;background:#0f1115}
  .tabs .tab{border-radius:8px;padding:9px 12px;text-align:left}
  main{grid-area:main;max-width:1080px;margin:0 auto;padding:22px 26px 40px}
  #subtabs{display:none!important}
  .navgroup{display:flex;flex-direction:column}
  .navgroup>.tab{display:flex;justify-content:space-between;align-items:center}
  .navgroup>.tab:after{content:"▾";font-size:11px;opacity:.6}
  .navgroup.open>.tab:after{content:"▴"}
  .navgroup .subs{display:none;flex-direction:column;gap:4px;margin:6px 0 8px 12px;padding-left:8px;border-left:1px solid #1c2028}
  .navgroup.open .subs{display:flex}
  .navgroup .subs .tab{font-size:13px;padding:6px 10px;border-radius:8px;color:#8b96a8}
  .navgroup .subs .tab.on{background:rgba(37,99,235,.25);color:#bfdbfe}
}
body.viewer button:not(.tab){opacity:.45;pointer-events:none}
body.viewer input,body.viewer select,body.viewer textarea{opacity:.55;pointer-events:none}
body.viewer .item button{pointer-events:none}
.memhead{display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap}
.memgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px}
.memgrid label{display:flex;flex-direction:column;gap:5px;font-size:12px;color:#8b93a5}
.memgrid input{width:100%;box-sizing:border-box}
.memrow{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.memitem{border:1px solid #242833;border-radius:10px;padding:10px 12px;margin-bottom:8px;display:flex;gap:10px;justify-content:space-between;align-items:flex-start;flex-wrap:wrap}
.memitem .main{flex:1;min-width:220px}
.memitem .meta{font-size:12px;color:#6b7280;margin-top:5px;line-height:1.6}
.memtag{display:inline-block;font-size:11px;padding:1px 7px;border-radius:6px;margin-right:6px}
.memtag.high{background:#172554;color:#93c5fd}
.memtag.perm{background:#431407;color:#fdba74}
button{transition:transform .08s ease, filter .15s ease, opacity .15s ease}
button:active{transform:scale(.96);filter:brightness(.88)}
button:disabled{opacity:.55;cursor:not-allowed}
#pbar{position:fixed;top:0;left:0;height:3px;width:0;background:#2563eb;z-index:99999;opacity:0;transition:width .2s ease,opacity .3s ease}
.tab:active{transform:scale(.97)}
@keyframes segFadeIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
.seg-anim{animation:segFadeIn .15s ease}
.memitem .acts{display:flex;gap:6px;flex-wrap:wrap}
</style></head>
<body><div id="pbar"></div>
<div class="topbar">
  <h1>FishPond</h1>
  <div class="swipe-hint" id="swipehint">← 左右滑动标签</div>
</div>
<div class="tabs" id="tabs">
  <div class="tab on" data-g="status">状态</div>
  <div class="tab" data-g="bot">机器人 <span id="updot" style="display:none;color:#f87171">●</span></div>
  <div class="tab" data-g="chat">聊天</div>
  <div class="tab" data-g="acct">账号</div>
  <div class="tab" data-g="logout">退出</div>
</div>
<div class="tabs" id="subtabs" style="margin-top:14px"></div>
<main id="main">

<div id="accounts" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">账号管理</h2>
    <div class="hint" id="acchint"></div>
    <div id="acclist"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">新建账号</h2>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0;align-items:center">
      <input id="accname" placeholder="用户名" style="width:130px">
      <input id="accpass" type="password" placeholder="密码（≥6位）" style="width:150px">
      <select id="accrole" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:9px">
        <option value="user">用户</option>
        <option value="admin">管理员</option>
        <option value="super">超级管理员</option>
      </select>
      <input id="accqg" type="number" min="0" placeholder="可加群上限（空=不限）" style="width:170px">
      <input id="accqu" type="number" min="0" placeholder="可加QQ上限（空=不限）" style="width:170px">
      <button onclick="createAccount()">创建账号</button>
    </div>
    <div class="msg" id="accmsg"></div>
  </div>
</div>

<div id="logins" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">登录日志</h2>
    <div class="hint">保留最近 30 天；超级管理员看全部，管理员看自己+下属，用户看自己。</div>
    <div id="loginloglist" style="margin-top:10px"></div>
  </div>
</div>

<div id="status">
  <div class="card" id="stat-card"><div class="hint">加载中…</div></div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">好友申请</h2>
    <div class="hint" id="friendbrief">加载中…</div>
    <div id="friendrecent" style="margin-top:8px"></div>
  </div>
  <div class="card"><h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">最近日志</h2><pre id="logbox"></pre></div>
</div>

<div id="super" class="hidden">
  <div class="card" style="padding:8px 12px">
    <div id="supertabs" style="display:flex;gap:8px;flex-wrap:wrap">
      <div class="tab on" onclick="superTab('basic', this)">基本设置</div>
      <div class="tab" onclick="superTab('capture', this)">表情收录</div>
      <div class="tab" onclick="superTab('profile', this)">机器人资料</div>
      <div class="tab" onclick="superTab('friend', this)">好友申请</div>
      <div class="tab" onclick="superTab('black', this)">黑名单</div>
    </div>
  </div>

  <div class="card superpanel" id="super-basic">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">超管 QQ</h2>
    <div class="hint">填写超级管理员的 QQ 号（多个用英文逗号分隔）。舔狗/专一/怼人模式只对这里的 QQ 生效。</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:10px 0;align-items:center">
      <input id="superqqs" placeholder="如：2844642318,123456789" style="flex:1;min-width:220px">
      <button onclick="saveSuperQQ()">保存 QQ 号</button>
    </div>
    <div class="hint" id="superdesc"></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:10px 0;align-items:center">
      <button id="simpbtn" onclick="toggleSimp()">舔狗模式：加载中</button>
      <span class="hint">开启后对超管唯命是从、语气更黏人。</span>
    </div>
    <div style="display:flex;gap:6px;flex-wrap:nowrap;margin:10px 0;align-items:center;white-space:nowrap">
      <button id="exclbtn" onclick="toggleExclusive()" style="padding:8px 10px">专一模式：加载中</button>
      <input id="exwin" type="number" min="10" max="3600" style="width:56px;padding:8px 6px">
      <span style="color:#9aa4b8;font-size:13px">秒</span>
      <button onclick="saveSuperWindow()" style="padding:8px 10px">保存</button>
    </div>
    <div class="hint">超管发消息后，窗口时间内只回超管；窗口内超管没再说话，其他人恢复正常回复。</div>
    <div style="display:flex;gap:6px;flex-wrap:nowrap;margin:10px 0;align-items:center;white-space:nowrap">
      <button id="roastbtn" onclick="toggleRoast()" style="padding:8px 10px">怼人模式：加载中</button>
      <input id="roastwords" placeholder="怼,损,喷" style="width:110px;padding:8px 6px">
      <button onclick="saveRoastWords()" style="padding:8px 10px">保存</button>
    </div>
    <div class="hint">超管在群里 @某人 并说「怼他/怼她」，AI 会结合上下文怼这个人（会 @ 被怼的人）。</div>
    <div style="display:flex;gap:6px;flex-wrap:nowrap;margin:10px 0;align-items:center;white-space:nowrap">
      <input id="balwords" placeholder="查余额,余额还剩多少" style="flex:1;min-width:120px;padding:8px 6px">
      <button onclick="saveBalanceWords()" style="padding:8px 10px">保存</button>
    </div>
    <div class="hint">仅超级管理员命中这些词才回复余额，其他人问不会输出。</div>
    <div class="msg" id="supermsg"></div>
  </div>

  <div class="card superpanel hidden" id="super-capture">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">群内收录表情包</h2>
    <div class="hint">群聊里 @AI + 引用表情包 + 关键词 + 语境，例如：<code>@AI 添加表情包 开心</code>，会自动收录并把「开心」作为说明。</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:10px 0;align-items:center">
      <span style="color:#9aa4b8;font-size:13px">收录关键词</span>
      <input id="capwords" placeholder="添加表情包,收录,存表情" style="width:220px">
      <button onclick="saveCaptureWords()">保存关键词</button>
      <button id="capbtn" onclick="toggleCapture()" style="background:#4b5563">收录：加载中</button>
    </div>
    <div class="hint">只写关键词不写语境时，会自动识图生成说明；收录后的说明可在「聊天 → 表情包」里修改。</div>
  </div>

  <div class="card superpanel hidden" id="super-profile">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">机器人资料（QQ昵称 / 头像）</h2>
    <div style="display:flex;gap:12px;align-items:center;margin:10px 0">
      <img id="botavatar" style="width:64px;height:64px;border-radius:50%;background:#222">
      <div>
        <div>QQ：<span id="botuin"></span></div>
        <div>昵称：<span id="botnicklabel"></span></div>
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
      <input id="botnick" placeholder="新昵称" style="width:200px">
      <button onclick="saveBotNick()">修改昵称</button>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
      <input id="botavatarurl" placeholder="头像图片 URL（http/https）" style="flex:1;min-width:220px">
      <button onclick="saveBotAvatar()">修改头像</button>
    </div>
    <div class="msg" id="botmsg"></div>
  </div>

  <div class="card superpanel hidden" id="super-friend">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">好友申请</h2>
    <div class="hint">别人加机器人好友时的处理方式。自动通过有名额上限，防止被 QQ 判定异常。</div>
    <div style="display:flex;gap:6px;flex-wrap:nowrap;margin:10px 0;align-items:center;white-space:nowrap">
      <button id="fautobtn" onclick="toggleFriendAuto()" style="padding:8px 10px">自动通过：加载中</button>
      <input id="flimit" type="number" min="1" max="200" style="width:64px;padding:8px 6px">
      <span style="color:#9aa4b8;font-size:13px">个/天</span>
      <button onclick="saveFriendCfg()" style="padding:8px 10px">保存</button>
    </div>
    <div class="hint">每天最多自动通过几个；超过的名额会保留为「待处理」，可在下面手动通过。</div>
    <div style="margin:10px 0"><button id="fnotifybtn" onclick="toggleFriendNotify()">超管提醒：加载中</button></div>
    <div class="hint">开启后每次有好友申请都会私聊通知超级管理员。</div>
    <div id="friendlist" style="margin-top:12px"></div>
  </div>

  <div class="card superpanel hidden" id="super-black">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">黑名单（机器人完全不回复）</h2>
    <div class="hint">被加入黑名单的 QQ 发消息机器人一律不回复。也可以在群里 @某人 说「加入黑名单」或「移出黑名单」（仅超级管理员可用）。</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0;align-items:center">
      <input id="blackqq" placeholder="要拉黑的 QQ 号" style="width:200px">
      <button onclick="addBlack()">添加</button>
    </div>
    <div id="blacklist"></div>
    <div class="msg" id="blackmsg"></div>
  </div>
</div>

<div id="rest" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">休息模式（模拟人类作息）</h2>
    <div class="hint">开启后在设定时间段内，机器人只回复超级管理员私聊 + 「休息群白名单」和「休息QQ白名单」里的人和群；其他人/群一律不回复，避免长时间高频在线被 QQ 判定为机器人。</div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:12px 0">
      <button id="restbtn" onclick="toggleRest()">休息模式：加载中</button>
      <span style="color:#9aa4b8;font-size:13px">开始</span>
      <input id="reststart" type="time" value="22:00" style="width:120px">
      <span style="color:#9aa4b8;font-size:13px">结束</span>
      <input id="restend" type="time" value="08:00" style="width:120px">
      <button onclick="saveRestTime()">保存时间</button>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0 10px">
      <button id="restnotifybtn" onclick="toggleRestNotify()">休息通知：加载中</button>
      <span class="hint">进入/结束休息时发一句问候：通知群为空时发到「名单 → 群白名单」里的所有群；第一个群立即发，后面的每隔 30 秒~2 分钟随机间隔</span>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0">
      <input id="restnotifyg" placeholder="通知群号（休息开始/结束在这发一句）" style="width:260px">
      <button onclick="addRestNotifyGroup()">添加通知群</button>
    </div>
    <div id="restnotifylist"></div>
    <div class="hint" id="reststatus"></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:12px 0;align-items:center">
      <input id="restg" placeholder="休息时也回复的群号" style="width:170px">
      <button onclick="addRestWL('group')">添加群</button>
      <input id="restu" placeholder="休息时也回复的QQ" style="width:170px">
      <button onclick="addRestWL('user')">添加QQ</button>
      <button onclick="importRestWL()" style="background:#4b5563">导入现有白名单</button>
    </div>
    <div class="hint">休息群白名单</div>
    <div id="restglist"></div>
    <div class="hint" style="margin-top:10px">休息QQ白名单</div>
    <div id="restulist"></div>
    <div class="hint" id="restwl" style="margin-top:10px"></div>
    <div class="msg" id="restmsg"></div>
  </div>
</div>

<div id="settings" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">版本与更新</h2>
    <div id="verline" class="hint">当前版本：加载中…</div>
    <div class="hint" id="vernotes"></div>
    <div style="display:flex;justify-content:center;margin:14px 0">
      <button id="checkbtn" onclick="checkUpdate(true)" style="min-width:160px">检查更新</button>
    </div>
    <div class="msg" id="updatemsg"></div>
  </div>
</div>

<div id="mem" class="hidden">
  <div class="card memhead">
    <div style="flex:1;min-width:200px">
      <h2 style="font-size:15px;margin:0 0 6px">记忆模式</h2>
      <div class="hint">超级管理员：<b>180 天</b>未被调用自动清理，调用 <b>3 次</b>以上永久保留；普通用户：<b>7 天</b>后清理，不保留永久。<br>「调用」= 消息或 AI 回复里真正用到这条记忆（命中内容才计），不是每条消息都算。</div>
    </div>
    <button id="membtn" onclick="toggleMemory()">记忆模式：加载中</button>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 10px">参数设置</h2>
    <div class="memgrid">
      <label>超管保留天数<input id="memsuperdays" type="number" min="1"></label>
      <label>普通保留天数<input id="memnormaldays" type="number" min="1"></label>
      <label>超管每人上限<input id="memsuperlimit" type="number" min="1"></label>
      <label>普通每人上限<input id="memnormallimit" type="number" min="1"></label>
      <label>注入条数·超管<input id="memsuperinject" type="number" min="1"></label>
      <label>注入条数·普通<input id="memnormalinject" type="number" min="1"></label>
      <label>每几轮提取<input id="memextract" type="number" min="1"></label>
    </div>
    <div style="margin-top:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <button onclick="saveMemoryConfig()">保存设置</button>
      <span class="msg" id="memmsg"></span>
    </div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 10px">查询</h2>
    <div class="hint" style="margin-bottom:8px">QQ、关键词、日期可单独查询；同时填写时需要同时满足（AND）。日期按记忆创建时间算。</div>
    <div class="memrow">
      <input id="memqq" placeholder="QQ号" style="width:150px">
      <input id="memkw" placeholder="关键词" style="width:160px">
      <input id="memdate" type="date" style="width:160px">
      <button onclick="loadMemory()">查询</button>
      <button onclick="memReset()" style="background:#4b5563">重置</button>
    </div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 10px">添加记忆</h2>
    <div class="memrow">
      <input id="memaddqq" placeholder="QQ号" style="width:150px">
      <input id="memaddtext" placeholder="记忆内容（最多120字）" style="flex:1;min-width:220px">
      <select id="memaddlevel" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:9px">
        <option value="normal">普通（7天）</option>
        <option value="high">超管（180天/永久）</option>
      </select>
      <button onclick="memAdd()">添加</button>
    </div>
  </div>
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
      <h2 style="font-size:14px;color:#8b93a5;margin:0">记忆列表</h2>
      <span style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <span class="hint" id="memcount"></span>
        <button onclick="aiReview()" style="background:#7c2d12">AI 审核清理</button>
      </span>
    </div>
    <div id="memlist" style="margin-top:10px"></div>
  </div>
</div>

<div id="persona" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">人格切换（可存多套）</h2>
    <div class="hint">选一个当前人格，或新建一套。点「设为当前」后下一条消息起生效。默认人格来自 config.yaml。</div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:10px 0">
      <span style="color:#9aa4b8;font-size:13px">当前人格</span>
      <select id="personasel" onchange="onPersonaSelect()" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:8px;min-width:180px"></select>
      <button onclick="newPersona()">新建</button>
      <button onclick="activatePersona()">设为当前</button>
      <button onclick="deletePersona2()">删除</button>
      <span class="hint" id="personalength"></span>
    </div>
    <input id="personaname" placeholder="人格名称，如：傲娇版 / 舔狗版 / 高冷版" style="width:100%;box-sizing:border-box;margin:8px 0">
    <textarea id="personatext" rows="16" style="width:100%;box-sizing:border-box;background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:10px;font-size:13px;line-height:1.7"></textarea>
    <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
      <button onclick="savePersona()">保存当前编辑</button>
    </div>
    <div class="msg" id="personamsg"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">性别感知</h2>
    <div class="hint">开启后，识别到对方是男生会偶尔称呼「哥哥」，女生会偶尔称呼「姐姐」，显得更亲近；性别未知时不猜、用中性称呼。</div>
    <div style="margin-top:10px"><button id="genderbtn" onclick="toggleGender()">性别感知：加载中</button></div>
  </div>
</div>

<div id="pv" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">当前模型</h2>
    <div class="hint" id="pvcurrent">加载中…</div>
    <div style="margin-top:10px"><button id="pvbalbtn" onclick="loadBalances(true)">刷新余额</button>
      <span class="hint" id="pvbalmsg" style="margin-left:8px"></span></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">添加 / 修改供应商</h2>
    <div class="hint">选预设自动填地址和模型；也支持自定义。粘贴 Key 后点「自动识别」会尝试匹配服务商。</div>
    <div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap">
      <select id="pvpreset" onchange="applyPreset()" style="flex:1;min-width:140px;background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:9px 11px"></select>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
      <input id="pvname" placeholder="名称（如 deepseek）" style="width:140px">
      <input id="pvbase" placeholder="base_url（https://.../v1）" style="flex:1;min-width:180px">
      <input id="pvmodel" placeholder="模型名（如 deepseek-chat）" style="width:160px">
      <input id="pvkey" type="password" placeholder="API Key" style="flex:1;min-width:160px">
    </div>
    <div style="display:flex;gap:8px;margin:8px 0">
      <button onclick="autoDetectProvider()">自动识别</button>
      <button onclick="saveProvider()">保存</button>
    </div>
    <div class="msg" id="pvmsg"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">已配置供应商</h2>
    <div id="pvlist"></div>
  </div>
</div>

<div id="voice" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">语音回复（TTS）</h2>
    <div class="hint">开启后，机器人的回复会合成语音发送（Edge-TTS，免费）。"跟随语音"= 对方发语音才回语音；"全部"= 所有回复都语音。</div>
    <div style="display:flex;gap:8px;margin:10px 0;align-items:center;flex-wrap:wrap">
      <button id="ttsbtn" onclick="toggleTTS()">加载中…</button>
      <span style="color:#9aa4b8;font-size:13px">音色</span>
      <select id="ttsvoice" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:8px"></select>
      <button onclick="previewVoice()">试听</button>
      <span style="color:#9aa4b8;font-size:13px">模式</span>
      <select id="ttsmode" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:8px">
        <option value="voice_in">跟随语音</option>
        <option value="always">所有回复</option>
      </select>
    </div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:8px 0">
      <span style="color:#9aa4b8;font-size:13px">语音引擎</span>
      <select id="ttsprovider" onchange="toggleDoubaoFields()" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:8px">
        <option value="edge">Edge-TTS（免费）</option>
        <option value="doubao">豆包 TTS（火山引擎）</option>
      </select>
    </div>
    <div id="doubaofields" style="display:none">
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:8px 0">
        <span style="color:#9aa4b8;font-size:13px">接口版本</span>
        <select id="dbversion" onchange="toggleDoubaoFields()" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:8px">
          <option value="v3">新版 v3（X-Api-Key）</option>
          <option value="v1">标准版 v1（AppID/Token）</option>
        </select>
      </div>
      <div id="dbv3" style="display:none">
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
          <input id="dbkey" type="password" placeholder="X-Api-Key（留空不修改）" style="flex:1;min-width:200px">
          <input id="dbmodel" placeholder="model（seed-audio-1.0）" style="width:180px">
          <select id="dbspeakersel" onchange="toggleSpeakerCustom()" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:8px;min-width:160px">
            <option value="zh_female_qingchezizi_uranus_bigtts">清车子子（女声）</option>
            <option value="zh_female_vv_uranus_bigtts">Vivi（女声）</option>
            <option value="zh_female_xiaohe_uranus_bigtts">小何（女声）</option>
            <option value="zh_female_tianmei_uranus_bigtts">甜妹（女声）</option>
            <option value="zh_female_roumeinvyou_uranus_bigtts">软妹女友（女声）</option>
            <option value="zh_male_m191_uranus_bigtts">M191（男声）</option>
            <option value="zh_male_taocan_uranus_bigtts">涛哥（男声）</option>
            <option value="zh_male_yuanboxiaoshu_uranus_bigtts">渊博小叔（男声）</option>
            <option value="zh_male_sunwukong_uranus_bigtts">孙悟空（男声）</option>
            <option value="__custom__">自定义…</option>
          </select>
          <input id="dbspeaker" placeholder="自定义 speaker 音色ID" style="flex:1;min-width:200px;display:none">
        </div>
        <div class="hint" id="dbkeyinfo"></div>
      </div>
      <div id="dbv1" style="display:none">
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
          <input id="dbappid" placeholder="AppID" style="width:150px">
          <input id="dbtoken" type="password" placeholder="Access Token（留空不修改）" style="flex:1;min-width:160px">
          <input id="dbcluster" placeholder="cluster（volcano_tts）" style="width:170px">
          <input id="dbvoice" placeholder="voice_type（BV001_streaming）" style="width:190px">
        </div>
        <div class="hint" id="dbinfo"></div>
      </div>
    </div>
    <div id="voicepreview" style="display:none;margin-top:8px">
      <audio id="voiceplayer" controls preload="auto" style="width:100%"></audio>
    </div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">语音识别（ASR）</h2>
    <div class="hint">填 OpenAI 兼容的语音转写服务。推荐：硅基流动 <code>https://api.siliconflow.cn/v1</code>（模型 FunAudioLLM/SenseVoiceSmall）或 Groq <code>https://api.groq.com/openai/v1</code>（模型 whisper-large-v3-turbo）。</div>
    <div style="display:flex;gap:8px;margin:10px 0;align-items:center;flex-wrap:wrap">
      <button id="asrbtn" onclick="toggleASR()">加载中…</button>
    </div>
    <div style="display:flex;gap:8px;margin:8px 0;align-items:center;flex-wrap:wrap">
      <span style="color:#9aa4b8;font-size:13px">识别引擎</span>
      <select id="asrengine" onchange="toggleASRFields()" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:8px">
        <option value="local">本地 Whisper（免费）</option>
        <option value="api">在线 API（OpenAI 兼容）</option>
      </select>
      <span style="color:#9aa4b8;font-size:13px">本地模型</span>
      <select id="asrlocal" style="background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:8px">
        <option value="tiny">tiny（最快）</option>
        <option value="base">base（推荐）</option>
        <option value="small">small（更准）</option>
      </select>
    </div>
    <div id="asrapifields" style="display:none">
      <div style="display:flex;gap:8px;margin:8px 0;flex-wrap:wrap">
        <input id="asrbase" placeholder="服务地址 https://.../v1" style="flex:1;min-width:180px">
        <input id="asrmodel" placeholder="模型名" style="width:180px">
        <input id="asrkey" type="password" placeholder="ASR Key（留空不修改）" style="flex:1;min-width:160px">
      </div>
      <div class="hint" id="asrkeyinfo"></div>
    </div>
  </div>
  <div class="card"><button onclick="saveVoice()">保存全部语音设置</button><div class="msg" id="voicemsg"></div></div>
</div>

<div id="qr" class="hidden">
  <div class="card">
    <div class="hint">点击下方按钮才会向 QQ 申请新二维码（60 秒冷却，避免频繁请求触发风控）。</div>
    <div style="margin:12px 0;display:flex;gap:10px;flex-wrap:wrap;align-items:center">
      <button id="qrbtn" onclick="getQR()">申请扫码二维码</button>
      <button onclick="getQR(true)" style="background:#4b5563">刷新二维码</button>
      <label class="hint" style="display:flex;gap:6px;align-items:center;margin:0">
        <input type="checkbox" id="qrautorefresh" checked> 过期自动刷新
      </label>
    </div>
    <div class="msg" id="qrmsg"></div>
    <div id="qrimg" style="margin-top:10px"></div>
    <div class="hint" id="qrinfo"></div>
    <div class="hint" id="qrcountdown"></div>
  </div>
</div>

<div id="wl" class="hidden">
  <div class="card">
    <div class="hint" id="wlquota"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">群聊白名单</h2>
    <div class="hint">留空 = 允许所有群；添加后 = 只在列表中的群回复。</div>
    <div style="display:flex;gap:8px;margin:10px 0">
      <input id="ginput" placeholder="群号（纯数字）" style="flex:1">
      <button onclick="addWL('group')">添加</button>
    </div>
    <div id="glist"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">QQ 号白名单</h2>
    <div class="hint">留空 = 允许所有人；添加后 = 只有列表中的 QQ 能使用机器人（群聊和私聊都生效）。</div>
    <div style="display:flex;gap:8px;margin:10px 0">
      <input id="uinput" placeholder="QQ 号（纯数字）" style="flex:1">
      <button onclick="addWL('user')">添加</button>
    </div>
    <div id="ulist"></div>
  </div>
</div>

<div id="kw" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">触发关键词</h2>
    <div class="hint">群聊里消息**包含**这些关键词时，大肥鱼会冒出来回复（不需要 @）。@ 触发始终有效；私聊始终回复。修改后立即生效，无需重启。</div>
    <div style="display:flex;gap:8px;margin:10px 0">
      <input id="kwinput" placeholder="关键词（如：大肥鱼）" style="flex:1">
      <button onclick="addKW()">添加</button>
    </div>
    <div id="kwlist"></div>
  </div>
</div>

<div id="pf" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">QQ 专属回复前缀</h2>
    <div class="hint">给不同 QQ 号设置不同前缀，机器人回复时自动加在开头（如 123456789 → 主人）。修改立即生效。留空则不加前缀。</div>
    <div style="margin:10px 0"><button id="pfbtn" onclick="togglePrefix()">加载中…</button></div>
    <div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap">
      <input id="pfqq" placeholder="QQ 号" style="flex:1;min-width:110px">
      <input id="pftext" placeholder="前缀（如：主人）" style="flex:1;min-width:110px">
      <button onclick="addPrefix()">添加/更新</button>
    </div>
    <div id="pflist"></div>
  </div>
</div>

<div id="auto" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">接话模式</h2>
    <div class="hint">开启后，下面名单里的 QQ 无论发什么（不用 @、不用关键词），机器人都接话回复。修改立即生效。</div>
    <div style="margin:12px 0">
      <button id="autobtn" onclick="toggleAuto()">加载中…</button>
      <span id="autostate" style="margin-left:10px;color:#9aa4b8;font-size:13px"></span>
    </div>
    <div style="display:flex;gap:8px;margin:10px 0">
      <input id="autoqq" placeholder="QQ 号（纯数字）" style="flex:1">
      <button onclick="addAuto()">添加接话 QQ</button>
    </div>
    <div id="autolist"></div>
  </div>
</div>

<div id="gr" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">群聊回复设置</h2>
    <div class="hint" id="grhint">用户 @ 或触发关键词后，开始与这个人持续对话：接话时间内没继续聊就沉默；聊天中每条都会刷新计时。频率限制每分钟回复条数。</div>
    <div style="display:flex;gap:8px;margin:10px 0;align-items:center;flex-wrap:wrap">
      <span style="color:#9aa4b8;font-size:13px">接话时间</span>
      <input id="grsecs" type="number" min="30" style="width:100px"> <span style="color:#9aa4b8;font-size:13px">秒</span>
      <span style="color:#9aa4b8;font-size:13px;margin-left:6px">频率</span>
      <input id="grcap" type="number" min="1" style="width:80px"> <span style="color:#9aa4b8;font-size:13px">条/分钟</span>
      <button onclick="saveGRConfig()">保存</button>
    </div>
    <div style="display:flex;gap:8px;margin:10px 0;align-items:center;flex-wrap:wrap">
      <span style="color:#9aa4b8;font-size:13px">最多同时接话人数</span>
      <input id="gramax" type="number" min="1" max="20" style="width:80px">
      <button id="thriftbtn" onclick="toggleThrift()">省流模式：加载中</button>
      <button id="atreplybtn" onclick="toggleAtReply()">被@时回复@对方：加载中</button>
      <span class="hint">省流模式：只回 @/关键词/接话名单，且固定只发一条消息</span>
    </div>
    <div class="msg" id="grmsg"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">当前接话中的用户（临时数据）</h2>
    <div class="hint">这些是触发过 @/关键词、正在接话窗口内的用户。到期自动删除（每 3 分钟自检一次清理）。</div>
    <div style="margin:8px 0"><button onclick="loadConvos()">刷新列表</button></div>
    <div id="convlist"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">群列表（来自白名单）</h2>
    <div class="hint">点「一直接话」后，该群所有消息都会被回复（不用 @/关键词），且不受群回复间隔限制，每分钟最多 10 条；再点一次关闭。</div>
    <div id="grlist" style="margin-top:8px"></div>
  </div>
</div>

<div id="stk" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">表情包设置</h2>
    <div class="hint">机器人回复时按概率附带一张随机表情包（概率 0 = 关闭）。表情包通过本网站公开地址访问，QQ 客户端需要能打开该地址（隧道换地址后需重新上传一张或点保存刷新）。</div>
    <div style="display:flex;gap:8px;align-items:center;margin:10px 0;flex-wrap:wrap">
      <span style="color:#9aa4b8;font-size:13px">附带概率</span>
      <input id="stkprob" type="number" min="0" max="100" style="width:80px">
      <span style="color:#9aa4b8;font-size:13px">%</span>
      <button onclick="saveStickerProb()">保存</button>
    </div>
    <div style="display:flex;gap:8px;margin:10px 0;align-items:center;flex-wrap:wrap">
      <span style="color:#9aa4b8;font-size:13px">选表情方式</span>
      <button id="skmrandom" onclick="setStickerMode('random')">随机</button>
      <button id="skmsmart" onclick="setStickerMode('smart')">智能匹配</button>
    </div>
    <div class="msg" id="stkmsg"></div>
    <div class="hint" id="stkbase"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">表情包库（上传）</h2>
    <div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap;align-items:center">
      <input id="stkfile" type="file" accept="image/*" multiple>
      <button onclick="uploadSticker()">上传</button>
      <button onclick="uploadStickerMany()" style="background:#0e7490">批量上传</button>
    </div>
    <div class="hint">批量上传：一次选中多张图片（支持 png/jpg/gif/webp，每张 ≤2MB）。</div>
    <div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap;align-items:flex-start">
      <textarea id="stkurls" placeholder="也可以粘图片直链，一行一个（http/https）" rows="3" style="flex:1;min-width:240px;background:#0b0d11;color:#e6e6e6;border:1px solid #2a2f3a;border-radius:8px;padding:9px;box-sizing:border-box"></textarea>
      <button onclick="addStickerUrls()" style="background:#0e7490">导入链接</button>
    </div>
    <div id="stklist"></div>
  </div>
</div>

<div id="end" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">结束语删除接话</h2>
    <div class="hint">用户在群里说了下面的触发词时，机器人立即结束与他的接话（不再追着聊），并发送"最后一句"。可自定义触发词与最后一句。</div>
    <div style="margin:10px 0"><button id="endtoggle" onclick="toggleEnd()">加载中…</button></div>
    <div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap;align-items:center">
      <span style="color:#9aa4b8;font-size:13px">最后一句</span>
      <input id="endreply" placeholder="如：好的，那我退下了（留空则不发）" style="flex:1;min-width:150px">
      <button onclick="saveEndReply2()">保存</button>
    </div>
    <div class="msg" id="endmsg"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">触发词（消息包含任意一个即触发）</h2>
    <div style="display:flex;gap:8px;margin:10px 0">
      <input id="endinput" placeholder="新增触发词（≤30字）" style="flex:1">
      <button onclick="addEndPhrase()">添加</button>
    </div>
    <div id="endlist"></div>
  </div>
</div>

<div id="rate" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">分段回复</h2>
    <div class="hint">把一次回复拆成几条消息发出去，像真人连发。省流模式开启时强制只发 1 条。</div>
    <div style="margin:14px 0 6px;color:#9aa4b8;font-size:13px">回复方式</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button id="segfixed" onclick="setSegMode('fixed')">固定条数</button>
      <button id="segrandom" onclick="setSegMode('random')">随机条数</button>
    </div>
    <div class="hint" style="margin-top:6px">固定：每次都发一样多；随机：在「最少 ~ 最多」之间随机。</div>
    <div class="memgrid" style="margin-top:14px">
      <label id="segfixedwrap">固定条数（条）<input id="segfixedn" type="number" min="1" max="10"></label>
      <label id="segrandwrap1">随机最少（条）<input id="segmin" type="number" min="1" max="10"></label>
      <label id="segrandwrap2">随机最多（条）<input id="segmax" type="number" min="1" max="10"></label>
    </div>
    <div style="margin-top:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <button onclick="saveSegConfig()">保存分段设置</button>
      <span class="msg" id="segmsg"></span>
    </div>
  </div>

  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">发送节奏</h2>
    <div class="hint">控制"等多久才发"。数值越大越像真人，太大回复会显得慢。</div>
    <div class="memgrid" style="margin-top:14px">
      <label>首句延迟（毫秒）<input id="segfirst" type="number" min="0" max="10000"></label>
      <label>消息间隔（毫秒）<input id="segdelay" type="number" min="0" max="10000"></label>
      <label>表情包延迟（毫秒）<input id="segsticker" type="number" min="0" max="10000"></label>
    </div>
    <div class="hint" style="margin-top:8px">1000 毫秒 = 1 秒。推荐：首句 300、间隔 600、表情包 800。</div>
    <div style="margin-top:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <button onclick="saveSegTiming()">保存节奏设置</button>
      <span class="msg" id="segmsg2"></span>
    </div>
  </div>

  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">每个群的回复频率</h2>
    <div class="hint">防止回太快被 QQ 判定为机器人：给每个群单独限制「每分钟最多几条」和「两条之间至少隔几秒」。没设置的群用默认值。</div>
    <div class="hint" id="ratedefault"></div>
    <div class="hint" style="margin-top:6px">群号 ｜ 每分钟最多回几条 ｜ 两条之间至少隔几秒（留空 = 用默认）</div>
    <div id="ratelist"></div>
  </div>
</div>

<div id="bored" class="hidden">
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">无聊模式</h2>
    <div class="hint">群聊多久没有新消息后，大肥鱼会主动发一段"废话文学"来活跃气氛（内容都是方便别人接话的问句）。只在白名单群生效。</div>
    <div style="margin:12px 0">
      <button id="boredbtn" onclick="toggleBored()">加载中…</button>
      <span id="boredstate" style="margin-left:10px;color:#9aa4b8;font-size:13px"></span>
    </div>
    <div style="display:flex;gap:8px;margin:10px 0;align-items:center;flex-wrap:wrap">
      <span style="color:#9aa4b8;font-size:13px">触发方式</span>
      <button id="btf" onclick="setBoredTimeMode('fixed')">固定间隔</button>
      <button id="btr" onclick="setBoredTimeMode('random')">随机区间</button>
    </div>
    <div style="display:flex;gap:8px;margin:10px 0;align-items:center;flex-wrap:wrap">
      <span style="color:#9aa4b8;font-size:13px">固定间隔</span>
      <input id="boredfixed" type="number" min="1" style="width:80px">
      <span style="color:#9aa4b8;font-size:13px">分钟</span>
      <span style="color:#6b7280;font-size:12px">（固定模式生效）</span>
    </div>
    <div style="display:flex;gap:8px;margin:10px 0;align-items:center;flex-wrap:wrap">
      <span style="color:#9aa4b8;font-size:13px">随机触发</span>
      <input id="boredmin" type="number" min="1" style="width:80px">
      <span style="color:#9aa4b8;font-size:13px">~</span>
      <input id="boredmax" type="number" min="1" style="width:80px">
      <span style="color:#9aa4b8;font-size:13px">分钟</span>
      <span style="color:#9aa4b8;font-size:13px;margin-left:6px">最小间隔</span>
      <input id="boredfloor" type="number" min="1" style="width:80px">
      <span style="color:#9aa4b8;font-size:13px">分钟</span>
      <button onclick="saveBoredInterval()">保存</button>
    </div>
    <div style="display:flex;gap:8px;margin:10px 0;align-items:center">
      <span style="color:#9aa4b8;font-size:13px">语料来源</span>
      <button id="modepool" onclick="setBoredMode('pool')">静态语料</button>
      <button id="modeai" onclick="setBoredMode('ai')">AI 自创</button>
    </div>
    <div class="msg" id="boredmsg"></div>
  </div>
  <div class="card">
    <h2 style="font-size:14px;color:#8b93a5;margin:0 0 8px">静态语料库</h2>
    <div class="hint">静态模式下随机从这里选一条发；AI 自创模式下忽略这里。可自由增删。</div>
    <div style="display:flex;gap:8px;margin:10px 0">
      <input id="blinput" placeholder="新增一句废话文学（≤100字）" style="flex:1">
      <button onclick="addBoredLine()">添加</button>
    </div>
    <div id="bllist"></div>
  </div>
</div>

<footer style="text-align:center;color:#4b5563;font-size:12px;line-height:1.9;padding:18px 0 8px">
  本源码完全免费发布，请勿购买｜作者 QQ：2844642318｜交流群：243625638
</footer>
</main>
<script>
const B = '__BASE__';
function el(id){return document.getElementById(id)}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function fmtUptime(s){const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return (h?h+'小时':'')+m+'分钟'}

const GROUP_DEFS = [
  {key:'status', label:'状态', roles:['super','admin'], subs:{super:[['status','状态']],admin:[['status','状态']]}},
  {key:'bot', label:'机器人', roles:['super'], subs:{super:[['persona','人设'],['pv','模型'],['voice','语音'],['rest','休息'],['settings','设置']]}},
  {key:'chat', label:'聊天', roles:['super','admin'], subs:{
    super:[['auto','接话模式'],['gr','群聊回复'],['rate','回复频率'],['kw','关键词'],['pf','回复前缀'],['end','结束语'],['stk','表情包'],['bored','无聊模式']],
    admin:[['auto','接话模式'],['gr','群聊回复'],['rate','回复频率'],['kw','关键词'],['pf','回复前缀'],['end','结束语'],['stk','表情包'],['bored','无聊模式']]
  }},
  {key:'wl', label:'白名单', roles:['super','admin','user'], subs:{
    super:[['wl','白名单']],
    admin:[['wl','白名单']],
    user:[['wl','白名单']]
  }},
  {key:'superadmin', label:'超级管理员', roles:['super'], subs:{
    super:[['super','超级管理员']]
  }},
  {key:'acct', label:'账号', roles:['super','admin'], subs:{
    super:[['qr','扫码登录'],['accounts','账号管理'],['logins','登录日志']],
    admin:[['accounts','账号管理'],['logins','登录日志']]
  }},
  {key:'logout', label:'退出'}
];
let CURRENT_ROLE = 'super';
const ALL_SECTIONS = '#status,#rest,#settings,#super,#persona,#pv,#voice,#qr,#wl,#kw,#pf,#auto,#gr,#end,#bored,#rate,#stk,#accounts,#logins,#mem';
function showTab(name){
  document.querySelectorAll(ALL_SECTIONS).forEach(x=>x.classList.add('hidden'));
  const node = el(name);
  if(node) node.classList.remove('hidden');
  if(name==='wl') loadWL();
  if(name==='kw') loadKW();
  if(name==='pf') loadPrefix();
  if(name==='auto') loadAuto();
  if(name==='gr') loadGR();
  if(name==='bored') loadBored();
  if(name==='rest') loadRest();
  if(name==='settings') loadSettings();
  if(name==='super') loadSuper();
  if(name==='persona') loadPersona();
  if(name==='pv') loadProviders();
  if(name==='voice') loadVoice();
  if(name==='end') loadEnd();
  if(name==='rate') loadRate();
  if(name==='stk') loadStickers();
  if(name==='status') loadFriendBrief();
  if(name==='accounts') loadAccounts();
  if(name==='logins') loadLoginLogs();
}
function subsFor(key){
  const eff = (CURRENT_ROLE === 'viewer') ? 'super' : CURRENT_ROLE;
  const g = GROUP_DEFS.find(x=>x.key===key);
  if(!g || !g.subs) return [];
  let items = g.subs[eff] || g.subs.super || [];
  if(CURRENT_ROLE === 'viewer'){
    items = items.filter(function(pair){ return pair[0] !== 'logins'; });
  }
  return items;
}
function renderSubtabs(key){
  const items = subsFor(key);
  const bar = el('subtabs');
  bar.innerHTML = '';
  bar.style.display = items.length > 1 ? 'flex' : 'none';
  items.forEach(function(pair, idx){
    const d = document.createElement('div');
    d.className = 'tab' + (idx === 0 ? ' on' : '');
    d.textContent = pair[1];
    d.onclick = function(){
      bar.querySelectorAll('.tab').forEach(x=>x.classList.toggle('on', x === d));
      showTab(pair[0]);
    };
    bar.appendChild(d);
  });
  if(items.length) showTab(items[0][0]);
}
function buildTabs(){
  const bar = el('tabs');
  bar.innerHTML = '';
  let first = null;
  const effRole = (CURRENT_ROLE === 'viewer') ? 'super' : CURRENT_ROLE;
  GROUP_DEFS.forEach(function(g){
    if(g.key === 'logout'){
      const d = document.createElement('div');
      d.className = 'tab'; d.textContent = '退出';
      d.onclick = function(){ fetch(B + '/api/logout',{method:'POST'}).then(function(){ location.reload(); }); };
      bar.appendChild(d);
      return;
    }
    if(g.roles.indexOf(effRole) === -1) return;
    const d = document.createElement('div');
    d.className = 'tab';
    if(g.key === 'bot') d.innerHTML = '机器人 <span id="updot" style="display:none;color:#f87171">●</span>';
    else d.textContent = g.label;
    d.onclick = function(){
      bar.querySelectorAll('.tab').forEach(x=>x.classList.toggle('on', x === d));
      renderSubtabs(g.key);
    };
    bar.appendChild(d);
    if(!first) first = d;
  });
  if(first){ first.classList.add('on'); first.onclick(); }
}
function isDesktopNav(){ return window.matchMedia('(min-width: 900px)').matches; }
function buildSidebar(){
  const bar = el('tabs');
  bar.innerHTML = '';
  const effRole = (CURRENT_ROLE === 'viewer') ? 'super' : CURRENT_ROLE;
  let firstGroup = null;
  GROUP_DEFS.forEach(function(g){
    if(g.key === 'logout'){
      const d = document.createElement('div');
      d.className = 'tab'; d.textContent = '退出';
      d.onclick = function(){ fetch(B + '/api/logout',{method:'POST'}).then(function(){ location.reload(); }); };
      bar.appendChild(d);
      return;
    }
    if(g.roles.indexOf(effRole) === -1) return;
    const wrap = document.createElement('div');
    wrap.className = 'navgroup';
    const main = document.createElement('div');
    main.className = 'tab';
    if(g.key === 'bot') main.innerHTML = '机器人 <span id="updot" style="display:none;color:#f87171">●</span>';
    else main.textContent = g.label;
    const subs = document.createElement('div');
    subs.className = 'subs';
    const items = subsFor(g.key);
    items.forEach(function(pair){
      const d = document.createElement('div');
      d.className = 'tab';
      d.textContent = pair[1];
      d.onclick = function(ev){
        if(ev) ev.stopPropagation();
        subs.querySelectorAll('.tab').forEach(function(x){ x.classList.toggle('on', x === d); });
        showTab(pair[0]);
      };
      subs.appendChild(d);
    });
    if(items.length === 1){
      main.onclick = function(){
        bar.querySelectorAll('.navgroup').forEach(function(x){ x.classList.remove('open'); });
        showTab(items[0][0]);
      };
      wrap.appendChild(main);
      bar.appendChild(wrap);
      if(!firstGroup) firstGroup = wrap;
      return;
    }
    main.onclick = function(){
      const wasOpen = wrap.classList.contains('open');
      bar.querySelectorAll('.navgroup').forEach(function(x){ x.classList.remove('open'); });
      if(!wasOpen){ wrap.classList.add('open'); }
      const first = subs.querySelector('.tab');
      if(first && !wasOpen) first.click();
    };
    wrap.appendChild(main);
    wrap.appendChild(subs);
    bar.appendChild(wrap);
    if(!firstGroup) firstGroup = wrap;
  });
  if(firstGroup){
    firstGroup.classList.add('open');
    const f = firstGroup.querySelector('.subs .tab');
    if(f) f.click();
  }
}
(function(){
  const orig = window.fetch.bind(window);
  const cache = new Map();
  let pending = 0;
  let busyBtns = [];
  window.__dshBusy = function(){ return pending > 0; };
  const release = function(){
    busyBtns.forEach(function(b){ b.disabled = false; });
    busyBtns = [];
  };
  document.addEventListener('click', function(e){
    const b = e.target && e.target.closest ? e.target.closest('button') : null;
    if(!b || b.disabled) return;
    setTimeout(function(){
      if(pending > 0 && !b.disabled){
        b.disabled = true;
        busyBtns.push(b);
      }
    }, 0);
  }, true);
  window.fetch = function(input, init){
    const method = ((init && init.method) || 'GET').toUpperCase();
    const url = (typeof input === 'string') ? input : ((input && input.url) || '');
    const key = method + ' ' + url;
    if(method === 'GET' && url.indexOf('/api/') !== -1){
      const hit = cache.get(key);
      if(hit && Date.now() - hit.t < 8000){
        return Promise.resolve(hit.r.clone());
      }
    }
    if(method !== 'GET') cache.clear();
    pending++;
    const bar = document.getElementById('pbar');
    if(bar){ bar.style.opacity = '1'; bar.style.width = '35%'; }
    return orig.apply(null, arguments).then(function(resp){
      if(method === 'GET' && url.indexOf('/api/') !== -1){
        try{ cache.set(key, { r: resp.clone(), t: Date.now() }); }catch(e){}
      }
      return resp;
    }).finally(function(){
      pending = Math.max(0, pending - 1);
      if(pending === 0){
        release();
        if(bar){ bar.style.width = '100%'; setTimeout(function(){ bar.style.width = '0'; bar.style.opacity = '0'; }, 180); }
      }
    });
  };
})();
async function initNav(){
  try{
    const r = await fetch(B + '/api/me').then(r=>r.json());
    if(r.code !== 0){ location.reload(); return; }
    CURRENT_ROLE = r.role || 'user';
    if(CURRENT_ROLE === 'viewer'){
      document.body.classList.add('viewer');
      const bar = document.createElement('div');
      bar.style.cssText = 'text-align:center;color:#fbbf24;font-size:13px;padding:8px 12px;border-bottom:1px solid #2a2f3a;background:rgba(251,191,36,.08)';
      bar.textContent = '观察者模式：只能查看，所有操作按钮已禁用';
      document.body.insertBefore(bar, document.body.firstChild);
    }
    if(isDesktopNav()) buildSidebar(); else buildTabs();
    window.addEventListener('resize', function(){
      const desktop = isDesktopNav();
      if(desktop !== window.__navDesktop){
        window.__navDesktop = desktop;
        if(desktop) buildSidebar(); else buildTabs();
      }
    });
    window.__navDesktop = isDesktopNav();
    if(CURRENT_ROLE !== 'user'){
      refreshStatus();
      setInterval(refreshStatus, 15000);
    }
  }catch(e){ location.reload(); }
}
initNav();

let BOT_EXPECT_NICK = '';
async function loadBlacklist(){
  const r = await fetch(B + '/api/blacklist').then(r=>r.json());
  const box = el('blacklist');
  box.innerHTML = '';
  if(!r.list || !r.list.length){
    const h = document.createElement('div'); h.className='hint'; h.textContent = '（空）';
    box.appendChild(h);
    return;
  }
  r.list.forEach(function(item){
    const qq = item.qq;
    const row = document.createElement('div'); row.className='item';
    const img = document.createElement('img');
    img.src = 'https://q1.qlogo.cn/g?b=qq&nk=' + qq + '&s=100';
    img.style.cssText = 'width:34px;height:34px;border-radius:50%;vertical-align:middle;margin-right:8px;background:#222;flex:none';
    const span = document.createElement('span');
    let label = qq;
    if(item.nick){ label += ' · ' + item.nick; }
    span.textContent = label;
    span.style.cssText = 'flex:1;word-break:break-all';
    const btn = document.createElement('button'); btn.textContent = '移出';
    btn.style.background = '#b91c1c';
    btn.onclick = function(){ delBlack(qq); };
    row.appendChild(img); row.appendChild(span); row.appendChild(btn);
    box.appendChild(row);
  });
}
async function addBlack(){
  const qq = el('blackqq').value.trim();
  if(!qq){ el('blackmsg').textContent='先填 QQ 号'; return; }
  const r = await fetch(B + '/api/blacklist/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({qq: qq})}).then(r=>r.json());
  el('blackmsg').textContent = r.code===0 ? '已加入黑名单' : (r.message||'添加失败');
  el('blackmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){ el('blackqq').value=''; loadBlacklist(); }
}
async function delBlack(qq){
  const r = await fetch(B + '/api/blacklist/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({qq: qq})}).then(r=>r.json());
  if(r.code===0) loadBlacklist();
}
async function loadBotProfile(refresh){
  const r = await fetch(B + '/api/bot-profile' + (refresh ? '?refresh=1' : '')).then(r=>r.json());
  if(r.code!==0) return null;
  el('botuin').textContent = r.uin || '-';
  el('botnicklabel').textContent = r.nick || '-';
  if(r.avatar){
    el('botavatar').src = r.avatar + '&t=' + Date.now();
  }
  el('botnick').placeholder = '新昵称（当前：' + (r.nick||'-') + '）';
  return r;
}
async function syncBotName(attempt){
  const r = await loadBotProfile(true);
  if(!r) return;
  if(BOT_EXPECT_NICK && r.nick !== BOT_EXPECT_NICK && attempt < 3){
    setTimeout(function(){ syncBotName(attempt + 1); }, 60000);
  } else if(BOT_EXPECT_NICK && r.nick === BOT_EXPECT_NICK){
    el('botmsg').textContent = '昵称已同步：' + r.nick;
    el('botmsg').style.color = '#4ade80';
  }
}
async function saveBotNick(){
  const nick = el('botnick').value.trim();
  if(!nick){ el('botmsg').textContent = '先填昵称'; return; }
  const r = await fetch(B + '/api/bot-profile/nick',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nickname: nick})}).then(r=>r.json());
  el('botmsg').textContent = r.code===0 ? '昵称已修改' : (r.message||'修改失败');
  el('botmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){
    el('botnick').value='';
    BOT_EXPECT_NICK = nick;
    el('botmsg').textContent = '已提交修改，1 分钟后自动同步昵称…';
    el('botmsg').style.color = '#4ade80';
    setTimeout(function(){ syncBotName(0); }, 60000);
  }
}
async function saveBotAvatar(){
  const url = el('botavatarurl').value.trim();
  if(!url){ el('botmsg').textContent = '先填图片地址'; return; }
  const r = await fetch(B + '/api/bot-profile/avatar',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url: url})}).then(r=>r.json());
  el('botmsg').textContent = r.code===0 ? '头像已提交修改（QQ 生效可能有延迟）' : (r.message||'修改失败');
  el('botmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){ el('botavatarurl').value=''; loadBotProfile(); }
}
async function loadRest(){
  let r;
  try{
    r = await fetch(B + '/api/rest').then(r=>r.json());
  }catch(e){
    r = {code:-1};
  }
  if(r.code!==0){
    el('restbtn').textContent = '休息模式：加载失败，点击重试';
    el('restbtn').style.background = '#7f1d1d';
    el('restnotifybtn').textContent = '休息通知：加载失败';
    el('reststatus').textContent = '接口请求失败，请刷新页面';
    return;
  }
  el('reststart').value = r.start || '22:00';
  el('restend').value = r.end || '08:00';
  const btn = el('restbtn');
  btn.textContent = r.enabled ? '休息模式：已开启' : '休息模式：已关闭';
  btn.style.background = r.enabled ? '#16a34a' : '#4b5563';
  const nb = el('restnotifybtn');
  nb.textContent = r.notify ? '休息通知：已开启' : '休息通知：已关闭';
  nb.style.background = r.notify ? '#16a34a' : '#4b5563';
  el('reststatus').textContent = r.enabled
    ? (r.in_rest ? '当前处于休息时间：只回复超管私聊和休息白名单' : '当前不在休息时间段，正常回复')
    : '未开启休息模式，全天正常回复';
  renderRestList('restglist', r.groups || [], 'group');
  renderRestNotify(r.notify_groups || []);
  renderRestList('restulist', r.users || [], 'user');
  const g = (r.groups||[]).length, u = (r.users||[]).length;
  el('restwl').textContent = u === 0
    ? ('休息 QQ 白名单为空 → 休息时只回复超级管理员私聊（防封号推荐）')
    : ('群 ' + g + ' 个，QQ ' + u + ' 个；休息时只回复这些群/QQ 和超级管理员私聊');
}
function renderRestList(boxId, values, type){
  const box = el(boxId);
  box.innerHTML = '';
  if(!values.length){
    const h = document.createElement('div'); h.className='hint'; h.textContent='（空）';
    box.appendChild(h);
    return;
  }
  values.forEach(function(v){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span'); span.textContent = v;
    const btn = document.createElement('button'); btn.textContent = '删除';
    btn.style.background = '#b91c1c';
    btn.onclick = function(){ delRestWL(type, v); };
    row.appendChild(span); row.appendChild(btn);
    box.appendChild(row);
  });
}
async function addRestWL(type){
  const input = type === 'group' ? el('restg') : el('restu');
  const value = input.value.trim();
  if(!value){ el('restmsg').textContent='先填数字'; return; }
  const r = await fetch(B + '/api/rest/wl',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type: type, action: 'add', value: value})}).then(r=>r.json());
  el('restmsg').textContent = r.code===0 ? '已添加' : (r.message||'添加失败');
  el('restmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){ input.value=''; loadRest(); }
}
async function delRestWL(type, value){
  const r = await fetch(B + '/api/rest/wl',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type: type, action: 'remove', value: value})}).then(r=>r.json());
  if(r.code===0) loadRest();
}
async function importRestWL(){
  const r = await fetch(B + '/api/rest/import',{method:'POST'}).then(r=>r.json());
  el('restmsg').textContent = r.code===0 ? '已导入现有群/QQ白名单' : (r.message||'导入失败');
  el('restmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadRest();
}
async function toggleRest(){
  const cur = el('restbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/rest/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled: !cur})}).then(r=>r.json());
  if(r.code===0) loadRest(); else alert(r.message||'操作失败');
}
function renderRestNotify(values){
  const box = el('restnotifylist');
  box.innerHTML = '';
  if(!values.length){
    const h = document.createElement('div'); h.className='hint'; h.textContent='（未设置通知群，不发送休息通知）';
    box.appendChild(h);
    return;
  }
  values.forEach(function(v){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span'); span.textContent = v;
    const btn = document.createElement('button'); btn.textContent = '删除';
    btn.style.background = '#b91c1c';
    btn.onclick = function(){ delRestNotifyGroup(v); };
    row.appendChild(span); row.appendChild(btn);
    box.appendChild(row);
  });
}
async function addRestNotifyGroup(){
  const value = el('restnotifyg').value.trim();
  if(!value){ el('restmsg').textContent='先填群号'; return; }
  const r = await fetch(B + '/api/rest/notify-groups',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add', value: value})}).then(r=>r.json());
  el('restmsg').textContent = r.code===0 ? '已添加通知群' : (r.message||'添加失败');
  el('restmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){ el('restnotifyg').value=''; loadRest(); }
}
async function delRestNotifyGroup(value){
  const r = await fetch(B + '/api/rest/notify-groups',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'remove', value: value})}).then(r=>r.json());
  if(r.code===0) loadRest();
}
async function toggleRestNotify(){
  const cur = el('restnotifybtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/rest/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({notify: !cur})}).then(r=>r.json());
  if(r.code===0) loadRest(); else alert(r.message||'操作失败');
}
async function saveRestTime(){
  const r = await fetch(B + '/api/rest/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({start: el('reststart').value, end: el('restend').value})}).then(r=>r.json());
  el('restmsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('restmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadRest();
}
async function loadSettings(){
  const r = await fetch(B + '/api/update').then(r=>r.json());
  renderUpdate(r);
}
function renderUpdate(r){
  if(!r || r.code !== 0) return;
  let line = '当前版本：' + (r.current || '-');
  if(r.latest){
    line += ' ｜ 最新：' + r.latest + (r.date ? '（' + r.date + '）' : '');
  } else if(r.error){
    line += ' ｜ 检查失败：' + r.error;
  }
  el('verline').textContent = line;
  el('vernotes').textContent = r.notes ? ('更新说明：' + r.notes) : '';
  const dot = el('updot');
  dot.style.display = r.has_update ? 'inline' : 'none';
  const btn = el('checkbtn');
  if(r.has_update){
    btn.textContent = r.force ? ('强制更新 → ' + (r.latest||'')) : ('立即更新 → ' + (r.latest||''));
    btn.style.background = '#16a34a';
    btn.onclick = applyUpdate;
    el('updatemsg').textContent = r.force ? '该版本要求强制更新' : '发现新版本，点击绿色按钮更新';
    el('updatemsg').style.color = r.force ? '#f87171' : '#fbbf24';
  } else {
    btn.textContent = '检查更新';
    btn.style.background = '#2563eb';
    btn.onclick = function(){ checkUpdate(true); };
  }
}
async function checkUpdate(force){
  const btn = el('checkbtn');
  btn.disabled = true;
  btn.textContent = '检查中…';
  el('updatemsg').textContent = '正在检查更新…';
  el('updatemsg').style.color = '#9aa4b8';
  try{
    const resp = await fetch(B + '/api/update' + (force ? '/check' : ''), {method:'POST'});
    if(!resp.ok) throw new Error('HTTP ' + resp.status);
    const r = await resp.json();
    if(r.code===0){
      renderUpdate(r);
      if(!r.has_update){
        el('updatemsg').textContent = '已是最新版本';
        el('updatemsg').style.color = '#4ade80';
      }
    } else {
      btn.textContent = '检查更新';
      el('updatemsg').textContent = r.message || '检查失败';
      el('updatemsg').style.color = '#f87171';
    }
  }catch(e){
    btn.textContent = '检查更新';
    el('updatemsg').textContent = '检查失败：' + (e && e.message ? e.message : '网络错误');
    el('updatemsg').style.color = '#f87171';
  }finally{
    btn.disabled = false;
    if(btn.textContent === '检查中…'){ btn.textContent = '检查更新'; }
  }
}
async function applyUpdate(){
  if(!confirm('确定更新到最新版本？更新后会自动重启，数据保留')) return;
  el('updatemsg').textContent = '下载并校验中…';
  const r = await fetch(B + '/api/update/apply',{method:'POST'}).then(r=>r.json());
  el('updatemsg').textContent = r.message || (r.code===0 ? '更新成功，重启中…' : '更新失败');
  el('updatemsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
}
function superTab(name, node){
  document.querySelectorAll('.superpanel').forEach(function(x){ x.classList.add('hidden'); });
  const panel = el('super-' + name);
  if(panel) panel.classList.remove('hidden');
  if(name === 'friend') loadFriend();
  const bar = el('supertabs');
  if(bar) bar.querySelectorAll('.tab').forEach(function(t){ t.classList.toggle('on', t === node); });
}
async function loadFriend(){
  const r = await fetch(B + '/api/friend').then(r=>r.json());
  if(r.code!==0){ el('friendlist').textContent = r.message || '无权限'; return; }
  el('fautobtn').textContent = r.auto ? '自动通过：已开启' : '自动通过：已关闭';
  el('fautobtn').style.background = r.auto ? '#16a34a' : '#4b5563';
  el('fnotifybtn').textContent = r.notify ? '超管提醒：已开启' : '超管提醒：已关闭';
  el('fnotifybtn').style.background = r.notify ? '#16a34a' : '#4b5563';
  el('flimit').value = r.limit;
  const box = el('friendlist'); box.innerHTML = '';
  const head = document.createElement('div'); head.className='hint';
  head.textContent = '今天：共 ' + r.today_total + ' 个申请，已通过 ' + r.today_accepted + ' 个';
  box.appendChild(head);
  if(!r.list.length){
    const h = document.createElement('div'); h.className='hint'; h.textContent='（暂无好友申请记录）';
    box.appendChild(h); return;
  }
  const labels = {pending:'待处理', accepted:'已通过', rejected:'已拒绝', overlimit:'超上限', failed:'处理失败'};
  r.list.forEach(function(it){
    const row = document.createElement('div'); row.className='item'; row.style.flexWrap='wrap'; row.style.gap='6px';
    const span = document.createElement('span'); span.style.flex='1'; span.style.minWidth='200px';
    span.textContent = it.user_id + ' · ' + (labels[it.action]||it.action) + (it.comment ? (' · ' + it.comment) : '') + ' · ' + (it.created_at||'');
    row.appendChild(span);
    if(it.action === 'pending'){
      const ok = document.createElement('button'); ok.textContent='通过';
      ok.onclick = function(){ friendAct(it.flag, true); };
      row.appendChild(ok);
      const no = document.createElement('button'); no.className='danger'; no.textContent='拒绝';
      no.onclick = function(){ friendAct(it.flag, false); };
      row.appendChild(no);
    }
    box.appendChild(row);
  });
}
async function toggleFriendAuto(){
  const cur = el('fautobtn').textContent.indexOf('已开启') !== -1;
  await fetch(B + '/api/friend/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({auto: !cur})});
  loadFriend();
}
async function toggleFriendNotify(){
  const cur = el('fnotifybtn').textContent.indexOf('已开启') !== -1;
  await fetch(B + '/api/friend/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({notify: !cur})});
  loadFriend();
}
async function saveFriendCfg(){
  await fetch(B + '/api/friend/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({limit: el('flimit').value})});
  loadFriend();
}
async function friendAct(flag, approve){
  const r = await fetch(B + '/api/friend/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({flag:flag, approve:approve})}).then(r=>r.json());
  if(r.code!==0) alert(r.message||'处理失败'); else loadFriend();
}
async function loadFriendBrief(){
  try{
    const r = await fetch(B + '/api/friend').then(r=>r.json());
    if(r.code!==0){ el('friendbrief').textContent = '无权限查看'; return; }
    el('friendbrief').textContent = '今天收到 ' + r.today_total + ' 个好友申请，已通过 ' + r.today_accepted + ' 个；自动通过：' + (r.auto ? '开启' : '关闭');
    const box = el('friendrecent'); box.innerHTML = '';
    const labels = {pending:'待处理', accepted:'已通过', rejected:'已拒绝', overlimit:'超上限', failed:'处理失败'};
    r.list.slice(0,5).forEach(function(it){
      const row = document.createElement('div'); row.className='hint';
      row.textContent = it.user_id + ' · ' + (labels[it.action]||it.action) + ' · ' + (it.created_at||'');
      box.appendChild(row);
    });
  }catch(e){}
}
async function loadSuper(){
  const r = await fetch(B + '/api/super').then(r=>r.json());
  if(r.code!==0) return;
  el('superqqs').value = (r.qqs || []).join(',');
  const sb = el('simpbtn');
  sb.textContent = r.simp ? '舔狗模式：已开启' : '舔狗模式：已关闭';
  sb.style.background = r.simp ? '#16a34a' : '#4b5563';
  const eb = el('exclbtn');
  eb.textContent = r.exclusive ? '专一模式：已开启' : '专一模式：已关闭';
  eb.style.background = r.exclusive ? '#16a34a' : '#4b5563';
  el('exwin').value = r.window_seconds || 60;
  el('roastwords').value = r.roast_keywords || '怼';
  el('balwords').value = r.balance_keywords || '';
  el('capwords').value = r.sticker_capture_keywords || '';
  const cb = el('capbtn');
  if(cb){
    cb.textContent = r.sticker_capture ? '收录：已开启' : '收录：已关闭';
    cb.style.background = r.sticker_capture ? '#16a34a' : '#4b5563';
  }
  const rb = el('roastbtn');
  rb.textContent = r.roast ? '怼人模式：已开启' : '怼人模式：已关闭';
  rb.style.background = r.roast ? '#16a34a' : '#4b5563';
  el('superdesc').textContent = (r.qqs && r.qqs.length)
    ? ('当前超管：' + r.qqs.join('、'))
    : '还没填超管 QQ，下面两个模式不会生效';
  loadBotProfile();
  loadBlacklist();
}
async function saveCaptureWords(){
  const r = await fetch(B + '/api/super/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sticker_capture_keywords: el('capwords').value})}).then(r=>r.json());
  el('supermsg').textContent = r.code===0 ? '收录关键词已保存' : (r.message||'保存失败');
  el('supermsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadSuper();
}
async function toggleCapture(){
  const cur = el('capbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/super/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sticker_capture: !cur})}).then(r=>r.json());
  if(r.code!==0) alert(r.message||'操作失败'); else loadSuper();
}
async function saveBalanceWords(){
  const r = await fetch(B + '/api/super/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({balance_keywords: el('balwords').value})}).then(r=>r.json());
  el('supermsg').textContent = r.code===0 ? '余额关键词已保存' : (r.message||'保存失败');
  el('supermsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadSuper();
}
async function toggleRoast(){
  const cur = el('roastbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/super/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({roast: !cur})}).then(r=>r.json());
  if(r.code===0) loadSuper(); else alert(r.message||'操作失败');
}
async function saveRoastWords(){
  const r = await fetch(B + '/api/super/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({roast_keywords: el('roastwords').value})}).then(r=>r.json());
  el('supermsg').textContent = r.code===0 ? '触发词已保存' : (r.message||'保存失败');
  el('supermsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadSuper();
}
async function saveSuperWindow(){
  const r = await fetch(B + '/api/super/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({window_seconds: parseInt(el('exwin').value||'60')})}).then(r=>r.json());
  el('supermsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('supermsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadSuper();
}
async function saveSuperQQ(){
  const r = await fetch(B + '/api/super/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({qqs: el('superqqs').value})}).then(r=>r.json());
  el('supermsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('supermsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadSuper();
}
async function toggleSimp(){
  const cur = el('simpbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/super/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({simp: !cur})}).then(r=>r.json());
  if(r.code===0) loadSuper(); else alert(r.message||'操作失败');
}
async function toggleExclusive(){
  const cur = el('exclbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/super/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({exclusive: !cur})}).then(r=>r.json());
  if(r.code===0) loadSuper(); else alert(r.message||'操作失败');
}

let PERSONA_NEW = false;
let PERSONA_LIST = [];
async function loadMemory(){
  const q = el('memqq').value.trim(), kw = el('memkw').value.trim(), dt = el('memdate').value;
  const url = B + '/api/memory?qq=' + encodeURIComponent(q) + '&kw=' + encodeURIComponent(kw) + '&date=' + encodeURIComponent(dt);
  const r = await fetch(url).then(r=>r.json());
  if(r.code!==0){ alert(r.message||'无权限'); return; }
  const c = r.config;
  el('membtn').textContent = c.enabled ? '记忆模式：已开启' : '记忆模式：已关闭';
  el('membtn').style.background = c.enabled ? '#16a34a' : '#4b5563';
  el('memsuperdays').value = c.super_days;
  el('memnormaldays').value = c.normal_days;
  el('memsuperlimit').value = c.super_limit;
  el('memnormallimit').value = c.normal_limit;
  el('memsuperinject').value = c.super_inject;
  el('memnormalinject').value = c.normal_inject;
  el('memextract').value = c.extract_every;
  el('memcount').textContent = '共 ' + r.items.length + ' 条';
  const box = el('memlist'); box.innerHTML = '';
  if(!r.items.length){
    const parts = [];
    if(q) parts.push('QQ=' + q);
    if(kw) parts.push('关键词=' + kw);
    if(dt) parts.push('日期=' + dt);
    const h = document.createElement('div'); h.className='hint';
    h.textContent = parts.length > 1
      ? ('（没有匹配的记忆）当前条件：' + parts.join(' + ') + '，需同时满足，可减少条件再查')
      : ('（没有匹配的记忆' + (parts.length ? '：' + parts[0] : '') + '）');
    box.appendChild(h); return;
  }
  r.items.forEach(function(it){
    const row = document.createElement('div'); row.className='memitem';
    const main = document.createElement('div'); main.className='main';
    const title = document.createElement('div');
    const tag = document.createElement('span');
    tag.className = 'memtag' + (it.level === 'high' ? ' high' : '');
    tag.textContent = it.level === 'high' ? '超管' : '普通';
    title.appendChild(tag);
    if(it.permanent){
      const pt = document.createElement('span'); pt.className='memtag perm'; pt.textContent='永久';
      title.appendChild(pt);
    }
    const txt = document.createElement('span'); txt.textContent = it.content;
    title.appendChild(txt);
    main.appendChild(title);
    const meta = document.createElement('div'); meta.className='meta';
    meta.textContent = 'QQ ' + it.owner_qq + '　·　调用 ' + (it.use_count||0) + ' 次　·　' + (it.created_at||'');
    main.appendChild(meta);
    row.appendChild(main);

    const acts = document.createElement('div'); acts.className='acts';
    const ed = document.createElement('button'); ed.textContent='编辑';
    ed.onclick = function(){ memEdit(it); };
    acts.appendChild(ed);
    const del = document.createElement('button'); del.className='danger'; del.textContent='删除';
    del.onclick = function(){ memDelete(it.id); };
    acts.appendChild(del);
    const clr = document.createElement('button'); clr.textContent='清空该QQ'; clr.style.background='#7f1d1d';
    clr.onclick = function(){ if(confirm('清空 QQ ' + it.owner_qq + ' 的所有记忆？')) memClear(it.owner_qq); };
    acts.appendChild(clr);
    row.appendChild(acts);
    box.appendChild(row);
  });
}
async function aiReview(){
  if(!confirm('让 AI 逐条判断哪些记忆值得保留？会消耗少量 token。')) return;
  const r = await fetch(B + '/api/memory/ai_review').then(r=>r.json());
  if(r.code!==0){ alert(r.message||'审核失败'); return; }
  if(!r.ids || !r.ids.length){ alert('AI 认为当前记忆都值得保留'); return; }
  const sample = (r.samples||[]).join(' / ');
  if(!confirm('AI 建议删除 ' + r.ids.length + ' 条（共 ' + r.total + ' 条）。示例：' + sample + '。确定？')) return;
  const d = await fetch(B + '/api/memory/delete_many',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:r.ids})}).then(r=>r.json());
  if(d.code!==0){ alert(d.message||'删除失败'); return; }
  alert('已删除 ' + d.deleted + ' 条');
  loadMemory();
}
async function toggleMemory(){
  const cur = el('membtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/memory/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled: !cur})}).then(r=>r.json());
  if(r.code!==0){ alert(r.message||'操作失败'); return; }
  loadMemory();
}
async function saveMemoryConfig(){
  const body = {
    super_days: el('memsuperdays').value, normal_days: el('memnormaldays').value,
    super_limit: el('memsuperlimit').value, normal_limit: el('memnormallimit').value,
    super_inject: el('memsuperinject').value, normal_inject: el('memnormalinject').value,
    extract_every: el('memextract').value
  };
  const r = await fetch(B + '/api/memory/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).then(r=>r.json());
  el('memmsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('memmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadMemory();
}
async function memAdd(){
  const r = await fetch(B + '/api/memory/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    qq: el('memaddqq').value.trim(), content: el('memaddtext').value.trim(), level: el('memaddlevel').value
  })}).then(r=>r.json());
  if(r.code!==0){ alert(r.message||'添加失败'); return; }
  el('memaddtext').value=''; loadMemory();
}
async function memEdit(it){
  const v = prompt('修改记忆内容', it.content);
  if(!v) return;
  const r = await fetch(B + '/api/memory/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:it.id, content:v})}).then(r=>r.json());
  if(r.code!==0){ alert(r.message||'修改失败'); return; }
  loadMemory();
}
async function memDelete(id){
  if(!confirm('删除这条记忆？')) return;
  const r = await fetch(B + '/api/memory/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:id})}).then(r=>r.json());
  if(r.code!==0){ alert(r.message||'删除失败'); return; }
  loadMemory();
}
async function memClear(qq){
  const r = await fetch(B + '/api/memory/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({qq:qq})}).then(r=>r.json());
  if(r.code!==0){ alert(r.message||'清空失败'); return; }
  loadMemory();
}
async function memReset(){
  el('memqq').value=''; el('memkw').value=''; el('memdate').value='';
  loadMemory();
}
async function loadPersona(){
  const r = await fetch(B + '/api/personas').then(r=>r.json());
  if(r.code!==0) return;
  PERSONA_LIST = r.personas || [];
  const sel = el('personasel');
  sel.innerHTML = '<option value="0">默认人格（config）</option>' + PERSONA_LIST.map(function(p){
    return '<option value="'+p.id+'">'+p.name+'</option>';
  }).join('');
  const active = r.active && r.active !== '0' ? r.active : '0';
  sel.value = active;
  PERSONA_NEW = false;
  el('personatext').value = r.current;
  el('personaname').value = '';
  el('personalength').textContent = '当前：' + (sel.options[sel.selectedIndex]||{}).text + ' · ' + r.current.length + ' 字';
  try{
    const g = await fetch(B + '/api/persona').then(r=>r.json());
    const gb = el('genderbtn');
    if(gb){
      gb.textContent = g.gender_aware ? '性别感知：已开启' : '性别感知：已关闭';
      gb.style.background = g.gender_aware ? '#16a34a' : '#4b5563';
    }
  }catch(e){}
}
function onPersonaSelect(){
  const id = el('personasel').value;
  PERSONA_NEW = false;
  if(id === '0'){
    fetch(B + '/api/personas').then(r=>r.json()).then(function(r){
      el('personatext').value = r.default;
      el('personaname').value = '';
      el('personalength').textContent = '默认人格 · ' + r.default.length + ' 字';
    });
    return;
  }
  const p = PERSONA_LIST.find(function(x){ return String(x.id) === id; });
  if(p){
    el('personatext').value = p.content;
    el('personaname').value = p.name;
    el('personalength').textContent = p.name + ' · ' + p.content.length + ' 字';
  }
}
function newPersona(){
  PERSONA_NEW = true;
  el('personaname').value = '';
  el('personatext').value = '';
  el('personalength').textContent = '新建人格（填写名称和内容后保存）';
  el('personaname').focus();
}
async function toggleGender(){
  const cur = el('genderbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/persona/gender',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled: !cur})}).then(r=>r.json());
  if(r.code===0) loadPersona(); else alert(r.message||'操作失败');
}
async function savePersona(){
  const name = el('personaname').value.trim();
  const content = el('personatext').value.trim();
  const sel = el('personasel').value;
  const id = PERSONA_NEW ? null : (sel !== '0' ? sel : null);
  const r = await fetch(B + '/api/personas/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id: id, name: name, content: content})}).then(r=>r.json());
  el('personamsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('personamsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){ PERSONA_NEW=false; loadPersona(); }
}
async function activatePersona(){
  const id = el('personasel').value || '0';
  const r = await fetch(B + '/api/personas/activate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id: id})}).then(r=>r.json());
  if(r.code===0){ loadPersona(); } else alert(r.message||'切换失败');
}
async function deletePersona2(){
  const sel = el('personasel').value;
  if(sel === '0'){ alert('默认人格不能删除'); return; }
  if(!confirm('确定删除这个人格？')) return;
  const r = await fetch(B + '/api/personas/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id: sel})}).then(r=>r.json());
  if(r.code===0){ loadPersona(); } else alert(r.message||'删除失败');
}

async function loadVoice(){
  const r = await fetch(B + '/api/voice').then(r=>r.json());
  if(r.code!==0) return;
  const tb = el('ttsbtn');
  tb.textContent = r.tts_enabled ? 'TTS：已开启（点击关闭）' : 'TTS：已关闭（点击开启）';
  tb.style.background = r.tts_enabled ? '#16a34a' : '#4b5563';
  el('ttsprovider').value = r.tts_provider || 'edge';
  el('dbversion').value = r.doubao_version || 'v3';
  el('dbmodel').value = r.doubao_model || 'seed-audio-1.0';
  const sp = r.doubao_speaker || '';
  const known = Array.prototype.some.call(el('dbspeakersel').options, function(o){ return o.value === sp && sp !== '__custom__'; });
  if(sp && !known){ el('dbspeakersel').value = '__custom__'; el('dbspeaker').value = sp; }
  else { el('dbspeakersel').value = sp || 'zh_female_qingchezizi_uranus_bigtts'; el('dbspeaker').value = ''; }
  toggleSpeakerCustom();
  el('dbkeyinfo').textContent = r.doubao_api_key_masked ? ('当前 X-Api-Key：' + r.doubao_api_key_masked) : 'X-Api-Key 未配置';
  el('dbappid').value = r.doubao_appid || '';
  el('dbcluster').value = r.doubao_cluster || 'volcano_tts';
  el('dbvoice').value = r.doubao_voice || 'BV001_streaming';
  el('dbinfo').textContent = r.doubao_token_masked ? ('当前豆包 Token：' + r.doubao_token_masked) : '豆包 Token 未配置';
  toggleDoubaoFields();
  el('ttsvoice').innerHTML = r.voices.map(function(v){ return '<option value="'+v+'">'+v+'</option>'; }).join('');
  el('ttsvoice').value = r.tts_voice;
  el('ttsmode').value = r.tts_mode;
  const ab = el('asrbtn');
  ab.textContent = r.asr_enabled ? 'ASR：已开启（点击关闭）' : 'ASR：已关闭（点击开启）';
  ab.style.background = r.asr_enabled ? '#16a34a' : '#4b5563';
  el('asrengine').value = r.asr_engine || 'local';
  el('asrlocal').value = r.asr_local_model || 'base';
  el('asrbase').value = r.asr_base || '';
  el('asrmodel').value = r.asr_model || '';
  el('asrkeyinfo').textContent = r.asr_key_masked ? ('当前 ASR Key：' + r.asr_key_masked) : 'ASR Key 未配置';
  toggleASRFields();
}
function toggleSpeakerCustom(){
  const custom = el('dbspeakersel').value === '__custom__';
  el('dbspeaker').style.display = custom ? 'inline-block' : 'none';
}
function currentSpeaker(){
  const sel = el('dbspeakersel').value;
  return (sel === '__custom__') ? el('dbspeaker').value.trim() : sel;
}
function toggleASRFields(){
  el('asrapifields').style.display = (el('asrengine').value === 'api') ? 'block' : 'none';
}
function toggleDoubaoFields(){
  const show = el('ttsprovider').value === 'doubao';
  el('doubaofields').style.display = show ? 'block' : 'none';
  el('ttsvoice').parentElement.style.display = show ? 'none' : 'flex';
  if(show){
    const v3 = el('dbversion').value === 'v3';
    el('dbv3').style.display = v3 ? 'block' : 'none';
    el('dbv1').style.display = v3 ? 'none' : 'block';
  }
}
async function previewVoice(){
  const v = el('ttsvoice').value;
  el('voicemsg').textContent = '合成中…'; el('voicemsg').style.color = '#9aa4b8';
  try{
    const r = await fetch(B + '/api/voice/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({voice:v})}).then(r=>r.json());
    if(r.code===0){
      const box = el('voicepreview');
      box.style.display = 'block';
      const p = el('voiceplayer');
      p.src = r.audio;
      try { await p.play(); } catch(e) { /* 浏览器限制自动播放，等用户点播放条 */ }
      el('voicemsg').textContent = '已生成（' + v + '）：没自动播放就点上面的播放条';
      el('voicemsg').style.color = '#4ade80';
    } else {
      el('voicemsg').textContent = r.message||'合成失败'; el('voicemsg').style.color = '#f87171';
    }
  }catch(e){ el('voicemsg').textContent = '网络错误'; el('voicemsg').style.color = '#f87171'; }
}
async function toggleTTS(){
  const cur = el('ttsbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/voice/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tts_enabled: !cur})}).then(r=>r.json());
  if(r.code===0) loadVoice(); else alert(r.message||'操作失败');
}
async function toggleASR(){
  const cur = el('asrbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/voice/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({asr_enabled: !cur})}).then(r=>r.json());
  if(r.code===0) loadVoice(); else alert(r.message||'操作失败');
}
async function saveVoice(){
  const r = await fetch(B + '/api/voice/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    tts_voice: el('ttsvoice').value, tts_mode: el('ttsmode').value,
    tts_provider: el('ttsprovider').value,
    doubao_version: el('dbversion').value,
    doubao_api_key: el('dbkey').value.trim(),
    doubao_model: el('dbmodel').value.trim(),
    doubao_speaker: currentSpeaker(),
    doubao_appid: el('dbappid').value.trim(),
    doubao_cluster: el('dbcluster').value.trim(),
    doubao_voice: el('dbvoice').value.trim(),
    doubao_token: el('dbtoken').value.trim(),
    asr_engine: el('asrengine').value, asr_local_model: el('asrlocal').value,
    asr_base: el('asrbase').value.trim(), asr_model: el('asrmodel').value.trim(), asr_key: el('asrkey').value.trim()
  })}).then(r=>r.json());
  el('voicemsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('voicemsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){ el('asrkey').value=''; loadVoice(); }
}

let PV_PRESETS = [];
async function loadProviders(){
  const r = await fetch(B + '/api/providers').then(r=>r.json());
  if(r.code!==0) return;
  PV_PRESETS = r.presets || [];
  const sel = el('pvpreset');
  sel.innerHTML = '<option value="">-- 选择预设 --</option>' +
    PV_PRESETS.map(function(p){ return '<option value="' + p.name + '">' + p.name + '</option>'; }).join('');
  const active = (r.providers || []).find(function(p){ return p.active; });
  el('pvcurrent').textContent = active
    ? ('当前使用：' + active.name + ' · ' + active.model + '（' + active.base_url + '）')
    : '当前使用：默认 DeepSeek（来自状态页 Key 或 .env）';
  const box = el('pvlist');
  box.innerHTML = '';
  if(!r.providers.length){
    const h = document.createElement('div'); h.className='hint';
    h.textContent = '（空）还没有配置供应商，用上面的表单添加';
    box.appendChild(h);
    return;
  }
  r.providers.forEach(function(p){
    const card = document.createElement('div');
    card.style.cssText = 'border:1px solid #242833;border-radius:10px;padding:10px 12px;margin-bottom:10px';
    const head = document.createElement('div');
    head.style.cssText = 'display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap';
    const title = document.createElement('span');
    title.innerHTML = '<b>' + p.name + '</b>' + (p.active ? ' <span class="badge">使用中</span>' : '');
    head.appendChild(title);
    const btns = document.createElement('span');
    btns.style.display='flex'; btns.style.gap='6px'; btns.style.flexWrap='wrap';
    const edit = document.createElement('button'); edit.textContent='编辑';
    edit.onclick = function(){ editProvider(p); };
    btns.appendChild(edit);
    const t = document.createElement('button'); t.textContent='测试';
    t.onclick = function(){ testProvider(p.name); };
    btns.appendChild(t);
    if(!p.active){
      const act = document.createElement('button'); act.textContent='启用';
      act.onclick = function(){ activateProvider(p.name); };
      btns.appendChild(act);
    }
    const d = document.createElement('button'); d.className='danger'; d.textContent='删除';
    d.onclick = function(){ deleteProvider(p.name); };
    btns.appendChild(d);
    head.appendChild(btns);
    card.appendChild(head);
    const meta = document.createElement('div');
    meta.className='hint'; meta.style.marginTop='6px';
    meta.textContent = '模型：' + p.model + '　|　地址：' + p.base_url + '　|　Key：' + p.masked;
    card.appendChild(meta);
    const bal = document.createElement('div');
    bal.className = 'hint';
    bal.style.marginTop = '4px';
    bal.style.color = '#fbbf24';
    bal.dataset.bal = p.name;
    bal.textContent = '余额：查询中…';
    card.appendChild(bal);
    box.appendChild(card);
  });
  loadBalances(false);
}
async function loadBalances(force){
  const btn = el('pvbalbtn');
  if(btn){ btn.disabled = true; }
  if(force && el('pvbalmsg')) el('pvbalmsg').textContent = '查询中…';
  try{
    const r = await fetch(B + '/api/providers/balances' + (force ? '?force=1' : '')).then(r=>r.json());
    const map = (r && r.balances) || {};
    document.querySelectorAll('[data-bal]').forEach(function(node){
      const name = node.dataset.bal;
      const v = map[name];
      node.textContent = v ? ('余额：' + v) : '余额：不支持查询 / 获取失败';
      node.style.color = v ? '#fbbf24' : '#6b7280';
    });
    if(force && el('pvbalmsg')) el('pvbalmsg').textContent = '已刷新';
  }catch(e){
    if(el('pvbalmsg')) el('pvbalmsg').textContent = '查询失败';
  }finally{
    if(btn){ btn.disabled = false; }
  }
}
function applyPreset(){
  const name = el('pvpreset').value;
  const p = PV_PRESETS.find(function(x){ return x.name === name; });
  if(!p) return;
  if(name !== 'custom'){ el('pvname').value = name; }
  el('pvbase').value = p.base_url;
  el('pvmodel').value = p.model;
}
async function autoDetectProvider(){
  const key = el('pvkey').value.trim();
  if(!key){ el('pvmsg').textContent='先粘贴 API Key'; el('pvmsg').style.color='#f87171'; return; }
  el('pvmsg').textContent = '正在探测…'; el('pvmsg').style.color='#9aa4b8';
  const r = await fetch(B + '/api/providers/autodetect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:key})}).then(r=>r.json());
  if(r.matches && r.matches.length){
    const m = r.matches[0];
    el('pvname').value = m.name;
    el('pvbase').value = m.base_url;
    el('pvmodel').value = m.model;
    el('pvmsg').textContent = r.message;
    el('pvmsg').style.color = '#4ade80';
  } else {
    el('pvmsg').textContent = r.message || '没有匹配到';
    el('pvmsg').style.color = '#f87171';
  }
}
async function saveProvider(){
  const r = await fetch(B + '/api/providers/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    name: el('pvname').value.trim(), base_url: el('pvbase').value.trim(),
    model: el('pvmodel').value.trim(), api_key: el('pvkey').value.trim()
  })}).then(r=>r.json());
  el('pvmsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('pvmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){ el('pvkey').value=''; loadProviders(); }
}
function editProvider(p){
  el('pvname').value = p.name;
  el('pvbase').value = p.base_url;
  el('pvmodel').value = p.model;
  el('pvkey').value = '';
  el('pvkey').placeholder = '留空 = 不修改 Key';
  el('pvmsg').textContent = '正在编辑 ' + p.name + '，改完点保存';
  el('pvmsg').style.color = '#9aa4b8';
}
async function activateProvider(name){
  const r = await fetch(B + '/api/providers/activate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name})}).then(r=>r.json());
  if(r.code===0) loadProviders(); else alert(r.message||'操作失败');
}
async function testProvider(name){
  const r = await fetch(B + '/api/providers/test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name})}).then(r=>r.json());
  el('pvmsg').textContent = r.message || (r.code===0?'Key 有效':'Key 无效');
  el('pvmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
}
async function deleteProvider(name){
  const r = await fetch(B + '/api/providers/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name})}).then(r=>r.json());
  if(r.code===0) loadProviders(); else alert(r.message||'删除失败');
}

async function refreshStatus(){
  try{
    const r = await fetch(B + '/api/status').then(r=>r.json());
    if(r.code!==0) return;
    const qq = r.qq||{};
    el('stat-card').innerHTML =
      row('桥接连接', r.bridge_connected?'<span class="ok">在线</span>':'<span class="bad">离线</span>')+
      row('QQ 登录', qq.online?'<span class="ok">在线</span>':'<span class="bad">下线/未知</span>')+
      row('QQ 号', (qq.uin||r.self_id||'-'))+
      row('昵称', esc(qq.nick||'-'))+
      row('模型', esc(r.model))+
      row('运行时长', fmtUptime(r.uptime))+
      row('收 / 发消息', r.messages+' / '+r.replies)+
      row('最近消息', r.last_message? (r.last_message.time+' '+esc(r.last_message.session)+' '+esc(r.last_message.user)+': '+esc(r.last_message.text)) : '-');
    const l = await fetch(B + '/api/logs').then(r=>r.json());
    if(l.code===0) el('logbox').textContent = (l.logs||[]).slice(-25).join('\\n');
  }catch(e){}
}
function row(k,v){return '<div class="row"><span class="k">'+k+'</span><span>'+v+'</span></div>'}

let qrTimer = null, qrLeft = 0;
function qrTick(){
  if(qrLeft > 0){
    el('qrcountdown').textContent = '二维码剩余 ' + qrLeft + ' 秒，请尽快用手机 QQ 扫描';
    qrLeft--;
  } else {
    el('qrcountdown').textContent = '二维码已过期，请点「刷新二维码」';
    clearInterval(qrTimer);
    if(el('qrautorefresh').checked){
      setTimeout(function(){ getQR(true); }, 400);
    }
  }
}
async function getQR(manual){
  clearInterval(qrTimer);
  el('qrbtn').disabled = true;
  el('qrmsg').textContent = '请求中…';
  el('qrimg').innerHTML = ''; el('qrinfo').textContent=''; el('qrcountdown').textContent='';
  try{
    const r = await fetch(B + '/api/qr',{method:'POST'}).then(r=>r.json());
    if(r.code===0 && r.qrcode){
      el('qrimg').innerHTML = '<img class="qr" src="'+r.qrcode+'">';
      el('qrinfo').textContent = '请用手机 QQ「扫一扫」摄像头扫描（不要用相册/长按识别）';
      el('qrmsg').textContent = '二维码约 2 分钟有效' + (manual ? '（已刷新）' : '');
      qrLeft = 115;
      qrTick();
      qrTimer = setInterval(qrTick, 1000);
    } else {
      el('qrmsg').textContent = r.message || '申请失败';
    }
  }catch(e){ el('qrmsg').textContent = '网络错误'; }
  setTimeout(()=>{ el('qrbtn').disabled=false; }, 61000);
}

function renderList(containerId, values, onDel, emptyText){
  const box = el(containerId);
  box.innerHTML = '';
  if(!values.length){
    const hint = document.createElement('div');
    hint.className = 'hint';
    hint.textContent = emptyText || '（空）';
    box.appendChild(hint);
    return;
  }
  values.forEach(function(v){
    const row = document.createElement('div'); row.className = 'item';
    const span = document.createElement('span'); span.textContent = v;
    const btn = document.createElement('button'); btn.className = 'danger'; btn.textContent = '删除';
    btn.onclick = function(){ onDel(v); };
    row.appendChild(span); row.appendChild(btn);
    box.appendChild(row);
  });
}

async function loadWL(){
  const r = await fetch(B + '/api/whitelist').then(r=>r.json());
  if(r.code!==0){ alert(r.message||'无权限'); return; }
  renderWlList('glist', r.groups||[], 'group', r);
  renderWlList('ulist', r.users||[], 'user', r);
  const qg = r.role==='super' ? '不限' : (r.quota_groups==null ? '不限' : (r.used_groups+' / '+r.quota_groups));
  const qu = r.role==='super' ? '不限' : (r.quota_users==null ? '不限' : (r.used_users+' / '+r.quota_users));
  el('wlquota').textContent = '你的配额：群 ' + qg + ' ｜ QQ ' + qu + (r.role==='user' ? '（只能看到和删除自己添加的）' : '');
}
function renderWlList(id, items, type, r){
  const box = el(id);
  box.innerHTML = '';
  if(!items.length){
    const h = document.createElement('div'); h.className='hint'; h.textContent = (type==='group' ? '（空）允许所有群' : '（空）允许所有人');
    box.appendChild(h);
    return;
  }
  items.forEach(function(it){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span');
    span.textContent = it.id + (it.owner ? (' · 由 ' + it.owner + ' 添加') : '');
    span.style.flex = '1';
    row.appendChild(span);
    const can = (r.role !== 'user') || it.mine;
    if(can){
      const ed = document.createElement('button'); ed.textContent = '修改';
      ed.style.background = '#4b5563';
      ed.onclick = function(){ editWL(type, it.id); };
      row.appendChild(ed);
      const del = document.createElement('button'); del.textContent = '删除';
      del.style.background = '#b91c1c';
      del.onclick = function(){ delWL(type, it.id); };
      row.appendChild(del);
    }
    box.appendChild(row);
  });
}
async function addWL(type){
  const input = type==='group' ? el('ginput') : el('uinput');
  const v = input.value.trim(); if(!v) return;
  const r = await fetch(B + '/api/whitelist/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:type, value:v})}).then(r=>r.json());
  if(r.code===0){ input.value=''; loadWL(); } else { alert(r.message||'添加失败'); }
}
async function delWL(type, value){
  const r = await fetch(B + '/api/whitelist/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:type, value:value})}).then(r=>r.json());
  if(r.code!==0){ alert(r.message||'删除失败'); return; }
  loadWL();
}
async function editWL(type, old){
  const nv = prompt('修改为新的' + (type==='group' ? '群号' : 'QQ号'), old);
  if(!nv || nv.trim() === old) return;
  const r = await fetch(B + '/api/whitelist/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:type, old:old, new:nv.trim()})}).then(r=>r.json());
  if(r.code!==0){ alert(r.message||'修改失败'); return; }
  loadWL();
}

async function loadAccounts(){
  const r = await fetch(B + '/api/accounts').then(r=>r.json());
  if(r.code!==0){ el('acclist').textContent = r.message || '无权限'; return; }
  const isSuper = r.my_role === 'super';
  el('acchint').textContent = isSuper ? '你可以创建超级管理员/管理员/用户，并设置配额' : '你可以创建用户，并设置其配额';
  let opts = '<option value="user">用户</option>';
  if(isSuper){
    opts += '<option value="admin">管理员</option><option value="super">超级管理员</option>';
    if(r.viewer_enabled) opts += '<option value="viewer">观察者</option>';
  }
  el('accrole').innerHTML = opts;
  const box = el('acclist'); box.innerHTML = '';
  const labels = {super:'超级管理员', admin:'管理员', user:'用户', viewer:'观察者'};
  if(!r.accounts.length){
    const h = document.createElement('div'); h.className='hint'; h.textContent='（暂无账号）';
    box.appendChild(h);
    return;
  }
  r.accounts.forEach(function(a){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span'); span.style.flex='1';
    const qg = (a.quota_groups == null) ? '不限' : a.quota_groups;
    const qu = (a.quota_users == null) ? '不限' : a.quota_users;
    span.textContent = a.username + ' · ' + (labels[a.role]||a.role) + ' · 配额 群' + qg + '/QQ' + qu
      + (a.last_login_at ? (' · 最近登录 ' + a.last_login_at) : '') + (a.disabled ? ' · 已禁用' : '');
    row.appendChild(span);
    const mk = function(label, bg, fn){ const b=document.createElement('button'); b.textContent=label; b.style.background=bg; b.onclick=fn; row.appendChild(b); };
    mk('改配额', '#4b5563', function(){ editAccount(a); });
    mk('重置密码', '#4b5563', function(){ resetAccountPassword(a.id); });
    mk(a.disabled ? '启用' : '禁用', a.disabled ? '#16a34a' : '#b45309', function(){ toggleAccount(a.id, !a.disabled); });
    mk('删除', '#b91c1c', function(){ deleteAccount(a); });
    box.appendChild(row);
  });
}
async function createAccount(){
  const r = await fetch(B + '/api/accounts/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    username: el('accname').value.trim(),
    password: el('accpass').value,
    role: el('accrole').value,
    quota_groups: el('accqg').value,
    quota_users: el('accqu').value
  })}).then(r=>r.json());
  el('accmsg').textContent = r.code===0 ? '创建成功' : (r.message||'创建失败');
  el('accmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){ el('accname').value=''; el('accpass').value=''; loadAccounts(); }
}
async function editAccount(a){
  const qg = prompt('最多可添加群数（留空=不限）', a.quota_groups == null ? '' : a.quota_groups);
  if(qg === null) return;
  const qu = prompt('最多可添加 QQ 数（留空=不限）', a.quota_users == null ? '' : a.quota_users);
  if(qu === null) return;
  const r = await fetch(B + '/api/accounts/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:a.id, quota_groups:qg.trim(), quota_users:qu.trim()})}).then(r=>r.json());
  if(r.code!==0) alert(r.message||'保存失败');
  loadAccounts();
}
async function resetAccountPassword(id){
  const pw = prompt('输入新密码（至少6位）');
  if(!pw) return;
  const r = await fetch(B + '/api/accounts/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:id, password:pw})}).then(r=>r.json());
  if(r.code!==0) alert(r.message||'重置失败'); else alert('密码已重置');
}
async function toggleAccount(id, disabled){
  const r = await fetch(B + '/api/accounts/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:id, disabled:disabled})}).then(r=>r.json());
  if(r.code!==0) alert(r.message||'操作失败'); else loadAccounts();
}
async function deleteAccount(a){
  if(!confirm('确定删除账号 ' + a.username + '？')) return;
  const r = await fetch(B + '/api/accounts/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:a.id})}).then(r=>r.json());
  if(r.code!==0) alert(r.message||'删除失败'); else loadAccounts();
}
async function loadLoginLogs(){
  const r = await fetch(B + '/api/login-logs').then(r=>r.json());
  const box = el('loginloglist'); box.innerHTML = '';
  if(r.code!==0){ box.textContent = r.message || '无权限'; return; }
  if(!r.logs.length){
    const h = document.createElement('div'); h.className='hint'; h.textContent='（暂无日志）';
    box.appendChild(h); return;
  }
  r.logs.forEach(function(l){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span'); span.style.flex='1';
    span.textContent = l.created_at + ' · ' + l.username + '(' + (l.role||'-') + ') · ' + (l.success ? '成功' : '失败')
      + ' · ' + (l.ip||'-') + (l.location ? (' · ' + l.location) : '') + (l.reason ? (' · ' + l.reason) : '');
    row.appendChild(span);
    box.appendChild(row);
  });
}

async function loadKW(){
  const r = await fetch(B + '/api/keywords').then(r=>r.json());
  if(r.code!==0) return;
  renderList('kwlist', r.keywords, delKW, '（空）暂无触发词');
}
async function addKW(){
  const v = el('kwinput').value.trim(); if(!v) return;
  const r = await fetch(B + '/api/keywords/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({word:v})}).then(r=>r.json());
  if(r.code===0){ el('kwinput').value=''; loadKW(); } else { alert(r.message||'添加失败'); }
}
async function delKW(w){
  await fetch(B + '/api/keywords/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({word:w})});
  loadKW();
}

async function loadPrefix(){
  const r = await fetch(B + '/api/prefix').then(r=>r.json());
  if(r.code!==0) return;
  const pb = el('pfbtn');
  pb.textContent = r.enabled ? '前缀功能：已开启（点击关闭）' : '前缀功能：已关闭（点击开启）';
  pb.style.background = r.enabled ? '#16a34a' : '#4b5563';
  const box = el('pflist');
  box.innerHTML = '';
  if(!r.prefixes.length){
    const hint = document.createElement('div'); hint.className='hint';
    hint.textContent = '（空）暂无专属前缀';
    box.appendChild(hint);
    return;
  }
  r.prefixes.forEach(function(item){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span'); span.textContent = item.qq + ' → ' + item.prefix;
    const btn = document.createElement('button'); btn.className='danger'; btn.textContent='删除';
    btn.onclick = function(){ delPrefix(item.qq); };
    row.appendChild(span); row.appendChild(btn);
    box.appendChild(row);
  });
}
async function togglePrefix(){
  const cur = el('pfbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/prefix/toggle',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled: !cur})}).then(r=>r.json());
  if(r.code===0) loadPrefix(); else alert(r.message||'操作失败');
}
async function addPrefix(){
  const qq = el('pfqq').value.trim();
  const prefix = el('pftext').value.trim();
  const r = await fetch(B + '/api/prefix/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({qq:qq, prefix:prefix})}).then(r=>r.json());
  if(r.code===0){ el('pfqq').value=''; el('pftext').value=''; loadPrefix(); } else { alert(r.message||'添加失败'); }
}
async function delPrefix(qq){
  await fetch(B + '/api/prefix/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({qq:qq})});
  loadPrefix();
}

async function loadAuto(){
  const r = await fetch(B + '/api/auto').then(r=>r.json());
  if(r.code!==0) return;
  const btn = el('autobtn');
  btn.textContent = r.enabled ? '已开启（点击关闭）' : '已关闭（点击开启）';
  btn.style.background = r.enabled ? '#16a34a' : '#4b5563';
  el('autostate').textContent = r.users.length ? ('名单：' + r.users.length + ' 个 QQ') : '名单为空';
  const box = el('autolist');
  box.innerHTML = '';
  if(!r.users.length){
    const hint = document.createElement('div'); hint.className='hint';
    hint.textContent = '（空）还没有接话用户';
    box.appendChild(hint);
    return;
  }
  r.users.forEach(function(qq){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span'); span.textContent = qq;
    const del = document.createElement('button'); del.className='danger'; del.textContent='删除';
    del.onclick = function(){ delAuto(qq); };
    row.appendChild(span); row.appendChild(del);
    box.appendChild(row);
  });
  if(STK_DATA.length > STK_SHOWN){
    const more = document.createElement('button');
    more.textContent = '显示更多（还有 ' + (STK_DATA.length - STK_SHOWN) + ' 张）';
    more.style.marginTop = '8px';
    more.onclick = function(){ STK_SHOWN += 50; renderStkList(); };
    box.appendChild(more);
  }
}
async function toggleAuto(){
  const cur = el('autobtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/auto/toggle',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled: !cur})}).then(r=>r.json());
  if(r.code===0) loadAuto();
}
async function addAuto(){
  const v = el('autoqq').value.trim(); if(!v) return;
  const r = await fetch(B + '/api/auto/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({qq:v})}).then(r=>r.json());
  if(r.code===0){ el('autoqq').value=''; loadAuto(); } else { alert(r.message||'添加失败'); }
}
async function delAuto(qq){
  await fetch(B + '/api/auto/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({qq:qq})});
  loadAuto();
}

async function loadEnd(){
  const r = await fetch(B + '/api/end-phrase').then(r=>r.json());
  if(r.code!==0) return;
  const b = el('endtoggle');
  b.textContent = r.enabled ? '结束语功能：已开启（点击关闭）' : '结束语功能：已关闭（点击开启）';
  b.style.background = r.enabled ? '#16a34a' : '#4b5563';
  el('endreply').value = r.reply || '';
  renderEndPhrases(r.phrases || []);
}
function renderEndPhrases(list){
  const box = el('endlist');
  box.innerHTML = '';
  if(!list.length){
    const h = document.createElement('div'); h.className='hint';
    h.textContent = '（空）没有触发词，功能相当于关闭';
    box.appendChild(h);
    return;
  }
  list.forEach(function(p){
    const row = document.createElement('div'); row.className='item';
    const sp = document.createElement('span'); sp.textContent = p;
    const del = document.createElement('button'); del.className='danger'; del.textContent='删除';
    del.onclick = function(){ delEndPhrase(p); };
    row.appendChild(sp); row.appendChild(del);
    box.appendChild(row);
  });
}
async function toggleEnd(){
  const cur = el('endtoggle').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/end-phrase/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled: !cur})}).then(r=>r.json());
  if(r.code===0) loadEnd(); else alert(r.message||'操作失败');
}
async function saveEndReply2(){
  const r = await fetch(B + '/api/end-phrase/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reply: el('endreply').value})}).then(r=>r.json());
  el('endmsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('endmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadEnd();
}
async function addEndPhrase(){
  const v = el('endinput').value.trim(); if(!v) return;
  const r = await fetch(B + '/api/end-phrase/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({phrase:v})}).then(r=>r.json());
  if(r.code===0){ el('endinput').value=''; loadEnd(); } else { alert(r.message||'添加失败'); }
}
async function delEndPhrase(p){
  await fetch(B + '/api/end-phrase/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({phrase:p})});
  loadEnd();
}

let STK_DATA = [], STK_SHOWN = 50;
async function loadStickers(){
  const r = await fetch(B + '/api/stickers').then(r=>r.json());
  if(r.code!==0) return;
  el('stkprob').value = r.probability;
  el('skmrandom').style.background = (r.mode==='smart') ? '#4b5563' : '#2563eb';
  el('skmsmart').style.background = (r.mode==='smart') ? '#2563eb' : '#4b5563';
  el('stkbase').textContent = r.base ? ('当前表情包访问地址：' + r.base) : '提示：上传一张图后会自动记录访问地址';
  STK_DATA = r.stickers || [];
  STK_SHOWN = 50;
  renderStkList();
}
function renderStkList(){
  const r = { stickers: STK_DATA };
  const box = el('stklist');
  box.innerHTML = '';
  if(!r.stickers.length){
    const hint = document.createElement('div'); hint.className='hint';
    hint.textContent = '（空）还没有表情包';
    box.appendChild(hint);
    return;
  }
  r.stickers.slice(0, STK_SHOWN).forEach(function(it){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span');
    span.style.display='flex'; span.style.alignItems='center'; span.style.gap='8px';
    if(it.url){
      const img = document.createElement('img');
      img.src = it.url; img.loading = 'lazy'; img.decoding = 'async';
      img.style.width='44px'; img.style.height='44px';
      img.style.objectFit='contain'; img.style.background='#fff'; img.style.borderRadius='6px';
      span.appendChild(img);
    }
    const info = document.createElement('span');
    info.style.display='flex'; info.style.flexDirection='column'; info.style.gap='2px';
    const t = document.createElement('span'); t.textContent = it.name;
    info.appendChild(t);
    const d = document.createElement('span'); d.className='hint';
    d.style.fontSize='12px';
    d.textContent = it.description ? ('说明：' + it.description) : '说明：未设置（智能匹配不会用到）';
    info.appendChild(d);
    span.appendChild(info);
    row.appendChild(span);
    const ed = document.createElement('button'); ed.textContent='编辑说明'; ed.style.background='#4b5563';
    ed.onclick = function(){
      const v = prompt('表情包说明（用于智能匹配，2~10字或一句话）', it.description || '');
      if(v === null) return;
      fetch(B + '/api/stickers/desc',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:it.name, description:v})}).then(function(){ loadStickers(); });
    };
    row.appendChild(ed);
    const del = document.createElement('button'); del.className='danger'; del.textContent='删除';
    del.onclick = function(){ delSticker(it.name); };
    row.appendChild(del);
    box.appendChild(row);
  });
  if(STK_DATA.length > STK_SHOWN){
    const more = document.createElement('button');
    more.textContent = '显示更多（还有 ' + (STK_DATA.length - STK_SHOWN) + ' 张）';
    more.style.marginTop = '8px';
    more.onclick = function(){ STK_SHOWN += 50; renderStkList(); };
    box.appendChild(more);
  }
}
async function setStickerMode(mode){
  const r = await fetch(B + '/api/stickers/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:mode})}).then(r=>r.json());
  if(r.code===0) loadStickers(); else alert(r.message||'操作失败');
}
async function uploadSticker(){
  const f = el('stkfile').files[0];
  if(!f){ alert('先选择一张图片'); return; }
  const fd = new FormData(); fd.append('file', f);
  const r = await fetch(B + '/api/stickers/upload',{method:'POST',body:fd}).then(r=>r.json()).catch(function(){ return {code:-1,message:'上传失败'}; });
  if(r.code===0){ el('stkfile').value=''; loadStickers(); } else { alert(r.message||'上传失败'); }
}
async function uploadStickerMany(){
  const files = el('stkfile').files;
  if(!files || !files.length){ alert('先选择图片（可多选）'); return; }
  const fd = new FormData();
  for(let i=0;i<files.length;i++) fd.append('files', files[i]);
  const r = await fetch(B + '/api/stickers/upload_many',{method:'POST',body:fd}).then(r=>r.json()).catch(function(){ return {code:-1}; });
  if(r.code!==0){ alert('上传失败'); return; }
  alert('批量上传完成：成功 ' + r.saved + ' 张' + (r.failed ? ('，失败 ' + r.failed + ' 张') : ''));
  el('stkfile').value='';
  loadStickers();
}
async function addStickerUrls(){
  const raw = el('stkurls').value || '';
  const urls = raw.split(String.fromCharCode(10)).map(function(s){ return s.trim(); }).filter(Boolean);
  if(!urls.length){ alert('先粘贴图片链接，一行一个'); return; }
  const r = await fetch(B + '/api/stickers/add_urls',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({urls:urls})}).then(r=>r.json()).catch(function(){ return {code:-1}; });
  if(r.code!==0){ alert('导入失败'); return; }
  alert('导入完成：成功 ' + r.saved + ' 张' + (r.failed ? ('，失败 ' + r.failed + ' 张') : ''));
  el('stkurls').value='';
  loadStickers();
}
async function delSticker(name){
  await fetch(B + '/api/stickers/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name})});
  loadStickers();
}
async function saveStickerProb(){
  const r = await fetch(B + '/api/stickers/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({probability: parseInt(el('stkprob').value||'0')})}).then(r=>r.json());
  el('stkmsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('stkmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadStickers();
}

let SEG_MODE = 'fixed';
function setSegMode(m){
  SEG_MODE = (m === 'random') ? 'random' : 'fixed';
  el('segfixed').style.background = (SEG_MODE === 'fixed') ? '#2563eb' : '#4b5563';
  el('segrandom').style.background = (SEG_MODE === 'random') ? '#2563eb' : '#4b5563';
  applySegView();
}
function applySegView(){
  const fixed = SEG_MODE !== 'random';
  const fw = el('segfixedwrap'), r1 = el('segrandwrap1'), r2 = el('segrandwrap2');
  fw.style.display = fixed ? '' : 'none';
  r1.style.display = fixed ? 'none' : '';
  r2.style.display = fixed ? 'none' : '';
  const box = fixed ? fw : r1;
  if(box){
    box.classList.remove('seg-anim');
    void box.offsetWidth;
    box.classList.add('seg-anim');
  }
}
async function saveSegConfig(){
  const r = await fetch(B + '/api/group-rate/segconfig',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    mode: SEG_MODE,
    fixed: parseInt(el('segfixedn').value||'2'),
    min: parseInt(el('segmin').value||'1'),
    max: parseInt(el('segmax').value||'5')
  })}).then(r=>r.json());
  el('segmsg').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('segmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
}
async function saveSegTiming(){
  const r = await fetch(B + '/api/group-rate/segconfig',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    first_delay_ms: parseInt(el('segfirst').value||'300'),
    seg_delay_ms: parseInt(el('segdelay').value||'600'),
    sticker_delay_ms: parseInt(el('segsticker').value||'800')
  })}).then(r=>r.json());
  el('segmsg2').textContent = r.code===0 ? '已保存' : (r.message||'保存失败');
  el('segmsg2').style.color = r.code===0 ? '#4ade80' : '#f87171';
}
async function loadRate(){
  const r = await fetch(B + '/api/group-rate').then(r=>r.json());
  if(r.code!==0) return;
  el('ratedefault').textContent = '默认：每分钟最多 ' + r.default_max + ' 条，间隔 ' + r.default_min + ' 秒';
  el('segfixedn').value = r.seg_fixed;
  el('segfirst').value = r.first_delay_ms;
  el('segdelay').value = r.seg_delay_ms;
  el('segsticker').value = r.sticker_delay_ms;
  el('segmin').value = r.seg_min;
  el('segmax').value = r.seg_max;
  setSegMode(r.seg_mode || 'fixed');
  const box = el('ratelist');
  box.innerHTML = '';
  if(!r.groups.length){
    const hint = document.createElement('div'); hint.className='hint';
    hint.textContent = '白名单为空，暂无群可配置（先到「白名单」添加群号）';
    box.appendChild(hint);
    return;
  }
  r.groups.forEach(function(gid){
    const rate = r.rates.find(function(x){ return x.group_id === gid; });
    const row = document.createElement('div'); row.className='item'; row.style.flexWrap='wrap'; row.style.gap='6px';
    const span = document.createElement('span'); span.textContent = gid; span.style.minWidth='86px';
    const i1 = document.createElement('input'); i1.type='number'; i1.min='1'; i1.style.width='76px'; i1.placeholder='最多几条/分'; i1.value = rate ? rate.max_per_minute : '';
    const i2 = document.createElement('input'); i2.type='number'; i2.min='1'; i2.style.width='76px'; i2.placeholder='间隔几秒'; i2.value = rate ? rate.min_interval_seconds : '';
    const b = document.createElement('button'); b.textContent='保存'; b.onclick = function(){ saveRate(gid, i1.value, i2.value); };
    const b2 = document.createElement('button'); b2.className='danger'; b2.textContent='恢复默认'; b2.onclick = function(){ resetRate(gid); };
    row.appendChild(span); row.appendChild(i1); row.appendChild(i2); row.appendChild(b); row.appendChild(b2);
    box.appendChild(row);
  });
}
async function saveRate(gid, cap, interval){
  const r = await fetch(B + '/api/group-rate/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({group_id:gid, max_per_minute:parseInt(cap||'6'), min_interval_seconds:parseInt(interval||'3')})}).then(r=>r.json());
  if(r.code===0){ loadRate(); } else { alert(r.message||'保存失败'); }
}
async function resetRate(gid){
  await fetch(B + '/api/group-rate/reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({group_id:gid})});
  loadRate();
}

async function loadGR(){
  const r = await fetch(B + '/api/group-reply').then(r=>r.json());
  if(r.code!==0) return;
  loadConvos();
  el('grsecs').value = r.continue_seconds;
  el('grcap').value = r.max_replies;
  el('gramax').value = r.max_active_users;
  const tb = el('thriftbtn');
  tb.textContent = r.thrifty ? '省流模式：已开启（只回@/关键词）' : '省流模式：已关闭';
  tb.style.background = r.thrifty ? '#16a34a' : '#4b5563';
  const ab = el('atreplybtn');
  ab.textContent = r.at_reply ? '被@时回复@对方：已开启' : '被@时回复@对方：已关闭';
  ab.style.background = r.at_reply ? '#16a34a' : '#4b5563';
  if(r.whitelist_empty){
    el('grhint').textContent = '白名单为空：当前对全部群聊生效，下面显示的是近期收到过消息的群。建议先去白名单添加群。';
  } else {
    el('grhint').textContent = '接话时间：机器人说过话后，这段时间内群消息免 @ 继续接话（秒）。频率：每分钟最多回复条数。';
  }
  const box = el('grlist');
  box.innerHTML = '';
  if(!r.groups.length){
    const hint = document.createElement('div'); hint.className='hint';
    hint.textContent = '（暂无群）白名单为空时默认全部群聊生效';
    box.appendChild(hint);
    return;
  }
  r.groups.forEach(function(gid){
    const on = r.always.indexOf(gid) !== -1;
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span'); span.textContent = gid;
    const btn = document.createElement('button');
    btn.textContent = on ? '一直接话：开' : '一直接话：关';
    btn.style.background = on ? '#16a34a' : '#4b5563';
    btn.onclick = function(){ toggleGRAlways(gid, !on); };
    row.appendChild(span); row.appendChild(btn);
    box.appendChild(row);
  });
}
async function loadConvos(){
  const r = await fetch(B + '/api/conversations').then(r=>r.json());
  if(r.code!==0) return;
  const box = el('convlist');
  box.innerHTML = '';
  if(!r.items.length){
    const hint = document.createElement('div'); hint.className='hint';
    hint.textContent = '（空）当前没有接话中的用户';
    box.appendChild(hint);
    return;
  }
  r.items.forEach(function(it){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span');
    span.textContent = '群 ' + it.group_id + ' · QQ ' + it.qq + ' · 剩余 ' + it.expires_in + ' 秒';
    const del = document.createElement('button'); del.className='danger'; del.textContent='删除';
    del.onclick = function(){ removeConvo(it.group_id, it.qq); };
    row.appendChild(span); row.appendChild(del); box.appendChild(row);
  });
}
async function saveGRConfig(){
  const r = await fetch(B + '/api/group-reply/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({continue_seconds: parseInt(el('grsecs').value||'180'), max_replies: parseInt(el('grcap').value||'6'), max_active_users: parseInt(el('gramax').value||'3')})}).then(r=>r.json());
  el('grmsg').textContent = r.code===0 ? '已保存，立即生效' : (r.message||'保存失败');
  el('grmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
}
async function removeConvo(gid, qq){
  const r = await fetch(B + '/api/conversations/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({group_id:gid, qq:qq})}).then(r=>r.json());
  if(r.code===0) loadConvos(); else alert(r.message||'删除失败');
}

async function toggleAtReply(){
  const cur = el('atreplybtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/group-reply/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({at_reply: !cur})}).then(r=>r.json());
  if(r.code===0) loadGR(); else alert(r.message||'操作失败');
}
async function toggleThrift(){
  const cur = el('thriftbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/group-reply/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({thrifty: !cur})}).then(r=>r.json());
  if(r.code===0) loadGR(); else alert(r.message||'操作失败');
}
async function toggleGRAlways(gid, enabled){
  const r = await fetch(B + '/api/group-reply/always',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({group_id:gid, enabled:enabled})}).then(r=>r.json());
  if(r.code===0) loadGR(); else alert(r.message||'操作失败');
}

async function loadBored(){
  const r = await fetch(B + '/api/bored').then(r=>r.json());
  if(r.code!==0) return;
  const btn = el('boredbtn');
  btn.textContent = r.enabled ? '已开启（点击关闭）' : '已关闭（点击开启）';
  btn.style.background = r.enabled ? '#16a34a' : '#4b5563';
  el('boredstate').textContent = r.enabled ? '群聊安静太久会主动冒泡' : '不会主动冒泡';
  el('boredmin').value = r.min_minutes;
  el('boredfixed').value = r.interval_minutes;
  el('btf').style.background = (r.time_mode==='fixed') ? '#2563eb' : '#4b5563';
  el('btr').style.background = (r.time_mode==='fixed') ? '#4b5563' : '#2563eb';
  el('boredmax').value = r.max_minutes;
  el('boredfloor').value = r.floor_minutes;
  el('modepool').style.background = (r.mode==='ai') ? '#4b5563' : '#2563eb';
  el('modeai').style.background = (r.mode==='ai') ? '#2563eb' : '#4b5563';
  loadBoredLines();
}
async function setBoredMode(mode){
  const r = await fetch(B + '/api/bored/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode: mode})}).then(r=>r.json());
  if(r.code===0) loadBored(); else alert(r.message||'操作失败');
}
async function loadBoredLines(){
  const r = await fetch(B + '/api/bored/lines').then(r=>r.json());
  if(r.code!==0) return;
  const box = el('bllist');
  box.innerHTML = '';
  if(!r.lines.length){
    const hint = document.createElement('div'); hint.className='hint';
    hint.textContent = '（空）静态模式将使用内置兜底语料';
    box.appendChild(hint);
    return;
  }
  r.lines.forEach(function(line){
    const row = document.createElement('div'); row.className='item';
    const span = document.createElement('span'); span.textContent = line;
    const del = document.createElement('button'); del.className='danger'; del.textContent='删除';
    del.onclick = function(){ delBoredLine(line); };
    row.appendChild(span); row.appendChild(del);
    box.appendChild(row);
  });
  if(STK_DATA.length > STK_SHOWN){
    const more = document.createElement('button');
    more.textContent = '显示更多（还有 ' + (STK_DATA.length - STK_SHOWN) + ' 张）';
    more.style.marginTop = '8px';
    more.onclick = function(){ STK_SHOWN += 50; renderStkList(); };
    box.appendChild(more);
  }
}
async function addBoredLine(){
  const v = el('blinput').value.trim(); if(!v) return;
  const r = await fetch(B + '/api/bored/lines/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({line:v})}).then(r=>r.json());
  if(r.code===0){ el('blinput').value=''; loadBoredLines(); } else { alert(r.message||'添加失败'); }
}
async function delBoredLine(line){
  await fetch(B + '/api/bored/lines/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({line:line})});
  loadBoredLines();
}
async function toggleBored(){
  const cur = el('boredbtn').textContent.indexOf('已开启') !== -1;
  const r = await fetch(B + '/api/bored/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled: !cur, interval_minutes: parseInt(el('boredmin').value||'30')})}).then(r=>r.json());
  if(r.code===0) loadBored(); else alert(r.message||'操作失败');
}
async function setBoredTimeMode(mode){
  const r = await fetch(B + '/api/bored/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({time_mode: mode})}).then(r=>r.json());
  if(r.code===0) loadBored(); else alert(r.message||'操作失败');
}
async function saveBoredInterval(){
  const r = await fetch(B + '/api/bored/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    min_minutes: parseInt(el('boredmin').value||'30'),
    max_minutes: parseInt(el('boredmax').value||'60'),
    floor_minutes: parseInt(el('boredfloor').value||'30'),
    interval_minutes: parseInt(el('boredfixed').value||el('boredmin').value||'30')
  })}).then(r=>r.json());
  el('boredmsg').textContent = r.code===0 ? '已保存，到点生效' : (r.message||'保存失败');
  el('boredmsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0) loadBored();
}

async function loadAdmins(){
  const r = await fetch(B + '/api/admins').then(r=>r.json());
  if(r.code!==0) return;
  renderList('alist', r.admins, delAdmin, '（空）');
}
async function addAdmin(){
  const u = el('newuser').value.trim(), p = el('newpass').value;
  const r = await fetch(B + '/api/admins/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u, password:p})}).then(r=>r.json());
  el('admsg').textContent = r.code===0 ? '已添加' : (r.message||'添加失败');
  el('admsg').style.color = r.code===0 ? '#4ade80' : '#f87171';
  if(r.code===0){ el('newuser').value=''; el('newpass').value=''; loadAdmins(); }
}
async function delAdmin(u){
  const r = await fetch(B + '/api/admins/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u})}).then(r=>r.json());
  if(r.code!==0){ alert(r.message||'删除失败'); } else { loadAdmins(); }
}

(function(){
  const hint = document.getElementById('swipehint');
  const tabs = document.getElementById('tabs');
  if(!hint || !tabs) return;
  const hide = function(){ hint.style.display = 'none'; };
  if(tabs.scrollWidth <= tabs.clientWidth + 4){ hide(); return; }
  tabs.addEventListener('scroll', function(){ if(tabs.scrollLeft > 8) hide(); }, {passive:true});
  setTimeout(hide, 8000);
})();
</script>
</body></html>"""


def main():
    cfg = load_config()
    bridge = Bridge(cfg)
    try:
        asyncio.run(bridge.run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
