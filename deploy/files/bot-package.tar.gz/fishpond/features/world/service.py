"""世界引擎 P0：世界时钟、日程、状态、事件日志、对话注入。"""
import asyncio
import datetime as _dt
import logging
import time

import aiohttp.web as aiohttp_web

log = logging.getLogger("qqbridge")

WEEK = "一二三四五六日"


def _today_index() -> int:
    return (_dt.date.today() - _dt.date(2026, 1, 1)).days


def ensure_world_tables(conn):
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS world_state (
        id INTEGER PRIMARY KEY CHECK (id=1),
        day_index INTEGER NOT NULL,
        minutes INTEGER NOT NULL,
        weather TEXT DEFAULT '晴',
        place TEXT DEFAULT '家',
        activity TEXT DEFAULT '休息',
        energy INTEGER DEFAULT 80,
        mood TEXT DEFAULT '平静',
        updated_at REAL
    );
    CREATE TABLE IF NOT EXISTS world_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        day_index INTEGER NOT NULL,
        minutes INTEGER NOT NULL,
        kind TEXT DEFAULT 'life',
        text TEXT NOT NULL,
        created_at REAL
    );
    CREATE INDEX IF NOT EXISTS idx_we_day ON world_events(day_index);
    """)
    row = conn.execute("SELECT id FROM world_state WHERE id=1").fetchone()
    if not row:
        conn.execute("INSERT INTO world_state(id,day_index,minutes,weather,place,activity,energy,mood,updated_at)"
                     " VALUES(1,?,?,?,?,?,?,?,?)",
                     (_today_index(), 8 * 60, "晴", "家", "刚起床", 80, "平静", time.time()))


def _schedule(minutes: int, weekday: int):
    """返回 (地点, 活动, 精力变化)。P0 固定为便利店夜班店员。"""
    if 22 * 60 <= minutes or minutes < 6 * 60:
        return "便利店", "值夜班", -1
    if 6 * 60 <= minutes < 7 * 60:
        return "路上", "下班回家", -1
    if 7 * 60 <= minutes < 14 * 60:
        return "家", "睡觉", +2
    if 14 * 60 <= minutes < 18 * 60:
        return "家", "画画接单", -1
    if 18 * 60 <= minutes < 20 * 60:
        return "家", "吃饭休息", 0
    return "街上", "闲逛", 0


class WorldMixin:
    async def world_loop(self):
        while not self._stop:
            await asyncio.sleep(300)
            try:
                if self.store.get_setting("world_enabled", "0") != "1":
                    continue
                scale = max(1, int(self.store.get_setting("world_scale", "1") or 1))
                self.world_tick(5 * scale)
            except Exception as e:
                log.warning("世界 tick 异常: %s", e)

    def world_state(self) -> dict:
        with self.store._conn() as c:
            r = c.execute("SELECT * FROM world_state WHERE id=1").fetchone()
        return dict(r) if r else {}

    def world_tick(self, advance: int = 5) -> dict:
        st = self.world_state()
        if not st:
            return {}
        minutes = st["minutes"] + advance
        day = st["day_index"]
        while minutes >= 1440:
            minutes -= 1440
            day += 1
        weekday = (day + 3) % 7  # 2026-01-01 是周四
        place, activity, delta = _schedule(minutes, weekday)
        energy = max(0, min(100, st["energy"] + delta * (advance // 5 or 1)))
        mood = "疲惫" if energy < 25 else ("有精神" if energy > 70 else "平静")
        with self.store._conn() as c:
            c.execute("UPDATE world_state SET day_index=?,minutes=?,place=?,activity=?,energy=?,mood=?,updated_at=? WHERE id=1",
                      (day, minutes, place, activity, energy, mood, time.time()))
            if place != st["place"] or activity != st["activity"]:
                c.execute("INSERT INTO world_events(day_index,minutes,kind,text,created_at) VALUES(?,?,?,?,?)",
                          (day, minutes, "move", f"{self._world_clock_text(day, minutes)} 去{place}{activity}", time.time()))
        return self.world_state()

    @staticmethod
    def _world_clock_text(day: int, minutes: int) -> str:
        d = _dt.date(2026, 1, 1) + _dt.timedelta(days=day)
        return f"{d.month}月{d.day}日 周{WEEK[d.weekday()]} {minutes // 60:02d}:{minutes % 60:02d}"

    def world_context(self, uid: str = "") -> str:
        if self.store.get_setting("world_enabled", "0") != "1":
            return ""
        st = self.world_state()
        if not st:
            return ""
        clock = self._world_clock_text(st["day_index"], st["minutes"])
        return (f"\n【你现在的生活】世界时间 {clock}。你人在{st['place']}，正在{st['activity']}，"
                f"精力{'充足' if st['energy'] > 70 else ('一般' if st['energy'] > 25 else '很差')}，心情{st['mood']}。"
                f"聊天时可以自然带出你正在做的事，但不要每句都汇报。")

    def world_recent_events(self, limit: int = 20) -> list:
        with self.store._conn() as c:
            rows = c.execute("SELECT * FROM world_events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    async def api_world_state(self, request):
        self.require_super(request)
        st = self.world_state()
        st["clock"] = self._world_clock_text(st.get("day_index", 0), st.get("minutes", 0)) if st else ""
        st["enabled"] = self.store.get_setting("world_enabled", "0")
        st["scale"] = self.store.get_setting("world_scale", "1")
        return aiohttp_web.json_response({"code": 0, "state": st, "events": self.world_recent_events(30)})

    async def api_world_config(self, request):
        self.require_super(request)
        data = await request.json()
        if "enabled" in data:
            self.store.set_setting("world_enabled", "1" if data.get("enabled") else "0")
        if "scale" in data:
            self.store.set_setting("world_scale", str(max(1, min(24, int(data.get("scale") or 1)))))
        return aiohttp_web.json_response({"code": 0})

    async def api_world_tick(self, request):
        self.require_super(request)
        self.world_tick(60)
        return aiohttp_web.json_response({"code": 0, "state": self.world_state()})

    async def start_world_loop(self):
        self._world_task = asyncio.get_running_loop().create_task(self.world_loop())
